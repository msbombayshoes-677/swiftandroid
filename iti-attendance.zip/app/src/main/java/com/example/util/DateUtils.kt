package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtils {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val displayDateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
    private val militaryTimeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val monthYearFormat = SimpleDateFormat("MMMM yyyy", Locale.getDefault())

    fun getTodayDateString(): String {
        return dateFormat.format(Date())
    }

    fun formatDateForDisplay(dateStr: String): String {
        return try {
            val date = dateFormat.parse(dateStr)
            if (date != null) displayDateFormat.format(date) else dateStr
        } catch (_: Exception) {
            dateStr
        }
    }

    fun formatTime(timestamp: Long?): String {
        if (timestamp == null || timestamp == 0L) return "--:--"
        return timeFormat.format(Date(timestamp))
    }

    fun formatDateTime(timestamp: Long?): String {
        if (timestamp == null || timestamp == 0L) return "--"
        val df = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        return df.format(Date(timestamp))
    }

    fun getCurrentMonthYear(): String {
        return monthYearFormat.format(Date())
    }

    fun formatYearMonthForDisplay(yearMonth: String): String {
        return try {
            val ymFormat = SimpleDateFormat("yyyy-MM", Locale.getDefault())
            val date = ymFormat.parse(yearMonth)
            if (date != null) monthYearFormat.format(date) else yearMonth
        } catch (_: Exception) {
            yearMonth
        }
    }

    /**
     * Checks whether punch in time is considered "Late" according to threshold HH:mm (e.g. 09:15)
     */
    fun isLate(punchInTimestamp: Long, lateThreshold: String): Boolean {
        return try {
            val cal = Calendar.getInstance().apply { timeInMillis = punchInTimestamp }
            val parts = lateThreshold.split(":")
            val lateHour = parts[0].toInt()
            val lateMin = parts[1].toInt()

            val punchHour = cal.get(Calendar.HOUR_OF_DAY)
            val punchMin = cal.get(Calendar.MINUTE)

            if (punchHour > lateHour) true
            else if (punchHour == lateHour && punchMin > lateMin) true
            else false
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Checks whether current time is past the specified CutOff time HH:mm (e.g. 17:00).
     * For past dates, always returns true.
     * For future dates, returns false.
     * For today's date, checks if current time >= cutOffTime.
     */
    fun isPastCutOff(targetDateStr: String, cutOffTime: String, nowMillis: Long = System.currentTimeMillis()): Boolean {
        val today = getTodayDateString()
        if (targetDateStr < today) return true
        if (targetDateStr > today) return false
        return isPastCutOffToday(cutOffTime, nowMillis)
    }

    fun isPastCutOffToday(cutOffTime: String, nowMillis: Long = System.currentTimeMillis()): Boolean {
        return try {
            val cal = Calendar.getInstance().apply { timeInMillis = nowMillis }
            val cleanTime = cutOffTime.trim()
            val isPm = cleanTime.contains("PM", ignoreCase = true)
            val isAm = cleanTime.contains("AM", ignoreCase = true)
            val timeDigits = cleanTime.replace("PM", "", ignoreCase = true).replace("AM", "", ignoreCase = true).trim()
            val parts = timeDigits.split(":")
            var cutOffHour = parts[0].trim().toInt()
            val cutOffMin = if (parts.size > 1) parts[1].trim().toInt() else 0

            if (isPm && cutOffHour < 12) {
                cutOffHour += 12
            } else if (isAm && cutOffHour == 12) {
                cutOffHour = 0
            }

            val currentHour = cal.get(Calendar.HOUR_OF_DAY)
            val currentMin = cal.get(Calendar.MINUTE)

            if (currentHour > cutOffHour) true
            else if (currentHour == cutOffHour && currentMin >= cutOffMin) true
            else false
        } catch (_: Exception) {
            false
        }
    }

    fun getDayOfWeek(): String {
        val cal = Calendar.getInstance()
        val days = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        return days[cal.get(Calendar.DAY_OF_WEEK) - 1]
    }

    fun getYesterdayDateString(): String {
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        return dateFormat.format(cal.time)
    }

    fun getPreviousDate(dateStr: String): String {
        return try {
            val date = dateFormat.parse(dateStr) ?: return dateStr
            val cal = Calendar.getInstance().apply {
                time = date
                add(Calendar.DAY_OF_YEAR, -1)
            }
            dateFormat.format(cal.time)
        } catch (_: Exception) {
            dateStr
        }
    }

    fun getNextDate(dateStr: String): String {
        return try {
            val date = dateFormat.parse(dateStr) ?: return dateStr
            val cal = Calendar.getInstance().apply {
                time = date
                add(Calendar.DAY_OF_YEAR, 1)
            }
            dateFormat.format(cal.time)
        } catch (_: Exception) {
            dateStr
        }
    }

    fun parseDateToUtcMillis(dateStr: String): Long {
        return try {
            val parts = dateStr.split("-")
            val year = parts[0].toInt()
            val month = parts[1].toInt() - 1
            val day = parts[2].toInt()
            val cal = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).apply {
                clear()
                set(year, month, day)
            }
            cal.timeInMillis
        } catch (_: Exception) {
            System.currentTimeMillis()
        }
    }

    fun formatUtcMillisToDate(millis: Long): String {
        val cal = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).apply {
            timeInMillis = millis
        }
        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH) + 1
        val day = cal.get(Calendar.DAY_OF_MONTH)
        return String.format(Locale.getDefault(), "%04d-%02d-%02d", year, month, day)
    }

    /**
     * Checks whether the given date is marked as a holiday in InstituteSettings.
     */
    fun isHoliday(dateStr: String, holidays: List<com.example.data.model.Holiday>): Boolean {
        val clean = dateStr.replace("/", "-").trim()
        return holidays.any { it.date.replace("/", "-").trim() == clean }
    }

    /**
     * Returns the Holiday object if the given date is marked as a holiday.
     */
    fun getHolidayForDate(dateStr: String, holidays: List<com.example.data.model.Holiday>): com.example.data.model.Holiday? {
        val clean = dateStr.replace("/", "-").trim()
        return holidays.firstOrNull { it.date.replace("/", "-").trim() == clean }
    }

    /**
     * Calculates total elapsed days, actual working days (excluding non-working days and marked holidays),
     * and total holiday days in the given month up to current date (or whole month if past month).
     */
    fun calculateWorkingDays(
        yearMonthStr: String,
        workingDaysList: List<String>,
        holidays: List<com.example.data.model.Holiday>
    ): Triple<Int, Int, Int> { // (totalDaysElapsed, workingDays, holidayDays)
        return try {
            val parts = yearMonthStr.replace("/", "-").split("-")
            val y = parts.getOrNull(0)?.toIntOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)
            val m = (parts.getOrNull(1)?.toIntOrNull() ?: (Calendar.getInstance().get(Calendar.MONTH) + 1)) - 1

            val todayCal = Calendar.getInstance()
            val curY = todayCal.get(Calendar.YEAR)
            val curM = todayCal.get(Calendar.MONTH)
            val curD = todayCal.get(Calendar.DAY_OF_MONTH)

            val cal = Calendar.getInstance().apply {
                clear()
                set(Calendar.YEAR, y)
                set(Calendar.MONTH, m)
                set(Calendar.DAY_OF_MONTH, 1)
            }
            val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

            val endDay = when {
                y < curY || (y == curY && m < curM) -> daysInMonth
                y == curY && m == curM -> minOf(curD, daysInMonth)
                else -> 0
            }

            val holidayDates = holidays.map { it.date.replace("/", "-").trim() }.toSet()
            val dayNames = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
            var wDays = 0
            var hDays = 0

            for (d in 1..endDay) {
                cal.set(Calendar.DAY_OF_MONTH, d)
                val dateStr = String.format(Locale.getDefault(), "%04d-%02d-%02d", y, m + 1, d)
                val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
                val dayName = dayNames[dayOfWeek - 1]
                val isRegularWorkingDay = if (workingDaysList.isNotEmpty()) {
                    workingDaysList.contains(dayName)
                } else {
                    dayOfWeek != Calendar.SUNDAY
                }
                val isMarkedHoliday = holidayDates.contains(dateStr)

                if (isRegularWorkingDay && !isMarkedHoliday) {
                    wDays++
                } else {
                    hDays++
                }
            }
            Triple(endDay, wDays, hDays)
        } catch (_: Exception) {
            Triple(30, 26, 4)
        }
    }
}
