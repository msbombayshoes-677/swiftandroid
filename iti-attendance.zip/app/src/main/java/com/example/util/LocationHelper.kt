package com.example.util

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.os.Build
import com.example.data.model.DistanceResult
import com.example.data.model.InstituteSettings
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object LocationHelper {

    /**
     * Computes the great circle distance between two points in meters using the Haversine formula.
     */
    fun calculateDistanceMeters(
        lat1: Double,
        lon1: Double,
        lat2: Double,
        lon2: Double
    ): Double {
        val r = 6371000.0 // Earth radius in meters
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    /**
     * Checks if current GPS coordinates are within institute radius (e.g. 100 meters).
     */
    fun verifyLocation(
        currentLat: Double,
        currentLng: Double,
        settings: InstituteSettings
    ): DistanceResult {
        val distance = calculateDistanceMeters(
            lat1 = currentLat,
            lon1 = currentLng,
            lat2 = settings.latitude,
            lon2 = settings.longitude
        )
        val isInside = distance <= settings.radiusMeters

        val message = if (isInside) {
            "Inside Institute (${String.format("%.1f", distance)}m from center). Attendance Allowed."
        } else {
            "Outside Institute (${String.format("%.1f", distance)}m away). You must be within ${settings.radiusMeters.toInt()}m of the institute to mark attendance."
        }

        return DistanceResult(
            distanceMeters = distance,
            isWithinRadius = isInside,
            currentLat = currentLat,
            currentLng = currentLng,
            instituteLat = settings.latitude,
            instituteLng = settings.longitude,
            allowedRadiusMeters = settings.radiusMeters,
            statusMessage = message
        )
    }

    /**
     * Fetch current device location using FusedLocationProviderClient with high accuracy.
     */
    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(context: Context): Location? {
        val fusedClient: FusedLocationProviderClient =
            LocationServices.getFusedLocationProviderClient(context)

        return suspendCancellableCoroutine { continuation ->
            val cts = CancellationTokenSource()
            continuation.invokeOnCancellation { cts.cancel() }

            fusedClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
                .addOnSuccessListener { location: Location? ->
                    continuation.resume(location)
                }
                .addOnFailureListener {
                    // Fallback to last known location if getCurrentLocation fails
                    fusedClient.lastLocation
                        .addOnSuccessListener { lastLoc -> continuation.resume(lastLoc) }
                        .addOnFailureListener { continuation.resume(null) }
                }
        }
    }

    /**
     * Detects if mock/spoofed location was supplied.
     */
    fun isMockLocation(location: Location): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            location.isMock
        } else {
            @Suppress("DEPRECATION")
            location.isFromMockProvider
        }
    }
}
