package com.example.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.MediaStore
import android.widget.Toast
import com.example.data.model.InstructorProfile
import com.example.data.model.TraineeProfile
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PrintTableUtils {

    /**
     * Prints or exports trainees table using Android's native PdfDocument and PrintManager.
     * Zero WebView / Chromium dependency to prevent any renderer process crashes.
     */
    fun printTraineesTable(
        context: Context,
        trainees: List<TraineeProfile>,
        tradeFilterName: String = "All Trades"
    ) {
        if (trainees.isEmpty()) {
            Toast.makeText(context, "No trainees to print", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
            if (printManager != null) {
                val printAttributes = PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape())
                    .setResolution(PrintAttributes.Resolution("res1", "default", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build()

                val adapter = TraineePdfPrintDocumentAdapter(trainees, tradeFilterName)
                val safeTradeName = tradeFilterName.replace(Regex("[^a-zA-Z0-9_-]"), "_")
                val jobName = "Trainees_List_${safeTradeName}"
                printManager.print(jobName, adapter, printAttributes)
            } else {
                // Fallback: Save PDF directly to Downloads if PrintManager is not available
                val success = saveTraineesPdfToDownloads(context, trainees, tradeFilterName)
                if (success) {
                    Toast.makeText(context, "PDF saved to Downloads folder", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, "Unable to print or save PDF", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback: Save PDF directly
            val saved = saveTraineesPdfToDownloads(context, trainees, tradeFilterName)
            if (saved) {
                Toast.makeText(context, "Print service unavailable. PDF saved to Downloads.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "Print failed: ${e.localizedMessage ?: "Unknown error"}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Saves the PDF table directly into device Downloads
     */
    fun saveTraineesPdfToDownloads(
        context: Context,
        trainees: List<TraineeProfile>,
        tradeFilterName: String
    ): Boolean {
        return try {
            val safeTrade = tradeFilterName.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val filename = "Trainees_${safeTrade}_$timestamp.pdf"

            val pdfDocument = createTraineesPdf(trainees, tradeFilterName, 842, 595)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        pdfDocument.writeTo(out)
                    }
                    pdfDocument.close()
                    true
                } else {
                    pdfDocument.close()
                    false
                }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val file = File(downloadsDir, filename)
                FileOutputStream(file).use { out ->
                    pdfDocument.writeTo(out)
                }
                pdfDocument.close()
                true
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Generates a complete native Android PdfDocument with styled headers, borders, and rows
     */
    fun createTraineesPdf(
        trainees: List<TraineeProfile>,
        tradeFilterName: String,
        pageWidth: Int = 842,
        pageHeight: Int = 595
    ): PdfDocument {
        val pdfDocument = PdfDocument()

        val marginX = 30f
        val marginY = 25f
        val tableWidth = pageWidth - (marginX * 2)

        // Column widths for Landscape A4 (total tableWidth ~ 782pt)
        val colSno = 35f
        val colName = 140f
        val colParentage = 110f
        val colAddress = 167f
        val colContact = 105f
        val colFatherContact = 110f
        val colTrade = 115f

        val colWidths = floatArrayOf(colSno, colName, colParentage, colAddress, colContact, colFatherContact, colTrade)
        val colHeaders = arrayOf("S.No", "Name", "Parentage", "Address", "Contact No", "Father's Contact", "Trade")

        val titlePaint = Paint().apply {
            color = Color.rgb(0, 51, 102) // #003366 Navy
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val subTitlePaint = Paint().apply {
            color = Color.rgb(70, 70, 70)
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val metaPaint = Paint().apply {
            color = Color.rgb(30, 30, 30)
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val thBgPaint = Paint().apply {
            color = Color.rgb(235, 242, 250) // Light navy tint
            style = Paint.Style.FILL
        }

        val thTextPaint = Paint().apply {
            color = Color.rgb(0, 51, 102)
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val evenRowBgPaint = Paint().apply {
            color = Color.rgb(250, 250, 250)
            style = Paint.Style.FILL
        }

        val borderPaint = Paint().apply {
            color = Color.rgb(180, 180, 180)
            style = Paint.Style.STROKE
            strokeWidth = 0.75f
        }

        val textPaint = Paint().apply {
            color = Color.rgb(30, 30, 30)
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val textBoldPaint = Paint().apply {
            color = Color.rgb(20, 20, 20)
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val idPaint = Paint().apply {
            color = Color.rgb(80, 80, 80)
            textSize = 7.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val rowHeight = 22f
        val headerRowHeight = 22f
        val dateStr = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date())

        val topHeaderHeight = 65f
        val footerHeight = 25f
        val availableHeightFirstPage = pageHeight - marginY - topHeaderHeight - headerRowHeight - footerHeight - marginY
        val availableHeightOtherPages = pageHeight - marginY - 30f - headerRowHeight - footerHeight - marginY

        val rowsFirstPage = maxOf(1, (availableHeightFirstPage / rowHeight).toInt())
        val rowsOtherPages = maxOf(1, (availableHeightOtherPages / rowHeight).toInt())

        val totalPages = if (trainees.size <= rowsFirstPage) {
            1
        } else {
            1 + Math.ceil((trainees.size - rowsFirstPage).toDouble() / rowsOtherPages).toInt()
        }

        var traineeIndex = 0

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            var currentY = marginY

            if (pageIndex == 0) {
                // Main Header Banner
                canvas.drawText("GOVT. INDUSTRIAL TRAINING INSTITUTE ANANTNAG", marginX, currentY + 14f, titlePaint)
                canvas.drawText("Trainee Directory & Contact Register • Trade: $tradeFilterName • Total Trainees: ${trainees.size}", marginX, currentY + 28f, subTitlePaint)

                // Meta row
                canvas.drawText("Printed on: $dateStr", tableWidth + marginX - 180f, currentY + 28f, idPaint)

                // Divider
                canvas.drawLine(marginX, currentY + 36f, marginX + tableWidth, currentY + 36f, borderPaint)
                currentY += 46f
            } else {
                // Secondary Page Header
                canvas.drawText("Govt. ITI Anantnag — Trainee Register ($tradeFilterName) — Page ${pageIndex + 1} of $totalPages", marginX, currentY + 12f, subTitlePaint)
                canvas.drawLine(marginX, currentY + 18f, marginX + tableWidth, currentY + 18f, borderPaint)
                currentY += 24f
            }

            // Draw Table Header
            val thTop = currentY
            val thBottom = thTop + headerRowHeight
            canvas.drawRect(marginX, thTop, marginX + tableWidth, thBottom, thBgPaint)
            canvas.drawRect(marginX, thTop, marginX + tableWidth, thBottom, borderPaint)

            var headerX = marginX
            for (i in colHeaders.indices) {
                val colW = colWidths[i]
                val textX = headerX + 5f
                val textY = thTop + 14f
                canvas.drawText(colHeaders[i], textX, textY, thTextPaint)

                if (i > 0) {
                    canvas.drawLine(headerX, thTop, headerX, thBottom, borderPaint)
                }
                headerX += colW
            }

            currentY = thBottom

            // Draw Data Rows
            val maxRowsThisPage = if (pageIndex == 0) rowsFirstPage else rowsOtherPages
            var rowsDrawn = 0

            while (traineeIndex < trainees.size && rowsDrawn < maxRowsThisPage) {
                val t = trainees[traineeIndex]
                val rowTop = currentY
                val rowBottom = rowTop + rowHeight

                // Alternating row background
                if (traineeIndex % 2 == 1) {
                    canvas.drawRect(marginX, rowTop, marginX + tableWidth, rowBottom, evenRowBgPaint)
                }
                canvas.drawRect(marginX, rowTop, marginX + tableWidth, rowBottom, borderPaint)

                var cellX = marginX

                // 1. S.No
                canvas.drawText("${traineeIndex + 1}", cellX + 6f, rowTop + 14f, textPaint)
                cellX += colWidths[0]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 2. Name & Trainee ID
                val displayName = clipText(t.name.ifBlank { "-" }, textBoldPaint, colWidths[1] - 8f)
                canvas.drawText(displayName, cellX + 4f, rowTop + 13f, textBoldPaint)
                cellX += colWidths[1]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 3. Parentage
                val parentage = clipText(t.parentage.ifBlank { "-" }, textPaint, colWidths[2] - 8f)
                canvas.drawText(parentage, cellX + 4f, rowTop + 14f, textPaint)
                cellX += colWidths[2]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 4. Address
                val address = clipText(t.address.ifBlank { "-" }, textPaint, colWidths[3] - 8f)
                canvas.drawText(address, cellX + 4f, rowTop + 14f, textPaint)
                cellX += colWidths[3]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 5. Contact No
                val contact = clipText(t.contact.ifBlank { "-" }, textPaint, colWidths[4] - 8f)
                canvas.drawText(contact, cellX + 4f, rowTop + 14f, textPaint)
                cellX += colWidths[4]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 6. Father's Contact No
                val fatherContact = clipText(t.guardianContact.ifBlank { "-" }, textPaint, colWidths[5] - 8f)
                canvas.drawText(fatherContact, cellX + 4f, rowTop + 14f, textPaint)
                cellX += colWidths[5]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 7. Trade
                val tradeName = clipText(t.tradeName.ifBlank { "-" }, textPaint, colWidths[6] - 8f)
                canvas.drawText(tradeName, cellX + 4f, rowTop + 14f, textPaint)

                currentY = rowBottom
                traineeIndex++
                rowsDrawn++
            }

            // Footer
            val footerY = pageHeight - marginY
            canvas.drawText("Generated from ITI Attendance App", marginX, footerY, idPaint)
            val pageNumStr = "Page ${pageIndex + 1} of $totalPages"
            val pageNumWidth = idPaint.measureText(pageNumStr)
            canvas.drawText(pageNumStr, marginX + tableWidth - pageNumWidth, footerY, idPaint)

            pdfDocument.finishPage(page)
        }

        return pdfDocument
    }

    private fun clipText(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var clipped = text
        while (clipped.isNotEmpty() && paint.measureText("$clipped...") > maxWidth) {
            clipped = clipped.dropLast(1)
        }
        return if (clipped.isEmpty()) "" else "$clipped..."
    }

    /**
     * Native Android PrintDocumentAdapter implementation
     */
    private class TraineePdfPrintDocumentAdapter(
        private val trainees: List<TraineeProfile>,
        private val tradeFilterName: String
    ) : PrintDocumentAdapter() {

        private var totalPages = 1
        private val pageWidth = 842
        private val pageHeight = 595

        override fun onLayout(
            oldAttributes: PrintAttributes?,
            newAttributes: PrintAttributes,
            cancellationSignal: CancellationSignal?,
            callback: LayoutResultCallback,
            extras: Bundle?
        ) {
            if (cancellationSignal?.isCanceled == true) {
                callback.onLayoutCancelled()
                return
            }

            // Estimate pages
            val rowsFirstPage = 18
            val rowsOtherPages = 20
            totalPages = if (trainees.size <= rowsFirstPage) {
                1
            } else {
                1 + Math.ceil((trainees.size - rowsFirstPage).toDouble() / rowsOtherPages).toInt()
            }

            val safeTrade = tradeFilterName.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val info = PrintDocumentInfo.Builder("Trainees_$safeTrade.pdf")
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(totalPages)
                .build()

            callback.onLayoutFinished(info, true)
        }

        override fun onWrite(
            pages: Array<out PageRange>?,
            destination: ParcelFileDescriptor?,
            cancellationSignal: CancellationSignal?,
            callback: WriteResultCallback
        ) {
            if (destination == null) {
                callback.onWriteFailed("Destination is null")
                return
            }

            var pdfDocument: PdfDocument? = null
            try {
                pdfDocument = createTraineesPdf(trainees, tradeFilterName, pageWidth, pageHeight)

                if (cancellationSignal?.isCanceled == true) {
                    callback.onWriteCancelled()
                    return
                }

                FileOutputStream(destination.fileDescriptor).use { output ->
                    pdfDocument.writeTo(output)
                }

                callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            } catch (e: Exception) {
                e.printStackTrace()
                callback.onWriteFailed(e.message)
            } finally {
                pdfDocument?.close()
            }
        }
    }

    /**
     * Prints or exports instructors table using Android's native PdfDocument and PrintManager.
     */
    fun printInstructorsTable(
        context: Context,
        items: List<InstructorPrintItem>,
        tradeFilterName: String = "All Trades"
    ) {
        if (items.isEmpty()) {
            Toast.makeText(context, "No instructors to print", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
            if (printManager != null) {
                val printAttributes = PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape())
                    .setResolution(PrintAttributes.Resolution("res1", "default", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build()

                val adapter = InstructorPdfPrintDocumentAdapter(items, tradeFilterName)
                val safeTradeName = tradeFilterName.replace(Regex("[^a-zA-Z0-9_-]"), "_")
                val jobName = "Instructors_List_${safeTradeName}"
                printManager.print(jobName, adapter, printAttributes)
            } else {
                val success = saveInstructorsPdfToDownloads(context, items, tradeFilterName)
                if (success) {
                    Toast.makeText(context, "PDF saved to Downloads folder", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, "Unable to print or save PDF", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            val saved = saveInstructorsPdfToDownloads(context, items, tradeFilterName)
            if (saved) {
                Toast.makeText(context, "Print service unavailable. PDF saved to Downloads.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "Print failed: ${e.localizedMessage ?: "Unknown error"}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Saves the instructor PDF table directly into device Downloads
     */
    fun saveInstructorsPdfToDownloads(
        context: Context,
        items: List<InstructorPrintItem>,
        tradeFilterName: String
    ): Boolean {
        return try {
            val safeTrade = tradeFilterName.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val filename = "Instructors_${safeTrade}_$timestamp.pdf"

            val pdfDocument = createInstructorsPdf(items, tradeFilterName, 842, 595)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        pdfDocument.writeTo(out)
                    }
                    pdfDocument.close()
                    true
                } else {
                    pdfDocument.close()
                    false
                }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val file = File(downloadsDir, filename)
                FileOutputStream(file).use { out ->
                    pdfDocument.writeTo(out)
                }
                pdfDocument.close()
                true
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Generates a native Android PdfDocument for Instructors
     */
    fun createInstructorsPdf(
        items: List<InstructorPrintItem>,
        tradeFilterName: String,
        pageWidth: Int = 842,
        pageHeight: Int = 595
    ): PdfDocument {
        val pdfDocument = PdfDocument()

        val marginX = 30f
        val marginY = 25f
        val tableWidth = pageWidth - (marginX * 2)

        // Columns: Sno (35), Name (160), Email (190), Trade (140), Contact No (120), No of Register Trainees (137)
        val colWidths = floatArrayOf(35f, 160f, 190f, 140f, 120f, 137f)
        val colHeaders = arrayOf("S.No", "Name", "Email", "Trade", "Contact No", "No of Register Trainees")

        val titlePaint = Paint().apply {
            color = Color.rgb(0, 51, 102)
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val subTitlePaint = Paint().apply {
            color = Color.rgb(70, 70, 70)
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val thBgPaint = Paint().apply {
            color = Color.rgb(235, 242, 250)
            style = Paint.Style.FILL
        }

        val thTextPaint = Paint().apply {
            color = Color.rgb(0, 51, 102)
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val evenRowBgPaint = Paint().apply {
            color = Color.rgb(250, 250, 250)
            style = Paint.Style.FILL
        }

        val borderPaint = Paint().apply {
            color = Color.rgb(180, 180, 180)
            style = Paint.Style.STROKE
            strokeWidth = 0.75f
        }

        val textPaint = Paint().apply {
            color = Color.rgb(30, 30, 30)
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val textBoldPaint = Paint().apply {
            color = Color.rgb(20, 20, 20)
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val idPaint = Paint().apply {
            color = Color.rgb(80, 80, 80)
            textSize = 7.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val rowHeight = 22f
        val headerRowHeight = 22f
        val dateStr = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date())

        val topHeaderHeight = 65f
        val footerHeight = 25f
        val availableHeightFirstPage = pageHeight - marginY - topHeaderHeight - headerRowHeight - footerHeight - marginY
        val availableHeightOtherPages = pageHeight - marginY - 30f - headerRowHeight - footerHeight - marginY

        val rowsFirstPage = maxOf(1, (availableHeightFirstPage / rowHeight).toInt())
        val rowsOtherPages = maxOf(1, (availableHeightOtherPages / rowHeight).toInt())

        val totalPages = if (items.size <= rowsFirstPage) {
            1
        } else {
            1 + Math.ceil((items.size - rowsFirstPage).toDouble() / rowsOtherPages).toInt()
        }

        var itemIndex = 0

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            var currentY = marginY

            if (pageIndex == 0) {
                // Header Banner
                canvas.drawText("GOVT. INDUSTRIAL TRAINING INSTITUTE ANANTNAG", marginX, currentY + 14f, titlePaint)
                canvas.drawText("Instructor Directory & Staff Register • Trade: $tradeFilterName • Total Instructors: ${items.size}", marginX, currentY + 28f, subTitlePaint)
                canvas.drawText("Printed on: $dateStr", tableWidth + marginX - 180f, currentY + 28f, idPaint)
                canvas.drawLine(marginX, currentY + 36f, marginX + tableWidth, currentY + 36f, borderPaint)
                currentY += 46f
            } else {
                canvas.drawText("Govt. ITI Anantnag — Instructor Register ($tradeFilterName) — Page ${pageIndex + 1} of $totalPages", marginX, currentY + 12f, subTitlePaint)
                canvas.drawLine(marginX, currentY + 18f, marginX + tableWidth, currentY + 18f, borderPaint)
                currentY += 24f
            }

            // Draw Table Header
            val thTop = currentY
            val thBottom = thTop + headerRowHeight
            canvas.drawRect(marginX, thTop, marginX + tableWidth, thBottom, thBgPaint)
            canvas.drawRect(marginX, thTop, marginX + tableWidth, thBottom, borderPaint)

            var headerX = marginX
            for (i in colHeaders.indices) {
                val colW = colWidths[i]
                val textX = headerX + 5f
                val textY = thTop + 14f
                canvas.drawText(colHeaders[i], textX, textY, thTextPaint)

                if (i > 0) {
                    canvas.drawLine(headerX, thTop, headerX, thBottom, borderPaint)
                }
                headerX += colW
            }

            currentY = thBottom

            val maxRowsThisPage = if (pageIndex == 0) rowsFirstPage else rowsOtherPages
            var rowsDrawn = 0

            while (itemIndex < items.size && rowsDrawn < maxRowsThisPage) {
                val rowItem = items[itemIndex]
                val inst = rowItem.instructor
                val rowTop = currentY
                val rowBottom = rowTop + rowHeight

                if (itemIndex % 2 == 1) {
                    canvas.drawRect(marginX, rowTop, marginX + tableWidth, rowBottom, evenRowBgPaint)
                }
                canvas.drawRect(marginX, rowTop, marginX + tableWidth, rowBottom, borderPaint)

                var cellX = marginX

                // 1. S.No
                canvas.drawText("${itemIndex + 1}", cellX + 6f, rowTop + 14f, textPaint)
                cellX += colWidths[0]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 2. Name
                val displayName = clipText(inst.name.ifBlank { "-" }, textBoldPaint, colWidths[1] - 8f)
                canvas.drawText(displayName, cellX + 4f, rowTop + 14f, textBoldPaint)
                cellX += colWidths[1]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 3. Email
                val email = clipText(inst.email.ifBlank { "-" }, textPaint, colWidths[2] - 8f)
                canvas.drawText(email, cellX + 4f, rowTop + 14f, textPaint)
                cellX += colWidths[2]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 4. Trade
                val tradeName = clipText(inst.tradeName.ifBlank { "-" }, textPaint, colWidths[3] - 8f)
                canvas.drawText(tradeName, cellX + 4f, rowTop + 14f, textPaint)
                cellX += colWidths[3]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 5. Contact No
                val contact = clipText(inst.contact.ifBlank { "-" }, textPaint, colWidths[4] - 8f)
                canvas.drawText(contact, cellX + 4f, rowTop + 14f, textPaint)
                cellX += colWidths[4]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 6. No of Register Trainees
                val traineesCountStr = "${rowItem.registeredTraineesCount} Trainees"
                val traineesText = clipText(traineesCountStr, textBoldPaint, colWidths[5] - 8f)
                canvas.drawText(traineesText, cellX + 4f, rowTop + 14f, textBoldPaint)

                currentY = rowBottom
                itemIndex++
                rowsDrawn++
            }

            // Footer
            val footerY = pageHeight - marginY
            canvas.drawText("Generated from ITI Attendance App", marginX, footerY, idPaint)
            val pageNumStr = "Page ${pageIndex + 1} of $totalPages"
            val pageNumWidth = idPaint.measureText(pageNumStr)
            canvas.drawText(pageNumStr, marginX + tableWidth - pageNumWidth, footerY, idPaint)

            pdfDocument.finishPage(page)
        }

        return pdfDocument
    }

    /**
     * Native PrintDocumentAdapter for Instructors table
     */
    private class InstructorPdfPrintDocumentAdapter(
        private val items: List<InstructorPrintItem>,
        private val tradeFilterName: String
    ) : PrintDocumentAdapter() {

        private var totalPages = 1
        private val pageWidth = 842
        private val pageHeight = 595

        override fun onLayout(
            oldAttributes: PrintAttributes?,
            newAttributes: PrintAttributes,
            cancellationSignal: CancellationSignal?,
            callback: LayoutResultCallback,
            extras: Bundle?
        ) {
            if (cancellationSignal?.isCanceled == true) {
                callback.onLayoutCancelled()
                return
            }

            val rowsFirstPage = 18
            val rowsOtherPages = 20
            totalPages = if (items.size <= rowsFirstPage) {
                1
            } else {
                1 + Math.ceil((items.size - rowsFirstPage).toDouble() / rowsOtherPages).toInt()
            }

            val safeTrade = tradeFilterName.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val info = PrintDocumentInfo.Builder("Instructors_$safeTrade.pdf")
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(totalPages)
                .build()

            callback.onLayoutFinished(info, true)
        }

        override fun onWrite(
            pages: Array<out PageRange>?,
            destination: ParcelFileDescriptor?,
            cancellationSignal: CancellationSignal?,
            callback: WriteResultCallback
        ) {
            if (destination == null) {
                callback.onWriteFailed("Destination is null")
                return
            }

            var pdfDocument: PdfDocument? = null
            try {
                pdfDocument = createInstructorsPdf(items, tradeFilterName, pageWidth, pageHeight)

                if (cancellationSignal?.isCanceled == true) {
                    callback.onWriteCancelled()
                    return
                }

                FileOutputStream(destination.fileDescriptor).use { output ->
                    pdfDocument.writeTo(output)
                }

                callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            } catch (e: Exception) {
                e.printStackTrace()
                callback.onWriteFailed(e.message)
            } finally {
                pdfDocument?.close()
            }
        }
    }

    /**
     * Prints or exports trades table using Android's native PdfDocument and PrintManager.
     */
    fun printTradesTable(
        context: Context,
        items: List<TradePrintItem>,
        instructorFilterName: String = "All Instructors"
    ) {
        if (items.isEmpty()) {
            Toast.makeText(context, "No trades to print", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
            if (printManager != null) {
                val printAttributes = PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape())
                    .setResolution(PrintAttributes.Resolution("res1", "default", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build()

                val adapter = TradePdfPrintDocumentAdapter(items, instructorFilterName)
                val safeInstructorName = instructorFilterName.replace(Regex("[^a-zA-Z0-9_-]"), "_")
                val jobName = "Trades_List_${safeInstructorName}"
                printManager.print(jobName, adapter, printAttributes)
            } else {
                Toast.makeText(context, "Print service is unavailable on this device", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Print error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Saves trades PDF file directly to Downloads directory without requiring WebView.
     */
    fun saveTradesPdfToDownloads(
        context: Context,
        items: List<TradePrintItem>,
        instructorFilterName: String = "All Instructors"
    ): Boolean {
        if (items.isEmpty()) return false

        return try {
            val pdfDocument = createTradesPdf(items, instructorFilterName)
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val safeFilter = instructorFilterName.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val filename = "ITI_Trades_${safeFilter}_$timeStamp.pdf"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { out ->
                        pdfDocument.writeTo(out)
                    }
                    pdfDocument.close()
                    true
                } else {
                    pdfDocument.close()
                    false
                }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val file = File(downloadsDir, filename)
                FileOutputStream(file).use { out ->
                    pdfDocument.writeTo(out)
                }
                pdfDocument.close()
                true
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Generates a native Android PdfDocument for Trades
     */
    fun createTradesPdf(
        items: List<TradePrintItem>,
        instructorFilterName: String,
        pageWidth: Int = 842,
        pageHeight: Int = 595
    ): PdfDocument {
        val pdfDocument = PdfDocument()

        val marginX = 30f
        val marginY = 25f
        val tableWidth = pageWidth - (marginX * 2)

        // Columns: Sno (30), Trade (135), Trade Code (75), Duration (72), Incharge Instructor (135), Email (145), Contact No (100), No. Of Trainees (90) = 782 total width
        val colWidths = floatArrayOf(30f, 135f, 75f, 72f, 135f, 145f, 100f, 90f)
        val colHeaders = arrayOf("Sno", "Trade", "Trade Code", "Duration", "Incharge Instructor", "Email", "Contact No", "No. Of Trainees")

        val titlePaint = Paint().apply {
            color = Color.rgb(0, 51, 102)
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val subTitlePaint = Paint().apply {
            color = Color.rgb(70, 70, 70)
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val thBgPaint = Paint().apply {
            color = Color.rgb(235, 242, 250)
            style = Paint.Style.FILL
        }

        val thTextPaint = Paint().apply {
            color = Color.rgb(0, 51, 102)
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val evenRowBgPaint = Paint().apply {
            color = Color.rgb(250, 250, 250)
            style = Paint.Style.FILL
        }

        val borderPaint = Paint().apply {
            color = Color.rgb(180, 180, 180)
            style = Paint.Style.STROKE
            strokeWidth = 0.75f
        }

        val textPaint = Paint().apply {
            color = Color.rgb(30, 30, 30)
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val textBoldPaint = Paint().apply {
            color = Color.rgb(20, 20, 20)
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val idPaint = Paint().apply {
            color = Color.rgb(80, 80, 80)
            textSize = 7.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val rowHeight = 22f
        val headerRowHeight = 22f
        val dateStr = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date())

        val topHeaderHeight = 65f
        val footerHeight = 25f
        val availableHeightFirstPage = pageHeight - marginY - topHeaderHeight - headerRowHeight - footerHeight - marginY
        val availableHeightOtherPages = pageHeight - marginY - 30f - headerRowHeight - footerHeight - marginY

        val rowsFirstPage = maxOf(1, (availableHeightFirstPage / rowHeight).toInt())
        val rowsOtherPages = maxOf(1, (availableHeightOtherPages / rowHeight).toInt())

        val totalPages = if (items.size <= rowsFirstPage) {
            1
        } else {
            1 + Math.ceil((items.size - rowsFirstPage).toDouble() / rowsOtherPages).toInt()
        }

        var itemIndex = 0

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            var currentY = marginY

            if (pageIndex == 0) {
                // Header Banner
                canvas.drawText("GOVT. INDUSTRIAL TRAINING INSTITUTE ANANTNAG", marginX, currentY + 14f, titlePaint)
                canvas.drawText("Trade Register & Incharge Details • Instructor: $instructorFilterName • Total Trades: ${items.size}", marginX, currentY + 28f, subTitlePaint)
                canvas.drawText("Printed on: $dateStr", tableWidth + marginX - 180f, currentY + 28f, idPaint)
                canvas.drawLine(marginX, currentY + 36f, marginX + tableWidth, currentY + 36f, borderPaint)
                currentY += 46f
            } else {
                canvas.drawText("Govt. ITI Anantnag — Trades & Incharge Register ($instructorFilterName) — Page ${pageIndex + 1} of $totalPages", marginX, currentY + 12f, subTitlePaint)
                canvas.drawLine(marginX, currentY + 18f, marginX + tableWidth, currentY + 18f, borderPaint)
                currentY += 24f
            }

            // Draw Table Header
            val thTop = currentY
            val thBottom = thTop + headerRowHeight
            canvas.drawRect(marginX, thTop, marginX + tableWidth, thBottom, thBgPaint)
            canvas.drawRect(marginX, thTop, marginX + tableWidth, thBottom, borderPaint)

            var headerX = marginX
            for (i in colHeaders.indices) {
                val colW = colWidths[i]
                val textX = headerX + 5f
                val textY = thTop + 14f
                canvas.drawText(colHeaders[i], textX, textY, thTextPaint)

                if (i > 0) {
                    canvas.drawLine(headerX, thTop, headerX, thBottom, borderPaint)
                }
                headerX += colW
            }

            currentY = thBottom

            val maxRowsThisPage = if (pageIndex == 0) rowsFirstPage else rowsOtherPages
            var rowsDrawn = 0

            while (itemIndex < items.size && rowsDrawn < maxRowsThisPage) {
                val rowItem = items[itemIndex]
                val rowTop = currentY
                val rowBottom = rowTop + rowHeight

                if (itemIndex % 2 == 1) {
                    canvas.drawRect(marginX, rowTop, marginX + tableWidth, rowBottom, evenRowBgPaint)
                }
                canvas.drawRect(marginX, rowTop, marginX + tableWidth, rowBottom, borderPaint)

                var cellX = marginX

                // 1. Sno
                canvas.drawText("${itemIndex + 1}", cellX + 6f, rowTop + 14f, textPaint)
                cellX += colWidths[0]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 2. Trade
                val tradeName = clipText(rowItem.trade.tradeName.ifBlank { "-" }, textBoldPaint, colWidths[1] - 8f)
                canvas.drawText(tradeName, cellX + 4f, rowTop + 14f, textBoldPaint)
                cellX += colWidths[1]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 3. Trade Code
                val tradeCode = clipText(rowItem.trade.tradeCode.ifBlank { "-" }, textPaint, colWidths[2] - 8f)
                canvas.drawText(tradeCode, cellX + 4f, rowTop + 14f, textPaint)
                cellX += colWidths[2]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 4. Duration
                val duration = clipText(rowItem.trade.duration.ifBlank { "-" }, textPaint, colWidths[3] - 8f)
                canvas.drawText(duration, cellX + 4f, rowTop + 14f, textPaint)
                cellX += colWidths[3]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 5. Incharge Instructor
                val incharge = clipText(rowItem.inchargeInstructorName.ifBlank { "Unassigned" }, textPaint, colWidths[4] - 8f)
                canvas.drawText(incharge, cellX + 4f, rowTop + 14f, textPaint)
                cellX += colWidths[4]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 6. Email
                val email = clipText(rowItem.email.ifBlank { "-" }, textPaint, colWidths[5] - 8f)
                canvas.drawText(email, cellX + 4f, rowTop + 14f, textPaint)
                cellX += colWidths[5]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 7. Contact No
                val contact = clipText(rowItem.contactNo.ifBlank { "-" }, textPaint, colWidths[6] - 8f)
                canvas.drawText(contact, cellX + 4f, rowTop + 14f, textPaint)
                cellX += colWidths[6]
                canvas.drawLine(cellX, rowTop, cellX, rowBottom, borderPaint)

                // 8. No. Of Trainees
                val traineesCountStr = "${rowItem.traineesCount} Trainees"
                val traineesText = clipText(traineesCountStr, textBoldPaint, colWidths[7] - 8f)
                canvas.drawText(traineesText, cellX + 4f, rowTop + 14f, textBoldPaint)

                currentY = rowBottom
                itemIndex++
                rowsDrawn++
            }

            // Footer
            val footerY = pageHeight - marginY
            canvas.drawText("Generated from ITI Attendance App", marginX, footerY, idPaint)
            val pageNumStr = "Page ${pageIndex + 1} of $totalPages"
            val pageNumWidth = idPaint.measureText(pageNumStr)
            canvas.drawText(pageNumStr, marginX + tableWidth - pageNumWidth, footerY, idPaint)

            pdfDocument.finishPage(page)
        }

        return pdfDocument
    }

    private class TradePdfPrintDocumentAdapter(
        private val items: List<TradePrintItem>,
        private val instructorFilterName: String
    ) : PrintDocumentAdapter() {

        private var pageWidth = 842
        private var pageHeight = 595

        override fun onLayout(
            oldAttributes: PrintAttributes?,
            newAttributes: PrintAttributes?,
            cancellationSignal: CancellationSignal?,
            callback: LayoutResultCallback,
            metadata: Bundle?
        ) {
            if (cancellationSignal?.isCanceled == true) {
                callback.onLayoutCancelled()
                return
            }

            val marginY = 25f
            val topHeaderHeight = 65f
            val headerRowHeight = 22f
            val footerHeight = 25f
            val rowHeight = 22f

            val availableHeightFirstPage = pageHeight - marginY - topHeaderHeight - headerRowHeight - footerHeight - marginY
            val availableHeightOtherPages = pageHeight - marginY - 30f - headerRowHeight - footerHeight - marginY

            val rowsFirstPage = maxOf(1, (availableHeightFirstPage / rowHeight).toInt())
            val rowsOtherPages = maxOf(1, (availableHeightOtherPages / rowHeight).toInt())

            val totalPages = if (items.size <= rowsFirstPage) {
                1
            } else {
                1 + Math.ceil((items.size - rowsFirstPage).toDouble() / rowsOtherPages).toInt()
            }

            val safeInstructor = instructorFilterName.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val info = PrintDocumentInfo.Builder("Trades_$safeInstructor.pdf")
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(totalPages)
                .build()

            callback.onLayoutFinished(info, true)
        }

        override fun onWrite(
            pages: Array<out PageRange>?,
            destination: ParcelFileDescriptor?,
            cancellationSignal: CancellationSignal?,
            callback: WriteResultCallback
        ) {
            if (destination == null) {
                callback.onWriteFailed("Destination is null")
                return
            }

            var pdfDocument: PdfDocument? = null
            try {
                pdfDocument = createTradesPdf(items, instructorFilterName, pageWidth, pageHeight)

                if (cancellationSignal?.isCanceled == true) {
                    callback.onWriteCancelled()
                    return
                }

                FileOutputStream(destination.fileDescriptor).use { output ->
                    pdfDocument.writeTo(output)
                }

                callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            } catch (e: Exception) {
                e.printStackTrace()
                callback.onWriteFailed(e.message)
            } finally {
                pdfDocument?.close()
            }
        }
    }
}

/**
 * Data item representing an Instructor and the count of registered trainees in their trade
 */
data class InstructorPrintItem(
    val instructor: InstructorProfile,
    val registeredTraineesCount: Int
)

/**
 * Data item representing a Trade with incharge instructor details and trainee count
 */
data class TradePrintItem(
    val trade: com.example.data.model.Trade,
    val inchargeInstructorName: String,
    val email: String,
    val contactNo: String,
    val traineesCount: Int,
    val instructorId: String = ""
)
