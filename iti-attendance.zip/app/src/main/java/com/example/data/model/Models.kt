package com.example.data.model

enum class UserRole(val roleName: String, val displayName: String) {
    ADMIN("admin", "Institute"),
    INSTRUCTOR("instructor", "Instructor"),
    TRAINEE("trainee", "Trainee"),
    PARENT("parent", "Parent");

    companion object {
        fun fromString(role: String?): UserRole {
            return entries.find { it.roleName.equals(role, ignoreCase = true) } ?: TRAINEE
        }
    }
}

enum class AccountStatus(val statusName: String) {
    PENDING("pending"),
    APPROVED("approved"),
    REJECTED("rejected"),
    INACTIVE("inactive");

    companion object {
        fun fromString(status: String?): AccountStatus {
            return entries.find { it.statusName.equals(status, ignoreCase = true) } ?: PENDING
        }
    }
}

enum class AttendanceStatus(val statusName: String, val displayName: String) {
    PRESENT("present", "Present"),
    LATE("late", "Late"),
    ABSENT("absent", "Absent"),
    HALF_DAY("half_day", "Half Day"),
    LEAVE("leave", "Leave"),
    NOT_MARKED("not_marked", "Not Marked");

    companion object {
        fun fromString(status: String?): AttendanceStatus {
            return entries.find { it.statusName.equals(status, ignoreCase = true) } ?: NOT_MARKED
        }
    }
}

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val role: String = "trainee",
    val status: String = "pending",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class AdminProfile(
    val uid: String = "",
    val name: String = "Admin",
    val email: String = "",
    val role: String = "admin",
    val status: String = "approved",
    val createdAt: Long = System.currentTimeMillis()
)

data class InstructorProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val contact: String = "",
    val tradeId: String = "",
    val tradeName: String = "",
    val role: String = "instructor",
    val status: String = "pending",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val approvedAt: Long? = null,
    val approvedBy: String? = null
)

data class TraineeProfile(
    val uid: String = "",
    val traineeId: String = "", // e.g. ITI-2026-00001
    val name: String = "",
    val parentage: String = "",
    val guardianContact: String = "", // Father / Guardian contact number
    val email: String = "",
    val contact: String = "",
    val address: String = "",
    val tradeId: String = "",
    val tradeName: String = "",
    val instructorId: String = "",
    val instructorName: String = "",
    val role: String = "trainee",
    val status: String = "pending",
    val rejectionReason: String? = null,
    val parentAccessPin: String = "1234", // Controlled parent access PIN
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val approvedAt: Long? = null,
    val approvedBy: String? = null
)

data class Trade(
    val tradeId: String = "",
    val tradeName: String = "",
    val tradeCode: String = "",
    val scheme: String = "CTS", // CTS, Self Finance, PMKVY, Other
    val duration: String = "1 Year",
    val status: String = "active", // active, inactive
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class AttendanceRecord(
    val attendanceId: String = "",
    val traineeId: String = "", // Document UID or user UID
    val traineeUniqueId: String = "", // formatted ID e.g. ITI-2026-00001
    val traineeName: String = "",
    val tradeId: String = "",
    val tradeName: String = "",
    val instructorId: String = "",
    val date: String = "", // YYYY-MM-DD
    val punchInTime: Long? = null,
    val punchOutTime: Long? = null,
    val punchInLatitude: Double? = null,
    val punchInLongitude: Double? = null,
    val punchOutLatitude: Double? = null,
    val punchOutLongitude: Double? = null,
    val punchInDistance: Double? = null,
    val punchOutDistance: Double? = null,
    val attendanceStatus: String = "not_marked", // present, late, absent, half_day, leave
    val remarks: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class Holiday(
    val holidayId: String = "",
    val date: String = "", // yyyy-MM-dd
    val name: String = "",
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val createdBy: String = "Admin"
)

data class InstituteSettings(
    val settingsId: String = "default",
    val instituteName: String = "Government ITI Anantnag",
    val instituteAddress: String = "ITI Anantnag Campus, Anantnag, J&K",
    val latitude: Double = 33.7314, // Default coordinates
    val longitude: Double = 75.1487,
    val radiusMeters: Double = 100.0, // Strict 100 meters attendance radius
    val reportingTime: String = "09:00", // HH:mm
    val lateTimeThreshold: String = "09:15", // HH:mm
    val cutOffTime: String = "17:00", // HH:mm - After cutoff time, unmarked trainees become Absent
    val workingDays: List<String> = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"),
    val holidays: List<Holiday> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis(),
    val updatedBy: String = "Admin"
)

data class AttendanceCorrection(
    val correctionId: String = "",
    val attendanceId: String = "",
    val traineeId: String = "",
    val traineeUniqueId: String = "",
    val traineeName: String = "",
    val date: String = "",
    val correctedBy: String = "",
    val correctedByName: String = "",
    val correctedByRole: String = "",
    val oldValue: String = "",
    val newValue: String = "",
    val reason: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class InstituteNotification(
    val notificationId: String = "",
    val title: String = "",
    val message: String = "",
    val targetRole: String = "all", // all, admin, instructor, trainee, parent
    val targetTradeId: String? = null,
    val targetUserId: String? = null,
    val senderName: String = "Institute Administration",
    val senderRole: String? = "admin", // admin, instructor
    val senderUserId: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

data class AuditLogEntry(
    val logId: String = "",
    val action: String = "",
    val performedBy: String = "",
    val performedByName: String = "",
    val performedByRole: String = "",
    val targetId: String = "",
    val targetType: String = "", // trade, instructor, trainee, attendance, settings
    val oldValue: String? = null,
    val newValue: String? = null,
    val reason: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class DashboardStats(
    val totalTrades: Int = 0,
    val totalInstructors: Int = 0,
    val totalTrainees: Int = 0,
    val presentToday: Int = 0,
    val absentToday: Int = 0,
    val lateToday: Int = 0,
    val halfDayToday: Int = 0,
    val leaveToday: Int = 0,
    val notMarkedToday: Int = 0,
    val pendingTraineeApprovals: Int = 0,
    val pendingInstructorRegistrations: Int = 0,
    val attendancePercentage: Double = 0.0
)

data class DistanceResult(
    val distanceMeters: Double,
    val isWithinRadius: Boolean,
    val currentLat: Double,
    val currentLng: Double,
    val instituteLat: Double,
    val instituteLng: Double,
    val allowedRadiusMeters: Double,
    val statusMessage: String
)

data class DiaryNote(
    val noteId: String = "",
    val traineeId: String = "",
    val traineeName: String = "",
    val tradeId: String = "",
    val tradeName: String = "",
    val instructorId: String = "",
    val instructorName: String = "",
    val title: String = "",
    val content: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val dateString: String = ""
)

fun compareTraineeIds(id1Raw: String, id2Raw: String): Int {
    val id1 = id1Raw.trim().uppercase()
    val id2 = id2Raw.trim().uppercase()

    if (id1 == id2) return 0
    if (id1.isEmpty()) return 1
    if (id2.isEmpty()) return -1

    if (id1 == "PENDING" && id2 != "PENDING") return 1
    if (id2 == "PENDING" && id1 != "PENDING") return -1

    val regex = Regex("(\\D+|\\d+)")
    val tokens1 = regex.findAll(id1).map { it.value }.toList()
    val tokens2 = regex.findAll(id2).map { it.value }.toList()

    val minLen = minOf(tokens1.size, tokens2.size)
    for (i in 0 until minLen) {
        val tok1 = tokens1[i]
        val tok2 = tokens2[i]

        val num1 = tok1.toLongOrNull()
        val num2 = tok2.toLongOrNull()

        if (num1 != null && num2 != null) {
            val cmp = num1.compareTo(num2)
            if (cmp != 0) return cmp
        } else {
            val cmp = tok1.compareTo(tok2)
            if (cmp != 0) return cmp
        }
    }
    return tokens1.size.compareTo(tokens2.size)
}

fun List<TraineeProfile>.sortedByTraineeIdAscending(): List<TraineeProfile> {
    return this.sortedWith { t1, t2 ->
        compareTraineeIds(t1.traineeId, t2.traineeId)
    }
}
