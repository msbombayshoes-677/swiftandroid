package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.data.model.DiaryNote
import com.example.data.model.InstituteNotification
import com.example.data.model.InstructorProfile
import com.example.data.model.TraineeProfile
import com.example.data.model.sortedByTraineeIdAscending
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodels.InstructorViewModel
import com.example.ui.viewmodels.TraineeAttendanceStat
import com.example.util.CsvExportUtils
import com.example.util.DateUtils
import com.example.util.NotificationPreferenceManager

enum class InstructorTab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard),
    ATTENDANCE("Attendance", Icons.Default.Checklist),
    REPORTS("Reports", Icons.Default.Assessment),
    DIARY("Diary", Icons.Default.MenuBook),
    TRAINEES("My Trainee", Icons.Default.People),
    APPROVALS("Approvals", Icons.Default.HowToReg),
    NOTIFICATIONS("Notifications", Icons.Default.Campaign)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstructorScreen(
    instructor: InstructorProfile,
    viewModel: InstructorViewModel,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf(InstructorTab.DASHBOARD) }

    val currentTradeName = uiState.currentTrade?.tradeName?.ifBlank { null }
        ?: uiState.instructorProfile?.tradeName?.ifBlank { null }
        ?: instructor.tradeName.ifBlank { "Trade Dashboard" }

    val context = LocalContext.current
    var acknowledgedNotifIds by remember(instructor.uid) {
        mutableStateOf(NotificationPreferenceManager.getAcknowledgedNotificationIds(context, instructor.uid))
    }
    var showNotifHistoryDialog by remember { mutableStateOf(false) }
    val unacknowledgedNotifs = remember(uiState.receivedAdminNotifications, acknowledgedNotifIds) {
        uiState.receivedAdminNotifications.filter { it.notificationId !in acknowledgedNotifIds }
    }

    // Dialog state for manual correction
    var recordToCorrect by remember { mutableStateOf<AttendanceRecord?>(null) }
    var newStatusToApply by remember { mutableStateOf(AttendanceStatus.PRESENT.statusName) }
    var correctionReason by remember { mutableStateOf("") }

    // Trainee rejection dialog
    var traineeUidToReject by remember { mutableStateOf<String?>(null) }
    var rejectionReason by remember { mutableStateOf("") }

    // Diary dialog state
    var showAddDiaryDialog by remember { mutableStateOf(false) }
    var noteToEdit by remember { mutableStateOf<DiaryNote?>(null) }
    var noteToDelete by remember { mutableStateOf<String?>(null) }

    // Broadcast notification dialog states
    var showInstructorBroadcastDialog by remember { mutableStateOf(false) }
    var broadcastSuccessTitle by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(instructor) {
        viewModel.setInstructor(instructor)
    }

    LaunchedEffect(selectedTab) {
        if (instructor.tradeId.isNotBlank()) {
            viewModel.loadInstructorData(instructor.tradeId)
        }
    }

    Scaffold(
        topBar = {
            Column {
                ItiTopAppBar(
                    title = currentTradeName,
                    subtitle = "Instructor: ${uiState.instructorProfile?.name ?: instructor.name}",
                    roleLabel = "Instructor",
                    notificationCount = uiState.notifications.size,
                    onBroadcast = { showInstructorBroadcastDialog = true },
                    onNotificationClick = { selectedTab = InstructorTab.NOTIFICATIONS },
                    onRefresh = { viewModel.loadInstructorData(instructor.tradeId) },
                    onLogout = onLogout
                )
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp,
                    shadowElevation = 2.dp
                ) {
                    ScrollableTabRow(
                        selectedTabIndex = InstructorTab.entries.indexOf(selectedTab).coerceAtLeast(0),
                        edgePadding = 4.dp,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.height(40.dp),
                        divider = { HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)) }
                    ) {
                        InstructorTab.entries.forEach { tab ->
                            val isSelected = selectedTab == tab
                            Tab(
                                selected = isSelected,
                                onClick = { selectedTab = tab },
                                modifier = Modifier
                                    .height(40.dp)
                                    .testTag("nav_instructor_${tab.name.lowercase()}"),
                                text = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = tab.icon,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = tab.title,
                                            maxLines = 1,
                                            softWrap = false,
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        )
                                    }
                                }
                            )
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Alerts
            if (uiState.message != null) {
                Surface(
                    color = StatusPresentGreen.copy(alpha = 0.15f),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(uiState.message ?: "", style = MaterialTheme.typography.bodySmall, color = StatusPresentGreen)
                        IconButton(onClick = { viewModel.clearMessages() }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = StatusPresentGreen)
                        }
                    }
                }
            }

            if (uiState.error != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(uiState.error ?: "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                        IconButton(onClick = { viewModel.clearMessages() }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss")
                        }
                    }
                }
            }

            // Tab Content
            when (selectedTab) {
                InstructorTab.DASHBOARD -> InstructorDashboardTab(
                    uiState = uiState,
                    onNavigate = { selectedTab = it }
                )
                InstructorTab.TRAINEES -> InstructorTraineesTab(
                    trainees = uiState.myTrainees.filter { it.status == "approved" || it.status == "inactive" || it.status == "deactivated" },
                    tradeName = currentTradeName,
                    searchQuery = uiState.searchQuery,
                    onSearchChange = { viewModel.updateSearchQuery(it) },
                    onViewHistory = { viewModel.viewTraineeHistory(it) },
                    onToggleStatus = { traineeUid, currentStatus, onSuccess ->
                        viewModel.toggleTraineeStatus(traineeUid, currentStatus, onSuccess)
                    },
                    onEditTrainee = { uid, name, parentage, contact, guardianContact, address, onSuccess ->
                        viewModel.updateTraineeDetails(uid, name, parentage, contact, guardianContact, address, onSuccess)
                    }
                )
                InstructorTab.DIARY -> InstructorDiaryTab(
                    diaryNotes = uiState.diaryNotes,
                    trainees = uiState.myTrainees.filter { it.status == "approved" },
                    onAddNoteClick = { showAddDiaryDialog = true },
                    onEditNoteClick = { noteToEdit = it },
                    onDeleteNote = { noteToDelete = it }
                )
                InstructorTab.APPROVALS -> InstructorApprovalsTab(
                    pendingTrainees = uiState.pendingTrainees,
                    onApprove = { viewModel.approveTrainee(it) },
                    onReject = { traineeUidToReject = it }
                )
                InstructorTab.NOTIFICATIONS -> InstructorNotificationsTab(
                    tradeName = currentTradeName,
                    notifications = uiState.notifications,
                    adminNotifications = uiState.receivedAdminNotifications,
                    myTrainees = remember(uiState.myTrainees, uiState.pendingTrainees) {
                        (uiState.myTrainees + uiState.pendingTrainees).distinctBy { it.uid }
                    },
                    instructorUid = uiState.instructorProfile?.uid ?: "",
                    onSendBroadcastClick = { showInstructorBroadcastDialog = true },
                    onDeleteNotification = { viewModel.deleteNotification(it) },
                    onDeleteNotifications = { viewModel.deleteNotifications(it) }
                )
                InstructorTab.ATTENDANCE -> InstructorAttendanceTab(
                    trainees = uiState.myTrainees.filter { it.status == "approved" },
                    attendance = uiState.todayAttendance,
                    selectedDate = uiState.selectedDate,
                    cutOffTime = uiState.instituteSettings.cutOffTime,
                    onDateChange = { viewModel.selectDate(it) },
                    onCorrect = { record ->
                        recordToCorrect = record
                        newStatusToApply = record.attendanceStatus
                    }
                )
                InstructorTab.REPORTS -> InstructorReportsTab(
                    trainees = uiState.myTrainees.filter { it.status == "approved" },
                    attendance = uiState.todayAttendance,
                    stats = uiState.stats,
                    tradeName = currentTradeName,
                    workingDaysList = uiState.instituteSettings.workingDays,
                    holidays = uiState.instituteSettings.holidays,
                    onFetchDayAttendance = { date -> viewModel.getAttendanceForDate(date) },
                    onFetchMonthlyAttendance = { month -> viewModel.getMonthlyAttendance(month) }
                )
            }
        }
    }

    // Manual Attendance Correction Dialog
    if (recordToCorrect != null) {
        val record = recordToCorrect!!
        val isNewMarking = record.attendanceStatus == "not_marked"
        AlertDialog(
            onDismissRequest = { recordToCorrect = null },
            title = {
                Text(if (isNewMarking) "Mark Trainee Attendance" else "Manual Attendance Correction")
            },
            text = {
                Column {
                    Text("Trainee: ${record.traineeName} (${record.traineeUniqueId})", fontWeight = FontWeight.Bold)
                    Text("Date: ${DateUtils.formatDateForDisplay(record.date)}", style = MaterialTheme.typography.bodySmall)
                    Text("Current Status: ${if (isNewMarking) "NOT MARKED" else record.attendanceStatus.uppercase()}", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isNewMarking) "Select Attendance Status:" else "Select Corrected Status:",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    val statusOptions = listOf(
                        "present" to "Present",
                        "late" to "Late",
                        "absent" to "Absent",
                        "half_day" to "Half Day",
                        "leave" to "Leave"
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        statusOptions.forEach { (st, label) ->
                            FilterChip(
                                selected = newStatusToApply == st,
                                onClick = { newStatusToApply = st },
                                label = {
                                    Text(
                                        text = label,
                                        maxLines = 1,
                                        softWrap = false,
                                        fontWeight = if (newStatusToApply == st) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                modifier = Modifier.testTag("chip_status_$st")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = correctionReason,
                        onValueChange = { correctionReason = it },
                        label = { Text(if (isNewMarking) "Remarks (Optional)" else "Reason for Correction (Mandatory)") },
                        modifier = Modifier.fillMaxWidth().testTag("input_correction_reason"),
                        minLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val finalReason = if (correctionReason.isNotBlank()) {
                            correctionReason
                        } else if (isNewMarking) {
                            "Marked by Instructor"
                        } else {
                            ""
                        }
                        viewModel.correctAttendance(record, newStatusToApply, finalReason)
                        recordToCorrect = null
                        correctionReason = ""
                    },
                    modifier = Modifier.testTag("btn_confirm_correction")
                ) {
                    Text(if (isNewMarking) "Save Attendance" else "Save Correction")
                }
            },
            dismissButton = {
                TextButton(onClick = { recordToCorrect = null }) { Text("Cancel") }
            }
        )
    }

    // Trainee Rejection Dialog
    if (traineeUidToReject != null) {
        AlertDialog(
            onDismissRequest = { traineeUidToReject = null },
            title = { Text("Reject Trainee Application") },
            text = {
                Column {
                    Text("Provide reason for rejecting this admission application:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = rejectionReason,
                        onValueChange = { rejectionReason = it },
                        label = { Text("Rejection Reason") },
                        modifier = Modifier.fillMaxWidth().testTag("input_instructor_reject_reason"),
                        minLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val uid = traineeUidToReject ?: return@Button
                        viewModel.rejectTrainee(uid, rejectionReason)
                        traineeUidToReject = null
                        rejectionReason = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("btn_confirm_instructor_reject")
                ) {
                    Text("Reject Application")
                }
            },
            dismissButton = {
                TextButton(onClick = { traineeUidToReject = null }) { Text("Cancel") }
            }
        )
    }

    // Add / Edit Diary Note Dialog
    if (showAddDiaryDialog || noteToEdit != null) {
        AddOrEditDiaryNoteDialog(
            trainees = uiState.myTrainees.filter { it.status == "approved" },
            noteToEdit = noteToEdit,
            onDismiss = {
                showAddDiaryDialog = false
                noteToEdit = null
            },
            onSave = { traineeId, traineeName, title, content ->
                viewModel.addDiaryNote(traineeId, traineeName, title, content)
                showAddDiaryDialog = false
                noteToEdit = null
            },
            onUpdate = { noteId, title, content ->
                viewModel.updateDiaryNote(noteId, title, content)
                noteToEdit = null
            }
        )
    }

    // Delete Diary Note Confirmation Dialog
    if (noteToDelete != null) {
        val noteId = noteToDelete!!
        AlertDialog(
            onDismissRequest = { noteToDelete = null },
            title = { Text("Delete Diary Note?") },
            text = { Text("Are you sure you want to delete this diary note? This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteDiaryNote(noteId)
                        noteToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { noteToDelete = null }) { Text("Cancel") }
            }
        )
    }

    // Broadcast Notification Dialog for Instructor
    if (showInstructorBroadcastDialog) {
        InstructorBroadcastNotificationDialog(
            tradeName = currentTradeName,
            myTrainees = uiState.myTrainees,
            onDismiss = { showInstructorBroadcastDialog = false },
            onSendNotification = { title, msg, targetUserId ->
                showInstructorBroadcastDialog = false
                viewModel.sendTradeBroadcastNotification(title, msg, targetUserId) {
                    broadcastSuccessTitle = title
                }
            }
        )
    }

    if (broadcastSuccessTitle != null) {
        AlertDialog(
            onDismissRequest = { broadcastSuccessTitle = null },
            icon = {
                Surface(
                    shape = androidx.compose.foundation.shape.CircleShape,
                    color = StatusPresentGreen.copy(alpha = 0.15f),
                    modifier = Modifier.size(56.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = StatusPresentGreen,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
            },
            title = {
                Text(
                    text = "Broadcast Sent Successfully!",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Text(
                    text = "Your announcement '$broadcastSuccessTitle' has been sent to trainees of $currentTradeName.",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = { broadcastSuccessTitle = null },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusPresentGreen),
                    modifier = Modifier.fillMaxWidth().testTag("btn_close_broadcast_success")
                ) {
                    Text("OK", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        )
    }

    // High-Priority Institute Pop-up Window Dialog on Login / New Announcement
    if (unacknowledgedNotifs.isNotEmpty()) {
        InstituteNotificationPopupDialog(
            notifications = unacknowledgedNotifs,
            onDismiss = { ids ->
                NotificationPreferenceManager.markNotificationsAcknowledged(context, ids, instructor.uid)
                acknowledgedNotifIds = NotificationPreferenceManager.getAcknowledgedNotificationIds(context, instructor.uid)
            }
        )
    }

    // Historical Notifications List Dialog
    if (showNotifHistoryDialog) {
        NotificationHistoryDialog(
            notifications = uiState.receivedAdminNotifications + uiState.notifications,
            onDismiss = { showNotifHistoryDialog = false }
        )
    }

    // Trainee History Modal
    if (uiState.selectedTraineeForHistory != null) {
        val selectedT = uiState.selectedTraineeForHistory!!
        AlertDialog(
            onDismissRequest = { viewModel.clearTraineeHistorySelection() },
            title = { Text("Attendance History: ${selectedT.name}") },
            text = {
                Column(modifier = Modifier.fillMaxWidth().height(320.dp)) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Trainee ID: ${selectedT.traineeId}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ItiNavyPrimary)
                                Text("Parent PIN: ${selectedT.parentAccessPin}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ItiOrangeSecondary)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = buildString {
                                    append("Father: ${selectedT.parentage}")
                                    if (selectedT.guardianContact.isNotBlank()) {
                                        append(" • Guardian No: ${selectedT.guardianContact}")
                                    }
                                    append(" • Contact: ${selectedT.contact}")
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    if (uiState.isLoading) {
                        Box(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Loading attendance history...", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    } else if (uiState.traineeHistory.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No past attendance records found for this trainee.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(uiState.traineeHistory) { hist ->
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp).fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(DateUtils.formatDateForDisplay(hist.date), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                            Text("In: ${DateUtils.formatTime(hist.punchInTime)} | Out: ${DateUtils.formatTime(hist.punchOutTime)}", style = MaterialTheme.typography.labelSmall)
                                        }
                                        StatusBadge(status = hist.attendanceStatus)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { viewModel.clearTraineeHistorySelection() }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
fun InstructorDashboardTab(
    uiState: com.example.ui.viewmodels.InstructorUiState,
    onNavigate: (InstructorTab) -> Unit
) {
    var selectedCategoryDialogIndex by remember { mutableStateOf<Int?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Assigned Trade: ${uiState.instructorProfile?.tradeName ?: "N/A"}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "Today: ${DateUtils.formatDateForDisplay(DateUtils.getTodayDateString())} (${DateUtils.getDayOfWeek()})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
            }
        }

        // Dedicated Current Month Trade Attendance Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_monthly_trade_attendance")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.BarChart,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Trade Monthly Attendance",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "All trainees of ${uiState.instructorProfile?.tradeName ?: "Trade"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = DateUtils.getCurrentMonthYear(),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "${String.format("%.1f", uiState.monthlyTradeAttendancePercentage)}%",
                                style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = when {
                                    uiState.monthlyTradeAttendancePercentage >= 80.0 -> StatusPresentGreen
                                    uiState.monthlyTradeAttendancePercentage >= 60.0 -> StatusLateOrange
                                    else -> StatusAbsentRed
                                }
                            )
                            Text(
                                text = "Trade Monthly Attendance Rate",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${uiState.stats.totalTrainees} Active Trainees",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${uiState.monthlyRecordedDaysCount} Recorded Days",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { (uiState.monthlyTradeAttendancePercentage / 100.0).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = when {
                            uiState.monthlyTradeAttendancePercentage >= 80.0 -> StatusPresentGreen
                            uiState.monthlyTradeAttendancePercentage >= 60.0 -> StatusLateOrange
                            else -> StatusAbsentRed
                        },
                        trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                    )
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth()) {
                StatCard(
                    title = "My Trainees",
                    value = uiState.stats.totalTrainees.toString(),
                    icon = Icons.Default.School,
                    accentColor = ItiNavyPrimary,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Attendance Rate",
                    value = "${String.format("%.1f", uiState.stats.attendancePercentage)}%",
                    icon = Icons.Default.CheckCircle,
                    accentColor = StatusPresentGreen,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth()) {
                StatCard(
                    title = "Present Today",
                    value = uiState.stats.presentToday.toString(),
                    icon = Icons.Default.CheckCircle,
                    accentColor = StatusPresentGreen,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Absent Today",
                    value = uiState.stats.absentToday.toString(),
                    icon = Icons.Default.PersonOff,
                    accentColor = StatusAbsentRed,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth()) {
                StatCard(
                    title = "Good (>=80%)",
                    value = uiState.goodAttendanceCount.toString(),
                    subtitle = "This month attendance",
                    icon = Icons.Default.ThumbUp,
                    accentColor = StatusPresentGreen,
                    onClick = { selectedCategoryDialogIndex = 0 },
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Poor (<=60%)",
                    value = uiState.poorAttendanceCount.toString(),
                    subtitle = "This month attendance",
                    icon = Icons.Default.ThumbDown,
                    accentColor = StatusAbsentRed,
                    onClick = { selectedCategoryDialogIndex = 1 },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        if (uiState.pendingTrainees.isNotEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Pending Trainee Approvals",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Text(
                                text = "${uiState.pendingTrainees.size} trainees awaiting your approval",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                            )
                        }
                        Button(onClick = { onNavigate(InstructorTab.APPROVALS) }) {
                            Text("Review")
                        }
                    }
                }
            }
        }

        // Developer Credit
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp, bottom = 8.dp, end = 4.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Developed By: V/I NAJEEB REHMAN :   Principal: Er. BILAL AHMAD WANI",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("developer_credit_instructor")
                )
            }
        }
    }

    if (selectedCategoryDialogIndex != null) {
        val goodTrainees = remember(uiState.monthlyTraineeStats) {
            uiState.monthlyTraineeStats.filter { it.percentage >= 80.0 }
        }
        val poorTrainees = remember(uiState.monthlyTraineeStats) {
            uiState.monthlyTraineeStats.filter { it.percentage <= 60.0 }
        }
        TraineeAttendanceCategoryDialog(
            initialCategoryIndex = selectedCategoryDialogIndex!!,
            goodTrainees = goodTrainees,
            poorTrainees = poorTrainees,
            tradeName = uiState.instructorProfile?.tradeName ?: "Trade",
            onDismiss = { selectedCategoryDialogIndex = null }
        )
    }
}

@Composable
fun TraineeAttendanceCategoryDialog(
    initialCategoryIndex: Int,
    goodTrainees: List<TraineeAttendanceStat>,
    poorTrainees: List<TraineeAttendanceStat>,
    tradeName: String,
    onDismiss: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(initialCategoryIndex) }
    var searchQuery by remember { mutableStateOf("") }

    val currentList = remember(selectedTab, goodTrainees, poorTrainees, searchQuery) {
        val base = if (selectedTab == 0) goodTrainees else poorTrainees
        if (searchQuery.isBlank()) {
            base.sortedByDescending { it.percentage }
        } else {
            base.filter {
                it.trainee.name.contains(searchQuery, ignoreCase = true) ||
                it.trainee.traineeId.contains(searchQuery, ignoreCase = true) ||
                it.trainee.contact.contains(searchQuery, ignoreCase = true)
            }.sortedByDescending { it.percentage }
        }
    }

    val themeColor = if (selectedTab == 0) StatusPresentGreen else StatusAbsentRed

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("btn_close_trainee_category_dialog")
            ) {
                Text("Close", fontWeight = FontWeight.Bold)
            }
        },
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Monthly Trainee Attendance",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Trade: $tradeName",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ThumbUp,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = StatusPresentGreen
                                )
                                Text(
                                    text = "Good (${goodTrainees.size})",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ThumbDown,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = StatusAbsentRed
                                )
                                Text(
                                    text = "Poor (${poorTrainees.size})",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = themeColor.copy(alpha = 0.12f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = if (selectedTab == 0) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = themeColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (selectedTab == 0) "Criteria: Trainees with >= 80% attendance this month" else "Criteria: Trainees with <= 60% attendance this month",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = themeColor
                        )
                    }
                }

                if ((if (selectedTab == 0) goodTrainees else poorTrainees).size > 3) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth().testTag("input_search_category_trainee"),
                        placeholder = { Text("Search by name or roll number...", style = MaterialTheme.typography.bodySmall) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp))
                        },
                        singleLine = true
                    )
                }

                if (currentList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                modifier = Modifier.size(36.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (searchQuery.isNotBlank()) "No trainees match '$searchQuery'" else if (selectedTab == 0) "No trainees with >=80% attendance this month" else "No trainees with <=60% attendance this month",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(currentList, key = { it.trainee.uid }) { stat ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = stat.trainee.name,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Roll: ${stat.trainee.traineeId} • Present: ${stat.presentDays}/${stat.totalDays} days",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Surface(
                                        color = (if (stat.percentage >= 80.0) StatusPresentGreen else if (stat.percentage <= 60.0) StatusAbsentRed else StatusLateOrange).copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = "${String.format("%.1f", stat.percentage)}%",
                                            color = if (stat.percentage >= 80.0) StatusPresentGreen else if (stat.percentage <= 60.0) StatusAbsentRed else StatusLateOrange,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun InstructorTraineesTab(
    trainees: List<TraineeProfile>,
    tradeName: String = "",
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onViewHistory: (TraineeProfile) -> Unit,
    onToggleStatus: (traineeUid: String, currentStatus: String, onSuccess: () -> Unit) -> Unit,
    onEditTrainee: (
        traineeUid: String,
        name: String,
        parentage: String,
        contact: String,
        guardianContact: String,
        address: String,
        onSuccess: () -> Unit
    ) -> Unit
) {
    var traineeToModify by remember { mutableStateOf<TraineeProfile?>(null) }
    var successDialogTraineeName by remember { mutableStateOf<String?>(null) }

    var statusToggleDialogTrainee by remember { mutableStateOf<TraineeProfile?>(null) }
    var statusSuccessDialogInfo by remember { mutableStateOf<Pair<String, Boolean>?>(null) } // Trainee Name to isActivated flag

    var subTab by remember { mutableStateOf(0) }

    if (traineeToModify != null) {
        ModifyTraineeDialog(
            trainee = traineeToModify!!,
            onDismiss = { traineeToModify = null },
            onSave = { name, parentage, contact, guardianContact, address ->
                val targetName = name
                onEditTrainee(traineeToModify!!.uid, name, parentage, contact, guardianContact, address) {
                    successDialogTraineeName = targetName
                }
            }
        )
    }

    if (successDialogTraineeName != null) {
        AlertDialog(
            onDismissRequest = { successDialogTraineeName = null },
            icon = {
                Surface(
                    shape = androidx.compose.foundation.shape.CircleShape,
                    color = StatusPresentGreen.copy(alpha = 0.15f),
                    modifier = Modifier.size(56.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = StatusPresentGreen,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
            },
            title = {
                Text(
                    text = "Details Updated Successfully!",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Trainee profile for $successDialogTraineeName has been modified successfully.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { successDialogTraineeName = null },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_close_modify_success_dialog")
                ) {
                    Text("OK", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Trainee Activation / Deactivation Confirmation Dialog
    if (statusToggleDialogTrainee != null) {
        val trainee = statusToggleDialogTrainee!!
        val isApproved = trainee.status.equals("approved", ignoreCase = true)
        val actionTitle = if (isApproved) "Deactivate Trainee" else "Activate Trainee"
        val actionVerb = if (isApproved) "deactivate" else "activate"

        AlertDialog(
            onDismissRequest = { statusToggleDialogTrainee = null },
            icon = {
                Surface(
                    shape = androidx.compose.foundation.shape.CircleShape,
                    color = if (isApproved) MaterialTheme.colorScheme.error.copy(alpha = 0.15f) else StatusPresentGreen.copy(alpha = 0.15f),
                    modifier = Modifier.size(56.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isApproved) Icons.Default.Block else Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = if (isApproved) MaterialTheme.colorScheme.error else StatusPresentGreen,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
            },
            title = {
                Text(
                    text = "$actionTitle?",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to $actionVerb trainee ${trainee.name} (${trainee.traineeId})? ${if (isApproved) "The trainee will be deactivated and will not be able to log in to their profile." else "The trainee will be activated and granted access to log in to their profile."}",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val target = statusToggleDialogTrainee
                        statusToggleDialogTrainee = null
                        if (target != null) {
                            val wasApproved = target.status.equals("approved", ignoreCase = true)
                            onToggleStatus(target.uid, target.status) {
                                statusSuccessDialogInfo = target.name to !wasApproved
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isApproved) MaterialTheme.colorScheme.error else StatusPresentGreen
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("btn_confirm_status_toggle")
                ) {
                    Text("Yes, $actionTitle", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { statusToggleDialogTrainee = null },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // Trainee Activation / Deactivation Success Popup Window Message Dialog
    if (statusSuccessDialogInfo != null) {
        val (traineeName, isActivated) = statusSuccessDialogInfo!!
        val actionText = if (isActivated) "Activated" else "Deactivated"
        val colorSchemeColor = if (isActivated) StatusPresentGreen else MaterialTheme.colorScheme.error

        AlertDialog(
            onDismissRequest = { statusSuccessDialogInfo = null },
            icon = {
                Surface(
                    shape = androidx.compose.foundation.shape.CircleShape,
                    color = colorSchemeColor.copy(alpha = 0.15f),
                    modifier = Modifier.size(56.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isActivated) Icons.Default.CheckCircle else Icons.Default.Block,
                            contentDescription = null,
                            tint = colorSchemeColor,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
            },
            title = {
                Text(
                    text = "Trainee $actionText Successfully!",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Trainee profile for $traineeName has been successfully $actionText. ${if (isActivated) "The trainee can now log in to their profile." else "The trainee will no longer be able to log in to their profile."}",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { statusSuccessDialogInfo = null },
                    colors = ButtonDefaults.buttonColors(containerColor = colorSchemeColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_close_status_success_dialog")
                ) {
                    Text("OK", fontWeight = FontWeight.Bold, color = androidx.compose.ui.graphics.Color.White)
                }
            }
        )
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        ScrollableTabRow(
            selectedTabIndex = subTab,
            edgePadding = 8.dp,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)),
            divider = {}
        ) {
            Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("My Trainees (${trainees.size})", maxLines = 1, softWrap = false)
                    }
                },
                modifier = Modifier.testTag("tab_my_trainees_list")
            )
            Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("View & Print", maxLines = 1, softWrap = false)
                    }
                },
                modifier = Modifier.testTag("tab_view_print_my_trainees")
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (subTab == 1) {
            val resolvedTrade = tradeName.ifBlank {
                trainees.firstOrNull()?.tradeName?.ifBlank { null } ?: "My Trade"
            }
            TraineeViewAndPrintSection(
                trainees = trainees.filter { it.status == "approved" || it.status == "inactive" },
                trades = emptyList(),
                fixedTradeName = resolvedTrade,
                lockToOwnTrade = true
            )
        } else {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("Search trainee by name / ID...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth().testTag("input_search_my_trainees"),
                singleLine = true
            )

        Spacer(modifier = Modifier.height(12.dp))

        val filtered = trainees.filter {
            searchQuery.isBlank() || it.name.contains(searchQuery, ignoreCase = true) || it.traineeId.contains(searchQuery, ignoreCase = true)
        }.sortedByTraineeIdAscending()

        if (filtered.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.People,
                title = "No Trainees Found",
                subtitle = "Approved trainees for your trade will appear here."
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered) { trainee ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth().testTag("trainee_card_${trainee.uid}")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(trainee.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                StatusBadge(status = trainee.status)
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Highlighted Credentials Box (Trainee ID + Parent Access PIN)
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.Badge,
                                            contentDescription = "Trainee ID",
                                            tint = ItiNavyPrimary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Column {
                                            Text(
                                                text = "TRAINEE ID",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = trainee.traineeId.ifBlank { "N/A" },
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = ItiNavyPrimary
                                            )
                                        }
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.Lock,
                                            contentDescription = "Parent PIN",
                                            tint = ItiOrangeSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "PARENT PIN",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = trainee.parentAccessPin.ifBlank { "1234" },
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = ItiOrangeSecondary
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Father / Parentage: ${trainee.parentage}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                            if (trainee.guardianContact.isNotBlank()) {
                                Text("Father/Guardian No: ${trainee.guardianContact}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium, color = ItiNavyPrimary)
                            }
                            Text("Contact: ${trainee.contact} • Email: ${trainee.email}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Address: ${trainee.address}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                FilledTonalButton(
                                    onClick = { onViewHistory(trainee) },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .height(34.dp)
                                        .testTag("btn_history_${trainee.uid}")
                                ) {
                                    Icon(
                                        Icons.Default.History,
                                        contentDescription = null,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "History",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1
                                    )
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                val isApproved = trainee.status.equals("approved", ignoreCase = true)
                                OutlinedButton(
                                    onClick = { statusToggleDialogTrainee = trainee },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = if (isApproved) MaterialTheme.colorScheme.error else StatusPresentGreen
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (isApproved) MaterialTheme.colorScheme.error.copy(alpha = 0.5f) else StatusPresentGreen.copy(alpha = 0.5f)
                                    ),
                                    modifier = Modifier
                                        .height(34.dp)
                                        .testTag("btn_toggle_status_${trainee.uid}")
                                ) {
                                    Icon(
                                        imageVector = if (isApproved) Icons.Default.Block else Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isApproved) "Deactivate" else "Activate",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1
                                    )
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                OutlinedButton(
                                    onClick = { traineeToModify = trainee },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .height(34.dp)
                                        .testTag("btn_modify_${trainee.uid}")
                                ) {
                                    Icon(
                                        Icons.Default.Edit,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Modify",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}

@Composable
fun ModifyTraineeDialog(
    trainee: TraineeProfile,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        parentage: String,
        contact: String,
        guardianContact: String,
        address: String
    ) -> Unit
) {
    var name by remember { mutableStateOf(trainee.name) }
    var parentage by remember { mutableStateOf(trainee.parentage) }
    var contact by remember { mutableStateOf(trainee.contact) }
    var guardianContact by remember { mutableStateOf(trainee.guardianContact) }
    var address by remember { mutableStateOf(trainee.address) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("Modify Trainee Details", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("Trainee ID: ${trainee.traineeId.ifBlank { "N/A" }}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name *") },
                    modifier = Modifier.fillMaxWidth().testTag("input_edit_trainee_name"),
                    singleLine = true
                )
                OutlinedTextField(
                    value = parentage,
                    onValueChange = { parentage = it },
                    label = { Text("Father / Parentage") },
                    modifier = Modifier.fillMaxWidth().testTag("input_edit_trainee_parentage"),
                    singleLine = true
                )
                OutlinedTextField(
                    value = contact,
                    onValueChange = { contact = it },
                    label = { Text("Trainee Contact No.") },
                    modifier = Modifier.fillMaxWidth().testTag("input_edit_trainee_contact"),
                    singleLine = true
                )
                OutlinedTextField(
                    value = guardianContact,
                    onValueChange = { guardianContact = it },
                    label = { Text("Father/Guardian Contact No.") },
                    modifier = Modifier.fillMaxWidth().testTag("input_edit_trainee_guardian_contact"),
                    singleLine = true
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Address") },
                    modifier = Modifier.fillMaxWidth().testTag("input_edit_trainee_address")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(name, parentage, contact, guardianContact, address)
                    onDismiss()
                },
                enabled = name.isNotBlank(),
                modifier = Modifier.testTag("btn_save_trainee_details")
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun InstructorApprovalsTab(
    pendingTrainees: List<TraineeProfile>,
    onApprove: (String) -> Unit,
    onReject: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Pending Trainee Admissions (${pendingTrainees.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Verify candidate details and grant admission for GPS attendance.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(12.dp))

        if (pendingTrainees.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.CheckCircle,
                title = "All Caught Up!",
                subtitle = "No pending trainee applications for your trade."
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(pendingTrainees) { trainee ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth().testTag("pending_trainee_${trainee.uid}")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(trainee.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text("Father: ${trainee.parentage}", style = MaterialTheme.typography.bodySmall)
                                    if (trainee.guardianContact.isNotBlank()) {
                                        Text("Father/Guardian No: ${trainee.guardianContact}", style = MaterialTheme.typography.bodySmall, color = ItiNavyPrimary)
                                    }
                                }
                                StatusBadge(status = "pending")
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Email: ${trainee.email}", style = MaterialTheme.typography.bodySmall)
                            Text("Contact: ${trainee.contact}", style = MaterialTheme.typography.bodySmall)
                            Text("Address: ${trainee.address}", style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                OutlinedButton(
                                    onClick = { onReject(trainee.uid) },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                    modifier = Modifier.testTag("btn_instructor_reject_${trainee.uid}")
                                ) {
                                    Text("Reject")
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = { onApprove(trainee.uid) },
                                    modifier = Modifier.testTag("btn_instructor_approve_${trainee.uid}")
                                ) {
                                    Text("Approve & Generate ID")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstructorAttendanceTab(
    trainees: List<TraineeProfile>,
    attendance: List<AttendanceRecord>,
    selectedDate: String,
    cutOffTime: String = "17:00",
    onDateChange: (String) -> Unit,
    onCorrect: (AttendanceRecord) -> Unit
) {
    var selectedFilter by remember { mutableStateOf("all") }
    var showDatePickerDialog by remember { mutableStateOf(false) }

    val hasPunchForDay = remember(attendance) {
        attendance.any { it.punchInTime != null || it.attendanceStatus.isNotBlank() }
    }

    val isPastCutOff = remember(selectedDate, cutOffTime, hasPunchForDay) {
        hasPunchForDay && DateUtils.isPastCutOff(selectedDate, cutOffTime)
    }

    val notMarkedTrainees = remember(trainees, attendance) {
        trainees.filter { t ->
            attendance.none { a -> a.traineeId == t.uid }
        }
    }

    if (showDatePickerDialog) {
        val initialMillis = remember(selectedDate) {
            DateUtils.parseDateToUtcMillis(selectedDate)
        }
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = initialMillis
        )
        DatePickerDialog(
            onDismissRequest = { showDatePickerDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        val selectedMillis = datePickerState.selectedDateMillis
                        if (selectedMillis != null) {
                            val formatted = DateUtils.formatUtcMillisToDate(selectedMillis)
                            onDateChange(formatted)
                        }
                        showDatePickerDialog = false
                    },
                    modifier = Modifier.testTag("btn_apply_instructor_date_picker")
                ) {
                    Text("Apply Date")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePickerDialog = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(
                state = datePickerState,
                title = {
                    Text(
                        "Select Attendance Date",
                        modifier = Modifier.padding(start = 24.dp, end = 12.dp, top = 16.dp),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            )
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (selectedDate == DateUtils.getTodayDateString()) "Today's Punches" else "Attendance Punches",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Event,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = DateUtils.formatDateForDisplay(selectedDate),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (selectedDate != DateUtils.getTodayDateString()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "Previous Date",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Date picker button inserted to the right of date title
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (selectedDate != DateUtils.getTodayDateString()) {
                    OutlinedButton(
                        onClick = { onDateChange(DateUtils.getTodayDateString()) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("btn_reset_today_date")
                    ) {
                        Text("Today", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }

                FilledTonalButton(
                    onClick = { showDatePickerDialog = true },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("btn_select_attendance_date")
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = "Pick Date",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Select Date", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Horizontal filter chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            val filters = listOf(
                "all" to "All",
                "present" to "Present",
                "late" to "Late",
                "absent" to "Absent",
                "not_marked" to "Not Marked"
            )
            items(filters) { (filterKey, filterLabel) ->
                val presentOrLateCount = attendance.count { it.attendanceStatus.lowercase() == "present" || it.attendanceStatus.lowercase() == "late" }
                val count = when (filterKey) {
                    "all" -> attendance.size + notMarkedTrainees.size
                    "present" -> attendance.count { it.attendanceStatus.lowercase() == "present" }
                    "late" -> attendance.count { it.attendanceStatus.lowercase() == "late" }
                    "absent" -> if (isPastCutOff) (trainees.size - presentOrLateCount).coerceAtLeast(0) else attendance.count { it.attendanceStatus.lowercase() == "absent" }
                    "not_marked" -> if (isPastCutOff) 0 else notMarkedTrainees.size
                    else -> 0
                }
                FilterChip(
                    selected = selectedFilter == filterKey,
                    onClick = { selectedFilter = filterKey },
                    label = { Text("$filterLabel ($count)") },
                    modifier = Modifier.testTag("chip_attendance_filter_$filterKey")
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        val hasAnyData = trainees.isNotEmpty() || attendance.isNotEmpty()

        if (!hasAnyData) {
            EmptyStateView(
                icon = Icons.Default.Checklist,
                title = "No Trainees Found",
                subtitle = "There are no approved trainees in this trade to track."
            )
        } else {
            // Filter lists based on selection
            val filteredAttendance = remember(selectedFilter, attendance) {
                if (selectedFilter == "all") {
                    attendance
                } else {
                    attendance.filter { it.attendanceStatus.lowercase() == selectedFilter }
                }
            }

            val showUnmarked = if (isPastCutOff) (selectedFilter == "all" || selectedFilter == "absent") else (selectedFilter == "all" || selectedFilter == "not_marked")
            val displayedUnmarked = if (showUnmarked) notMarkedTrainees else emptyList()

            if (filteredAttendance.isEmpty() && displayedUnmarked.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Checklist,
                    title = "No Records Found",
                    subtitle = "No trainees match the selected filter."
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Show marked attendance first
                    items(filteredAttendance) { rec ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth().testTag("attendance_record_${rec.attendanceId}")
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(rec.traineeName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(rec.traineeUniqueId, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ItiNavyPrimary)
                                    }
                                    StatusBadge(status = rec.attendanceStatus)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Punch In: ${DateUtils.formatTime(rec.punchInTime)}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                                    Text("Punch Out: ${DateUtils.formatTime(rec.punchOutTime)}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                                }
                                if (rec.punchInDistance != null) {
                                    Text("Distance at Punch: ${String.format("%.1f", rec.punchInDistance)}m", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                if (rec.remarks != null) {
                                    Text("Remarks: ${rec.remarks}", style = MaterialTheme.typography.bodySmall, color = StatusLateOrange)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                    TextButton(
                                        onClick = { onCorrect(rec) },
                                        modifier = Modifier.testTag("btn_correct_${rec.attendanceId}")
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Manual Correction")
                                    }
                                }
                            }
                        }
                    }

                    // Show unmarked trainees
                    items(displayedUnmarked) { trainee ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth().testTag("unmarked_trainee_${trainee.uid}")
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(trainee.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(trainee.traineeId, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ItiNavyPrimary)
                                    }
                                    StatusBadge(status = if (isPastCutOff) "absent" else "not_marked")
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("No punch records for today.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                    TextButton(
                                        onClick = {
                                            val tempRecord = AttendanceRecord(
                                                attendanceId = "att_${trainee.uid}_${selectedDate}",
                                                traineeId = trainee.uid,
                                                traineeUniqueId = trainee.traineeId,
                                                traineeName = trainee.name,
                                                date = selectedDate,
                                                attendanceStatus = "not_marked"
                                            )
                                            onCorrect(tempRecord)
                                        },
                                        modifier = Modifier.testTag("btn_mark_${trainee.uid}")
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Mark Attendance")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstructorReportsTab(
    trainees: List<TraineeProfile>,
    attendance: List<AttendanceRecord>,
    stats: com.example.data.model.DashboardStats,
    tradeName: String,
    workingDaysList: List<String> = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"),
    holidays: List<com.example.data.model.Holiday> = emptyList(),
    onFetchDayAttendance: (suspend (String) -> List<AttendanceRecord>)? = null,
    onFetchMonthlyAttendance: (suspend (String) -> List<AttendanceRecord>)? = null
) {
    var reportTab by remember { mutableStateOf(1) } // 0: Day-Wise, 1: Month-Wise (Default to Month-Wise)
    var selectedDayDate by remember { mutableStateOf(DateUtils.getTodayDateString()) }
    var selectedMonthStr by remember { mutableStateOf(DateUtils.getTodayDateString().take(7)) } // e.g. "2026-08"

    var showDayDatePickerDialog by remember { mutableStateOf(false) }
    var showMonthDatePickerDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }

    var dayAttendanceRecords by remember { mutableStateOf<List<AttendanceRecord>>(attendance) }
    var monthlyAttendanceRecords by remember { mutableStateOf<List<AttendanceRecord>>(emptyList()) }
    var isLoadingDay by remember { mutableStateOf(false) }
    var isLoadingMonth by remember { mutableStateOf(false) }
    var reloadDayTrigger by remember { mutableStateOf(0) }
    var reloadMonthlyTrigger by remember { mutableStateOf(0) }
    var dayFilterStatus by remember { mutableStateOf("all") }

    val availableMonths = remember {
        val list = mutableListOf<Pair<String, String>>()
        val cal = java.util.Calendar.getInstance()
        val sdfVal = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault())
        val sdfLbl = java.text.SimpleDateFormat("MMMM yyyy", java.util.Locale.getDefault())
        for (i in 0..11) {
            list.add(sdfVal.format(cal.time) to sdfLbl.format(cal.time))
            cal.add(java.util.Calendar.MONTH, -1)
        }
        list
    }

    LaunchedEffect(selectedDayDate, reportTab, reloadDayTrigger) {
        if (reportTab == 0) {
            if (selectedDayDate == DateUtils.getTodayDateString() && attendance.isNotEmpty() && reloadDayTrigger == 0) {
                dayAttendanceRecords = attendance
            } else if (onFetchDayAttendance != null) {
                isLoadingDay = true
                dayAttendanceRecords = onFetchDayAttendance(selectedDayDate)
                isLoadingDay = false
            }
        }
    }

    LaunchedEffect(selectedMonthStr, reportTab, reloadMonthlyTrigger) {
        if (reportTab == 1 && onFetchMonthlyAttendance != null) {
            isLoadingMonth = true
            monthlyAttendanceRecords = onFetchMonthlyAttendance(selectedMonthStr)
            isLoadingMonth = false
        }
    }

    // Day DatePicker Dialog
    if (showDayDatePickerDialog) {
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = try {
                val sdf = java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.getDefault())
                sdf.parse(selectedDayDate)?.time
            } catch (_: Exception) { null }
        )
        DatePickerDialog(
            onDismissRequest = { showDayDatePickerDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val selectedMillis = datePickerState.selectedDateMillis
                        if (selectedMillis != null) {
                            selectedDayDate = DateUtils.formatUtcMillisToDate(selectedMillis)
                        }
                        showDayDatePickerDialog = false
                    }
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDayDatePickerDialog = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    // Month DatePicker Dialog
    if (showMonthDatePickerDialog) {
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = try {
                val sdf = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault())
                sdf.parse(selectedMonthStr)?.time
            } catch (_: Exception) { null }
        )
        DatePickerDialog(
            onDismissRequest = { showMonthDatePickerDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val selectedMillis = datePickerState.selectedDateMillis
                        if (selectedMillis != null) {
                            val formattedDate = DateUtils.formatUtcMillisToDate(selectedMillis)
                            selectedMonthStr = formattedDate.replace("/", "-").take(7)
                        }
                        showMonthDatePickerDialog = false
                    }
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showMonthDatePickerDialog = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    var traineeSearchQuery by remember { mutableStateOf("") }
    var expandedTraineeUids by remember { mutableStateOf<Set<String>>(emptySet()) }

    val (monthTotalDays, monthWorkingDays, monthHolidays) = remember(selectedMonthStr, workingDaysList, holidays) {
        DateUtils.calculateWorkingDays(selectedMonthStr, workingDaysList, holidays)
    }

    val distinctMonthDates = remember(monthlyAttendanceRecords) {
        monthlyAttendanceRecords.map { it.date.replace("/", "-") }.distinct().size
    }

    val enrolledUids = remember(trainees) { trainees.map { it.uid }.toSet() }
    val enrolledTraineeIds = remember(trainees) { trainees.map { it.traineeId }.filter { it.isNotBlank() }.toSet() }

    val allTraineesForMonth = remember(trainees, monthlyAttendanceRecords) {
        val additional = monthlyAttendanceRecords
            .filter { it.traineeId !in enrolledUids && it.traineeUniqueId !in enrolledTraineeIds }
            .distinctBy { it.traineeId.ifBlank { it.traineeUniqueId } }
            .map { rec ->
                TraineeProfile(
                    uid = rec.traineeId,
                    traineeId = rec.traineeUniqueId,
                    name = rec.traineeName,
                    tradeName = rec.tradeName
                )
            }
        (trainees + additional).sortedBy { it.name }
    }

    val totalMonthPunches = remember(monthlyAttendanceRecords) {
        monthlyAttendanceRecords.sumOf { rec ->
            var p = 0
            if (rec.punchInTime != null) p++
            if (rec.punchOutTime != null) p++
            if (p == 0 && (rec.attendanceStatus == "present" || rec.attendanceStatus == "late")) p = 1
            p
        }
    }
    val presentMonthCount = remember(monthlyAttendanceRecords) {
        monthlyAttendanceRecords.count { it.attendanceStatus == "present" }
    }
    val lateMonthCount = remember(monthlyAttendanceRecords) {
        monthlyAttendanceRecords.count { it.attendanceStatus == "late" }
    }
    val absentMonthCount = remember(monthlyAttendanceRecords) {
        monthlyAttendanceRecords.count { it.attendanceStatus == "absent" }
    }

    val filteredTrainees = remember(allTraineesForMonth, traineeSearchQuery) {
        if (traineeSearchQuery.isBlank()) allTraineesForMonth
        else {
            val q = traineeSearchQuery.trim()
            allTraineesForMonth.filter {
                it.name.contains(q, ignoreCase = true) ||
                it.traineeId.contains(q, ignoreCase = true)
            }
        }
    }

    // Day Stats Summary with full mapping
    val dayAttendanceMap = remember(dayAttendanceRecords) {
        val map = mutableMapOf<String, AttendanceRecord>()
        dayAttendanceRecords.forEach { rec ->
            if (rec.traineeId.isNotBlank()) map[rec.traineeId] = rec
            if (rec.traineeUniqueId.isNotBlank()) map[rec.traineeUniqueId] = rec
            if (rec.traineeName.isNotBlank()) map[rec.traineeName.lowercase().trim()] = rec
        }
        map
    }

    val allTraineesForDay = remember(trainees, dayAttendanceRecords, enrolledUids, enrolledTraineeIds) {
        val additional = dayAttendanceRecords
            .filter { it.traineeId !in enrolledUids && it.traineeUniqueId !in enrolledTraineeIds }
            .distinctBy { it.traineeId.ifBlank { it.traineeUniqueId } }
            .map { rec ->
                TraineeProfile(
                    uid = rec.traineeId,
                    traineeId = rec.traineeUniqueId,
                    name = rec.traineeName,
                    tradeName = rec.tradeName
                )
            }
        (trainees + additional).sortedBy { it.name }
    }

    val (dayPresentCountOnly, dayLateCount, dayMarkedAbsentCount, dayNotMarkedCount) = remember(allTraineesForDay, dayAttendanceMap) {
        var pOnly = 0
        var lCount = 0
        var aCount = 0
        var nmCount = 0
        allTraineesForDay.forEach { tr ->
            val rec = dayAttendanceMap[tr.uid]
                ?: (if (tr.traineeId.isNotBlank()) dayAttendanceMap[tr.traineeId] else null)
                ?: (if (tr.name.isNotBlank()) dayAttendanceMap[tr.name.lowercase().trim()] else null)
            val status = rec?.attendanceStatus?.lowercase()?.trim() ?: "not_marked"
            when (status) {
                "present" -> pOnly++
                "late" -> lCount++
                "absent" -> aCount++
                else -> nmCount++
            }
        }
        listOf(pOnly, lCount, aCount, nmCount)
    }

    val totalDayEnrolled = allTraineesForDay.size
    val presentDayCount = dayPresentCountOnly + dayLateCount
    // Formula: Absent trainees = enrolled trainees - present trainees - not marked attendance
    val absentDayCount = (totalDayEnrolled - presentDayCount - dayNotMarkedCount).coerceAtLeast(0)
    val lateDayCount = dayLateCount
    val notMarkedDayCount = dayNotMarkedCount
    val dayRate = if (totalDayEnrolled > 0) (presentDayCount.toFloat() / totalDayEnrolled) * 100f else 0f

    val filteredDayTrainees = remember(allTraineesForDay, dayAttendanceMap, dayFilterStatus) {
        allTraineesForDay.filter { tr ->
            val rec = dayAttendanceMap[tr.uid]
                ?: (if (tr.traineeId.isNotBlank()) dayAttendanceMap[tr.traineeId] else null)
                ?: (if (tr.name.isNotBlank()) dayAttendanceMap[tr.name.lowercase().trim()] else null)
            val status = rec?.attendanceStatus?.lowercase()?.trim() ?: "not_marked"
            when (dayFilterStatus) {
                "all" -> true
                "present" -> status == "present" || status == "late"
                "late" -> status == "late"
                "absent" -> status == "absent"
                "not_marked" -> status != "present" && status != "late" && status != "absent"
                else -> true
            }
        }
    }

    val dayHoliday = remember(selectedDayDate, holidays) {
        DateUtils.getHolidayForDate(selectedDayDate, holidays)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Trade Attendance Report", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                FilledTonalButton(
                    onClick = { showExportDialog = true },
                    modifier = Modifier.testTag("btn_export_trade_report")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Export Report")
                }
            }
        }

        // Mode Selector Tabs: Day-Wise vs Month-Wise
        item {
            TabRow(selectedTabIndex = reportTab) {
                Tab(
                    selected = reportTab == 0,
                    onClick = { reportTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Today, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Day-Wise Report", fontWeight = FontWeight.Bold)
                        }
                    }
                )
                Tab(
                    selected = reportTab == 1,
                    onClick = { reportTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Month-Wise Report", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }
        }

        if (reportTab == 0) {
            // Day-Wise Date Picker Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Selected Day:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "${DateUtils.formatDateForDisplay(selectedDayDate)} ($selectedDayDate)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(
                                onClick = { reloadDayTrigger++ },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    Icons.Default.Refresh,
                                    contentDescription = "Refresh Day Attendance",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            OutlinedButton(
                                onClick = { showDayDatePickerDialog = true },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("btn_pick_day_wise_date")
                            ) {
                                Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Select Date")
                            }
                        }
                    }
                }
            }

            // Holiday Alert Banner if selected day is a marked holiday
            if (dayHoliday != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f),
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                Icons.Default.EventBusy,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(24.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Institute Holiday: ${dayHoliday.name}",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "This day is marked as a holiday. It is excluded from working days and attendance calculations.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Day Summary (${DateUtils.formatDateForDisplay(selectedDayDate)})",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Surface(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Text(
                                    text = "Rate: ${String.format(java.util.Locale.US, "%.1f", dayRate)}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Enrolled", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    Text("$totalDayEnrolled", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Present", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    Text("$presentDayCount", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = StatusPresentGreen)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Absent", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    Text("$absentDayCount", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = StatusAbsentRed)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Late", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    Text("$lateDayCount", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = StatusLateOrange)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Unmarked", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    Text("$notMarkedDayCount", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }

            // Filter chips for Day-Wise Report
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val filters = listOf(
                        "all" to "All ($totalDayEnrolled)",
                        "present" to "Present ($presentDayCount)",
                        "absent" to "Absent ($absentDayCount)",
                        "late" to "Late ($lateDayCount)",
                        "not_marked" to "Not Marked ($notMarkedDayCount)"
                    )
                    items(filters) { (fKey, fLabel) ->
                        FilterChip(
                            selected = dayFilterStatus == fKey,
                            onClick = { dayFilterStatus = fKey },
                            label = { Text(fLabel, fontWeight = if (dayFilterStatus == fKey) FontWeight.Bold else FontWeight.Normal) },
                            modifier = Modifier.testTag("chip_day_filter_$fKey")
                        )
                    }
                }
            }

            if (isLoadingDay) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp))
                    }
                }
            } else {
                item {
                    Text(
                        text = "Trainee Day Attendance (${filteredDayTrainees.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (filteredDayTrainees.isEmpty()) {
                    item {
                        Text(
                            text = "No trainees found for the selected filter on $selectedDayDate.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    items(filteredDayTrainees) { tr ->
                        val rec = dayAttendanceMap[tr.uid]
                            ?: (if (tr.traineeId.isNotBlank()) dayAttendanceMap[tr.traineeId] else null)
                            ?: (if (tr.name.isNotBlank()) dayAttendanceMap[tr.name.lowercase().trim()] else null)
                        val status = rec?.attendanceStatus?.lowercase()?.trim() ?: "not_marked"
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(8.dp),
                            tonalElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(tr.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    val punchText = if (rec?.punchInTime != null) "Punch In: ${DateUtils.formatTime(rec.punchInTime)}" else "Attendance Not Marked"
                                    Text(
                                        text = "ID: ${tr.traineeId.ifBlank { tr.uid.take(8) }} • $punchText",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                StatusBadge(status = status)
                            }
                        }
                    }
                }
            }
        } else {
            // Month-Wise Report
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Selected Month:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = "${DateUtils.formatYearMonthForDisplay(selectedMonthStr)} ($selectedMonthStr)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(
                                    onClick = { reloadMonthlyTrigger++ },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Refresh,
                                        contentDescription = "Refresh Month Attendance",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                OutlinedButton(
                                    onClick = { showMonthDatePickerDialog = true },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.testTag("btn_pick_month_wise_date")
                                ) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Select Month")
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Quick Select Month:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(availableMonths) { pair ->
                                FilterChip(
                                    selected = selectedMonthStr == pair.first,
                                    onClick = { selectedMonthStr = pair.first },
                                    label = { Text(pair.second, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Monthly Overview (${DateUtils.formatYearMonthForDisplay(selectedMonthStr)})",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Surface(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Text(
                                    text = "$monthWorkingDays Working Days",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Trainees", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${allTraineesForMonth.size}", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Working Days", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    Text("$monthWorkingDays", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Total Holiday's", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    Text("$monthHolidays", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = StatusLateOrange)
                                }
                            }
                        }
                    }
                }
            }

            // Search Bar for trainees
            item {
                OutlinedTextField(
                    value = traineeSearchQuery,
                    onValueChange = { traineeSearchQuery = it },
                    label = { Text("Search Trainee by Name or ID") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (traineeSearchQuery.isNotBlank()) {
                            IconButton(onClick = { traineeSearchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("input_search_monthly_trainee"),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )
            }

            if (isLoadingMonth) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(modifier = Modifier.size(32.dp))
                    }
                }
            } else {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Trainee Month-Wise Report (${filteredTrainees.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        if (allTraineesForMonth.isNotEmpty()) {
                            TextButton(
                                onClick = {
                                    expandedTraineeUids = if (expandedTraineeUids.size == allTraineesForMonth.size) emptySet()
                                    else allTraineesForMonth.map { it.uid.ifBlank { it.traineeId } }.toSet()
                                }
                            ) {
                                Text(if (expandedTraineeUids.size == allTraineesForMonth.size) "Collapse All" else "Expand Logs")
                            }
                        }
                    }
                }

                if (filteredTrainees.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    if (traineeSearchQuery.isNotBlank()) "No trainees matching '$traineeSearchQuery'"
                                    else "No trainee records found for ${DateUtils.formatYearMonthForDisplay(selectedMonthStr)}.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = { reloadMonthlyTrigger++ },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reload Records")
                                }
                            }
                        }
                    }
                } else {
                    items(filteredTrainees) { trainee ->
                        val traineeKey = trainee.uid.ifBlank { trainee.traineeId }
                        val isExpanded = expandedTraineeUids.contains(traineeKey)
                        TraineeMonthReportCard(
                            trainee = trainee,
                            monthlyAttendanceRecords = monthlyAttendanceRecords,
                            distinctMonthDates = distinctMonthDates,
                            monthWorkingDays = monthWorkingDays,
                            selectedMonthStr = selectedMonthStr,
                            holidays = holidays,
                            isExpanded = isExpanded,
                            onToggleExpand = {
                                expandedTraineeUids = if (isExpanded) expandedTraineeUids - traineeKey
                                else expandedTraineeUids + traineeKey
                            }
                        )
                    }
                }
            }
        }
    }

    if (showExportDialog) {
        val context = androidx.compose.ui.platform.LocalContext.current
        val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
        var exportMode by remember { mutableStateOf(reportTab) } // 0: Daily, 1: Monthly
        var exportDayDate by remember { mutableStateOf(selectedDayDate) }
        var exportMonthStr by remember { mutableStateOf(selectedMonthStr) }

        var exportDayRecords by remember { mutableStateOf<List<AttendanceRecord>>(dayAttendanceRecords) }
        var exportMonthRecords by remember { mutableStateOf<List<AttendanceRecord>>(monthlyAttendanceRecords) }

        var showExportDayPicker by remember { mutableStateOf(false) }
        var showExportMonthPicker by remember { mutableStateOf(false) }

        LaunchedEffect(exportDayDate) {
            if (exportDayDate == selectedDayDate && dayAttendanceRecords.isNotEmpty()) {
                exportDayRecords = dayAttendanceRecords
            } else if (onFetchDayAttendance != null) {
                exportDayRecords = onFetchDayAttendance(exportDayDate)
            }
        }

        LaunchedEffect(exportMonthStr) {
            if (exportMonthStr == selectedMonthStr && monthlyAttendanceRecords.isNotEmpty()) {
                exportMonthRecords = monthlyAttendanceRecords
            } else if (onFetchMonthlyAttendance != null) {
                exportMonthRecords = onFetchMonthlyAttendance(exportMonthStr)
            }
        }

        if (showExportDayPicker) {
            val datePickerState = rememberDatePickerState(
                initialSelectedDateMillis = try {
                    val sdf = java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.getDefault())
                    sdf.parse(exportDayDate)?.time
                } catch (_: Exception) { null }
            )
            DatePickerDialog(
                onDismissRequest = { showExportDayPicker = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            val selectedMillis = datePickerState.selectedDateMillis
                            if (selectedMillis != null) {
                                exportDayDate = DateUtils.formatUtcMillisToDate(selectedMillis)
                            }
                            showExportDayPicker = false
                        }
                    ) {
                        Text("OK")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showExportDayPicker = false }) { Text("Cancel") }
                }
            ) {
                DatePicker(state = datePickerState)
            }
        }

        if (showExportMonthPicker) {
            val datePickerState = rememberDatePickerState(
                initialSelectedDateMillis = try {
                    val sdf = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault())
                    sdf.parse(exportMonthStr)?.time
                } catch (_: Exception) { null }
            )
            DatePickerDialog(
                onDismissRequest = { showExportMonthPicker = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            val selectedMillis = datePickerState.selectedDateMillis
                            if (selectedMillis != null) {
                                val formattedDate = DateUtils.formatUtcMillisToDate(selectedMillis)
                                exportMonthStr = formattedDate.replace("/", "-").take(7)
                            }
                            showExportMonthPicker = false
                        }
                    ) {
                        Text("OK")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showExportMonthPicker = false }) { Text("Cancel") }
                }
            ) {
                DatePicker(state = datePickerState)
            }
        }

        val activeRecords = if (exportMode == 0) exportDayRecords else exportMonthRecords

        val reportCsv = remember(exportMode, activeRecords, tradeName, exportMonthStr, trainees) {
            buildString {
                if (exportMode == 0) {
                    append("Date,Trainee ID,Trainee Name,Trade,Status,Punch In,Punch Out,Remarks\n")
                    activeRecords.forEach { a ->
                        append("${a.date},${a.traineeUniqueId},${a.traineeName},$tradeName,${a.attendanceStatus},${DateUtils.formatTime(a.punchInTime)},${DateUtils.formatTime(a.punchOutTime)},${a.remarks ?: ""}\n")
                    }
                } else {
                    // Month-Wise Trainee Summary CSV
                    val distinctDates = activeRecords.map { it.date.replace("/", "-") }.distinct().size
                    val enrolledUids = trainees.map { it.uid }.toSet()
                    val enrolledIds = trainees.map { it.traineeId }.filter { it.isNotBlank() }.toSet()
                    val additional = activeRecords
                        .filter { it.traineeId !in enrolledUids && it.traineeUniqueId !in enrolledIds }
                        .distinctBy { it.traineeId.ifBlank { it.traineeUniqueId } }
                        .map { TraineeProfile(uid = it.traineeId, traineeId = it.traineeUniqueId, name = it.traineeName, tradeName = it.tradeName) }
                    val allList = (trainees + additional).sortedBy { it.name }

                    append("=== MONTHLY TRAINEE ATTENDANCE SUMMARY ($exportMonthStr) ===\n")
                    append("Trainee ID,Trainee Name,Trade,Total Punches,Present Days,Late Days,Absent Days,Total Working Days,Attendance %\n")
                    allList.forEach { tr ->
                        val trRecords = activeRecords.filter {
                            (tr.uid.isNotBlank() && it.traineeId == tr.uid) ||
                            (tr.traineeId.isNotBlank() && it.traineeUniqueId == tr.traineeId) ||
                            (tr.name.isNotBlank() && it.traineeName.equals(tr.name, ignoreCase = true))
                        }
                        val punches = trRecords.sumOf { rec ->
                            var c = 0
                            if (rec.punchInTime != null) c++
                            if (rec.punchOutTime != null) c++
                            if (c == 0 && (rec.attendanceStatus == "present" || rec.attendanceStatus == "late")) c = 1
                            c
                        }
                        val present = trRecords.count { it.attendanceStatus.equals("present", ignoreCase = true) }
                        val late = trRecords.count { it.attendanceStatus.equals("late", ignoreCase = true) }
                        val absent = trRecords.count { it.attendanceStatus.equals("absent", ignoreCase = true) }
                        val attended = present + late
                        val pct = if (distinctDates > 0) ((attended.toDouble() / distinctDates.toDouble()) * 100.0).coerceIn(0.0, 100.0)
                        else if (trRecords.isNotEmpty()) ((attended.toDouble() / trRecords.size.toDouble()) * 100.0).coerceIn(0.0, 100.0) else 0.0
                        val trId = tr.traineeId.ifBlank { tr.uid.take(8) }

                        append("$trId,${tr.name},$tradeName,$punches,$present,$late,$absent,$distinctDates,${String.format(java.util.Locale.US, "%.1f%%", pct)}\n")
                    }

                    append("\n=== DETAILED MONTHLY LOGS ===\n")
                    append("Date,Trainee ID,Trainee Name,Trade,Status,Punch In,Punch Out,Remarks\n")
                    activeRecords.forEach { a ->
                        append("${a.date},${a.traineeUniqueId},${a.traineeName},$tradeName,${a.attendanceStatus},${DateUtils.formatTime(a.punchInTime)},${DateUtils.formatTime(a.punchOutTime)},${a.remarks ?: ""}\n")
                    }
                }
            }
        }

        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = {
                Column {
                    Text("Export Trade Attendance Report", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Trade: $tradeName", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TabRow(selectedTabIndex = exportMode) {
                        Tab(
                            selected = exportMode == 0,
                            onClick = { exportMode = 0 },
                            text = { Text("Day-Wise", fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = exportMode == 1,
                            onClick = { exportMode = 1 },
                            text = { Text("Month-Wise", fontWeight = FontWeight.Bold) }
                        )
                    }

                    if (exportMode == 0) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Target Date: $exportDayDate", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                OutlinedButton(
                                    onClick = { showExportDayPicker = true },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Pick Date", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Target Month: ${DateUtils.formatYearMonthForDisplay(exportMonthStr)}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                OutlinedButton(
                                    onClick = { showExportMonthPicker = true },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Pick Month", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(availableMonths) { pair ->
                                    FilterChip(
                                        selected = exportMonthStr == pair.first,
                                        onClick = { exportMonthStr = pair.first },
                                        label = { Text(pair.second, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Records: ${activeRecords.size}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Text(
                                "Present: ${activeRecords.count { it.attendanceStatus == "present" || it.attendanceStatus == "late" }} | Absent: ${activeRecords.count { it.attendanceStatus == "absent" }}",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(160.dp)
                    ) {
                        Text(
                            text = reportCsv,
                            modifier = Modifier.padding(8.dp),
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val sanitizedTrade = tradeName.replace(" ", "_").replace("/", "-")
                        val fileName = if (exportMode == 0) {
                            "trade_attendance_${sanitizedTrade}_${exportDayDate.replace("/", "-")}.csv"
                        } else {
                            "trade_attendance_${sanitizedTrade}_${exportMonthStr.replace("/", "-")}.csv"
                        }
                        val downloaded = CsvExportUtils.downloadCsvFile(context, fileName, reportCsv)
                        if (downloaded) {
                            android.widget.Toast.makeText(context, "CSV downloaded: $fileName to Downloads folder", android.widget.Toast.LENGTH_LONG).show()
                        } else {
                            clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(reportCsv))
                            android.widget.Toast.makeText(context, "CSV copied to clipboard!", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.testTag("btn_download_trade_csv")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Download CSV")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
fun TraineeMonthReportCard(
    trainee: TraineeProfile,
    monthlyAttendanceRecords: List<AttendanceRecord>,
    distinctMonthDates: Int,
    monthWorkingDays: Int,
    selectedMonthStr: String,
    holidays: List<com.example.data.model.Holiday> = emptyList(),
    isExpanded: Boolean,
    onToggleExpand: () -> Unit
) {
    // Calculate trainee specific records for this month
    val traineeRecords = remember(monthlyAttendanceRecords, trainee) {
        monthlyAttendanceRecords.filter { rec ->
            (trainee.uid.isNotBlank() && rec.traineeId == trainee.uid) ||
            (trainee.traineeId.isNotBlank() && rec.traineeUniqueId == trainee.traineeId) ||
            (trainee.name.isNotBlank() && rec.traineeName.equals(trainee.name, ignoreCase = true))
        }.sortedByDescending { it.date }
    }

    val holidayDates = remember(holidays) {
        holidays.map { it.date.replace("/", "-").trim() }.toSet()
    }

    val workingRecords = remember(traineeRecords, holidayDates) {
        traineeRecords.filter { it.date.replace("/", "-").trim() !in holidayDates }
    }

    val punchesCount = remember(traineeRecords) {
        traineeRecords.sumOf { rec ->
            var count = 0
            if (rec.punchInTime != null && rec.punchInTime > 0L) count++
            if (rec.punchOutTime != null && rec.punchOutTime > 0L) count++
            if (count == 0 && (rec.attendanceStatus.equals("present", ignoreCase = true) || rec.attendanceStatus.equals("late", ignoreCase = true))) {
                count = 1
            }
            count
        }
    }

    val traineePresentCount = remember(workingRecords) {
        workingRecords.count { it.attendanceStatus.equals("present", ignoreCase = true) }
    }
    val traineeLateCount = remember(workingRecords) {
        workingRecords.count { it.attendanceStatus.equals("late", ignoreCase = true) }
    }
    val traineeAbsentCount = remember(workingRecords) {
        workingRecords.count { it.attendanceStatus.equals("absent", ignoreCase = true) }
    }

    val effectiveAttendedDays = traineePresentCount + traineeLateCount
    val totalReferenceDays = if (monthWorkingDays > 0) monthWorkingDays else if (distinctMonthDates > 0) distinctMonthDates else workingRecords.size
    val attendancePercentage = remember(workingRecords, distinctMonthDates, monthWorkingDays, totalReferenceDays) {
        if (totalReferenceDays > 0) {
            ((effectiveAttendedDays.toDouble() / totalReferenceDays.toDouble()) * 100.0).coerceIn(0.0, 100.0)
        } else 0.0
    }

    val percentColor = when {
        attendancePercentage >= 80.0 -> StatusPresentGreen
        attendancePercentage >= 60.0 -> StatusLateOrange
        else -> StatusAbsentRed
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("trainee_month_card_${trainee.traineeId.ifBlank { trainee.uid }}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Top Row: Trainee Info + Attendance Percentage
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = CircleShape,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = trainee.name.take(1).uppercase(),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                    }

                    Column {
                        Text(
                            text = trainee.name,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        val displayId = trainee.traineeId.ifBlank { trainee.uid.take(8) }
                        Text(
                            text = "ID: $displayId",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Total Attendance Percentage Badge
                Surface(
                    color = percentColor.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, percentColor.copy(alpha = 0.3f))
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = String.format(java.util.Locale.US, "%.1f%%", attendancePercentage),
                            fontWeight = FontWeight.ExtraBold,
                            color = percentColor,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = "Attendance",
                            style = MaterialTheme.typography.labelSmall,
                            color = percentColor
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Progress Bar
            LinearProgressIndicator(
                progress = { (attendancePercentage / 100.0).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(6.dp),
                color = percentColor,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Metric Badges Grid: Punches, Present, Absent, Late
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Working Days
                Surface(
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Working Days", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        Text("$monthWorkingDays", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                    }
                }

                // Present Count
                Surface(
                    modifier = Modifier.weight(1f),
                    color = StatusPresentGreen.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Present", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$traineePresentCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = StatusPresentGreen)
                    }
                }

                // Late Count
                Surface(
                    modifier = Modifier.weight(1f),
                    color = StatusLateOrange.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Late", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$traineeLateCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = StatusLateOrange)
                    }
                }

                // Absent Count
                Surface(
                    modifier = Modifier.weight(1f),
                    color = StatusAbsentRed.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Absent", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$traineeAbsentCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = StatusAbsentRed)
                    }
                }
            }

            // Expandable Toggle for Punch Logs
            if (traineeRecords.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${traineeRecords.size} daily log(s) in $selectedMonthStr",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(
                        onClick = onToggleExpand,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                    ) {
                        Text(
                            text = if (isExpanded) "Hide Logs ▲" else "View Logs ▼",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }

                // Expanded Day Logs for this trainee
                if (isExpanded) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        traineeRecords.forEach { rec ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = rec.date,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                    val inTime = if (rec.punchInTime != null) DateUtils.formatTime(rec.punchInTime) else "No In-Punch"
                                    val outTime = if (rec.punchOutTime != null) DateUtils.formatTime(rec.punchOutTime) else "--:--"
                                    Text(
                                        text = "In: $inTime | Out: $outTime",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                StatusBadge(status = rec.attendanceStatus)
                            }
                            if (rec != traineeRecords.last()) {
                                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InstructorDiaryTab(
    diaryNotes: List<DiaryNote>,
    trainees: List<TraineeProfile>,
    onAddNoteClick: () -> Unit,
    onEditNoteClick: (DiaryNote) -> Unit,
    onDeleteNote: (String) -> Unit
) {
    var selectedTraineeFilter by remember { mutableStateOf<String>("all") }
    var searchQuery by remember { mutableStateOf("") }

    val filteredNotes = remember(diaryNotes, selectedTraineeFilter, searchQuery) {
        diaryNotes.filter { note ->
            val matchesTrainee = selectedTraineeFilter == "all" || note.traineeId == selectedTraineeFilter
            val matchesSearch = searchQuery.isBlank() ||
                    note.traineeName.contains(searchQuery, ignoreCase = true) ||
                    note.title.contains(searchQuery, ignoreCase = true) ||
                    note.content.contains(searchQuery, ignoreCase = true)
            matchesTrainee && matchesSearch
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Trainee Diary Notes", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Add & manage remarks visible to trainees and parents", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onAddNoteClick,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("btn_add_diary_note")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Note")
                }
            }
        }

        // Search Field
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search trainee name, title or remark...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_instructor_diary_search")
            )
        }

        // Filter by Trainee (Horizontal Scrollable Row)
        if (trainees.isNotEmpty()) {
            item {
                Column {
                    Text("Filter by Trainee:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            FilterChip(
                                selected = selectedTraineeFilter == "all",
                                onClick = { selectedTraineeFilter = "all" },
                                label = { Text("All (${diaryNotes.size})") }
                            )
                        }
                        items(trainees, key = { it.uid }) { t ->
                            FilterChip(
                                selected = selectedTraineeFilter == t.uid,
                                onClick = {
                                    selectedTraineeFilter = if (selectedTraineeFilter == t.uid) "all" else t.uid
                                },
                                label = { Text("${t.name} (${t.traineeId})") }
                            )
                        }
                    }
                }
            }
        }

        if (filteredNotes.isEmpty()) {
            item {
                EmptyStateView(
                    icon = Icons.Default.MenuBook,
                    title = "No Diary Notes Found",
                    subtitle = if (searchQuery.isNotBlank()) "No notes match '$searchQuery'." else "Click 'Add Note' to create remarks/notes for trainees in your trade."
                )
            }
        } else {
            items(filteredNotes, key = { it.noteId }) { note ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("diary_note_card_${note.noteId}")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = note.traineeName,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                Text(
                                    text = DateUtils.formatDateForDisplay(note.dateString.ifBlank { DateUtils.getTodayDateString() }),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Row {
                                IconButton(
                                    onClick = { onEditNoteClick(note) },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .testTag("btn_edit_diary_${note.noteId}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit Note",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { onDeleteNote(note.noteId) },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .testTag("btn_delete_diary_${note.noteId}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete Note",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = note.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = note.content,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(12.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Instructor: ${note.instructorName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = note.tradeName,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddOrEditDiaryNoteDialog(
    trainees: List<TraineeProfile>,
    noteToEdit: DiaryNote? = null,
    onDismiss: () -> Unit,
    onSave: (traineeId: String, traineeName: String, title: String, content: String) -> Unit,
    onUpdate: (noteId: String, title: String, content: String) -> Unit
) {
    val isEditing = noteToEdit != null
    var selectedTrainee by remember {
        mutableStateOf<TraineeProfile?>(
            trainees.find { it.uid == noteToEdit?.traineeId } ?: trainees.firstOrNull()
        )
    }
    var expandedDropdown by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf(noteToEdit?.title ?: "") }
    var content by remember { mutableStateOf(noteToEdit?.content ?: "") }

    val quickCategories = listOf("Conduct", "Discipline", "Academic", "Practical Test", "Attendance Issue", "Commendation", "General Remark")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isEditing) Icons.Default.Edit else Icons.Default.Add,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isEditing) "Edit Diary Note" else "Add Trainee Diary Note",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Trainee Selector
                Text("Target Trainee:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                if (isEditing) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "${noteToEdit?.traineeName ?: selectedTrainee?.name} (${noteToEdit?.tradeName ?: selectedTrainee?.tradeName})",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                } else {
                    ExposedDropdownMenuBox(
                        expanded = expandedDropdown,
                        onExpandedChange = { expandedDropdown = !expandedDropdown }
                    ) {
                        OutlinedTextField(
                            value = selectedTrainee?.let { "${it.name} (${it.traineeId})" } ?: "No Trainees Available",
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .testTag("dropdown_select_trainee")
                        )
                        ExposedDropdownMenu(
                            expanded = expandedDropdown,
                            onDismissRequest = { expandedDropdown = false }
                        ) {
                            trainees.forEach { t ->
                                DropdownMenuItem(
                                    text = { Text("${t.name} (${t.traineeId})") },
                                    onClick = {
                                        selectedTrainee = t
                                        expandedDropdown = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Quick Category Selectors
                Column {
                    Text("Quick Categories / Title Suggestions:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(quickCategories) { category ->
                            FilterChip(
                                selected = title.equals(category, ignoreCase = true),
                                onClick = { title = category },
                                label = { Text(category, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Note Title / Category") },
                    placeholder = { Text("e.g. Practical Conduct, Absence Note") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_diary_title")
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Diary Details / Remarks") },
                    placeholder = { Text("Enter detailed note for trainee and parent...") },
                    minLines = 4,
                    maxLines = 6,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_diary_content")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (isEditing) {
                        noteToEdit?.let { note ->
                            onUpdate(note.noteId, title.trim(), content.trim())
                        }
                    } else {
                        val t = selectedTrainee
                        if (t != null && title.isNotBlank() && content.isNotBlank()) {
                            onSave(t.uid, t.name, title.trim(), content.trim())
                        }
                    }
                },
                enabled = (isEditing || selectedTrainee != null) && title.isNotBlank() && content.isNotBlank(),
                modifier = Modifier.testTag(if (isEditing) "btn_update_diary_note" else "btn_save_diary_note")
            ) {
                Text(if (isEditing) "Update Note" else "Save Note")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstructorNotificationsTab(
    tradeName: String,
    notifications: List<InstituteNotification>,
    adminNotifications: List<InstituteNotification> = emptyList(),
    myTrainees: List<TraineeProfile>,
    instructorUid: String = "",
    onSendBroadcastClick: () -> Unit,
    onDeleteNotification: (String) -> Unit,
    onDeleteNotifications: ((List<String>) -> Unit)? = null
) {
    var filterType by remember { mutableStateOf("all") } // "all", "trainees", "institute"
    var selectedTraineeUid by remember { mutableStateOf<String?>(null) }
    var dropdownExpanded by remember { mutableStateOf(false) }
    var notifToDelete by remember { mutableStateOf<InstituteNotification?>(null) }
    var showDeleteAllDialog by remember { mutableStateOf(false) }

    val manualAdminNotices = remember(adminNotifications) {
        adminNotifications.filter { notif ->
            val isNotSystem = notif.senderName != "Attendance Engine" &&
                    !notif.senderName.contains("Engine", ignoreCase = true) &&
                    !notif.senderName.contains("System", ignoreCase = true)
            val isNotAutomated = !notif.title.contains("Late Punch", ignoreCase = true) &&
                    !notif.title.contains("Punch", ignoreCase = true) &&
                    !notif.title.contains("Account Approved", ignoreCase = true) &&
                    !notif.title.contains("Registration Approved", ignoreCase = true) &&
                    !notif.title.contains("Approved", ignoreCase = true) &&
                    !notif.title.contains("Rejected", ignoreCase = true) &&
                    !notif.title.contains("Diary Note", ignoreCase = true) &&
                    !notif.title.contains("Attendance", ignoreCase = true)

            isNotSystem && isNotAutomated
        }
    }

    val isShowingAdminNotices = filterType == "institute"

    val filteredNotifications = remember(notifications, manualAdminNotices, filterType, selectedTraineeUid, myTrainees) {
        when (filterType) {
            "institute" -> manualAdminNotices
            "all" -> notifications.filter { it.targetUserId.isNullOrBlank() }
            "trainees" -> {
                if (selectedTraineeUid != null) {
                    val matchingTrainee = myTrainees.find { it.uid == selectedTraineeUid || it.traineeId == selectedTraineeUid }
                    notifications.filter { notif ->
                        !notif.targetUserId.isNullOrBlank() && (
                            notif.targetUserId == selectedTraineeUid ||
                            (matchingTrainee != null && (notif.targetUserId == matchingTrainee.traineeId || notif.targetUserId == matchingTrainee.uid))
                        )
                    }
                } else {
                    notifications.filter { !it.targetUserId.isNullOrBlank() }
                }
            }
            else -> notifications
        }
    }

    val specificTraineeCount = remember(notifications) {
        notifications.count { !it.targetUserId.isNullOrBlank() }
    }

    val allTraineesCount = remember(notifications) {
        notifications.count { it.targetUserId.isNullOrBlank() }
    }

    val selectedTrainee = remember(selectedTraineeUid, myTrainees) {
        myTrainees.find { it.uid == selectedTraineeUid || it.traineeId == selectedTraineeUid }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section Title: Header Card matching Admin style
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer)
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Icon(
                                    imageVector = Icons.Default.Campaign,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Sent Announcements (${filteredNotifications.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = when (filterType) {
                                    "institute" -> "Broadcast notices issued by institute administration"
                                    "trainees" -> if (selectedTrainee != null) "Announcements sent to ${selectedTrainee.name}" else "Announcements sent to individual trainees"
                                    else -> "Broadcasting & alerts sent by you to all $tradeName trainees"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (filteredNotifications.isNotEmpty() && !isShowingAdminNotices && onDeleteNotifications != null) {
                        IconButton(
                            onClick = { showDeleteAllDialog = true },
                            modifier = Modifier.testTag("btn_delete_all_instructor_notifications")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Delete Displayed Announcements",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }

        // Filters: "All" (My), "Trainees" (with visible-on-selection dropdown), and "Institute"
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Filter 1: My
                item {
                    FilterChip(
                        selected = filterType == "all",
                        onClick = {
                            dropdownExpanded = false
                            filterType = "all"
                            selectedTraineeUid = null
                        },
                        label = { Text("My ($allTraineesCount)") },
                        leadingIcon = if (filterType == "all") {
                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        } else null,
                        modifier = Modifier.testTag("chip_filter_all")
                    )
                }

                // Filter 2: Trainees button
                item {
                    FilterChip(
                        selected = filterType == "trainees",
                        onClick = {
                            dropdownExpanded = false
                            filterType = if (filterType == "trainees") "all" else "trainees"
                        },
                        label = { Text("Trainees ($specificTraineeCount)") },
                        leadingIcon = if (filterType == "trainees") {
                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        } else {
                            { Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        },
                        modifier = Modifier.testTag("chip_filter_trainees")
                    )
                }

                // Filter 2b: Trainee Dropdown selector (visible only when Trainees button is selected)
                if (filterType == "trainees") {
                    item {
                        Box {
                            val dropdownLabel = if (selectedTrainee != null) {
                                val traineeCount = notifications.count { notif ->
                                    !notif.targetUserId.isNullOrBlank() && (
                                        notif.targetUserId == selectedTrainee.uid ||
                                        notif.targetUserId == selectedTrainee.traineeId
                                    )
                                }
                                "${selectedTrainee.name} ($traineeCount)"
                            } else {
                                "Select Trainee"
                            }

                            FilterChip(
                                selected = selectedTrainee != null,
                                onClick = { dropdownExpanded = !dropdownExpanded },
                                label = { Text(dropdownLabel, fontWeight = FontWeight.Medium) },
                                trailingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Select Specific Trainee",
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                modifier = Modifier.testTag("btn_trainee_dropdown_selector")
                            )

                            DropdownMenu(
                                expanded = dropdownExpanded,
                                onDismissRequest = { dropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Select Trainee ($specificTraineeCount)", fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        dropdownExpanded = false
                                        selectedTraineeUid = null
                                    },
                                    leadingIcon = if (selectedTraineeUid == null) {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    } else null
                                )
                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                                myTrainees.forEach { trainee ->
                                    val traineeNotifCount = remember(notifications, trainee) {
                                        notifications.count { notif ->
                                            !notif.targetUserId.isNullOrBlank() && (
                                                notif.targetUserId == trainee.uid ||
                                                notif.targetUserId == trainee.traineeId
                                            )
                                        }
                                    }
                                    DropdownMenuItem(
                                        text = {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f, fill = false)) {
                                                    Text(trainee.name, fontWeight = FontWeight.Medium)
                                                    Text(
                                                        text = "ID: ${trainee.traineeId}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                if (traineeNotifCount > 0) {
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Surface(
                                                        color = MaterialTheme.colorScheme.primaryContainer,
                                                        shape = RoundedCornerShape(10.dp)
                                                    ) {
                                                        Text(
                                                            text = "$traineeNotifCount",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        },
                                        onClick = {
                                            dropdownExpanded = false
                                            selectedTraineeUid = trainee.uid
                                        },
                                        leadingIcon = if (selectedTraineeUid == trainee.uid || selectedTraineeUid == trainee.traineeId) {
                                            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                        } else null
                                    )
                                }
                            }
                        }
                    }
                }

                // Filter 3: Institute filter (shows manual admin notifications except automated logs and system triggers)
                item {
                    FilterChip(
                        selected = filterType == "institute",
                        onClick = {
                            dropdownExpanded = false
                            filterType = if (filterType == "institute") "all" else "institute"
                            selectedTraineeUid = null
                        },
                        label = { Text("Institute (${manualAdminNotices.size})") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.AccountBalance,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (filterType == "institute") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        modifier = Modifier.testTag("chip_filter_institute")
                    )
                }
            }
        }

        // Notifications List
        if (filteredNotifications.isEmpty()) {
            item {
                EmptyStateView(
                    icon = if (filterType == "institute") Icons.Default.AccountBalance else if (filterType == "trainees") Icons.Default.Person else Icons.Default.NotificationsNone,
                    title = if (filterType == "institute") "No Institute Notices" else if (filterType == "trainees") "No Trainee Messages" else "No Sent Announcements",
                    subtitle = if (filterType == "institute") "Manual broadcast notices from institute administration will appear here." else if (filterType == "trainees") "Announcements targeted to specific trainees will appear here." else "Announcements sent to all trainees will appear here."
                )
            }
        } else {
            items(filteredNotifications, key = { it.notificationId }) { notif ->
                val isSpecificTrainee = !notif.targetUserId.isNullOrBlank()
                val targetTrainee = remember(notif.targetUserId, myTrainees) {
                    if (isSpecificTrainee) {
                        myTrainees.find { it.uid == notif.targetUserId || it.traineeId == notif.targetUserId }
                    } else null
                }
                val traineeName = targetTrainee?.name ?: "Specific Trainee"
                val traineeId = targetTrainee?.traineeId?.takeIf { it.isNotBlank() } ?: notif.targetUserId ?: ""

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        width = 1.dp,
                        color = if (isSpecificTrainee) MaterialTheme.colorScheme.primary.copy(alpha = 0.35f) else MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("card_instructor_notif_${notif.notificationId}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        // TOP SECTION: Inside message, display trainee name, id & delete icon at top
                        if (isSpecificTrainee) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primaryContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Person,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = traineeName,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Surface(
                                                color = MaterialTheme.colorScheme.secondaryContainer,
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = "ID: $traineeId",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                            Surface(
                                                color = StatusLateOrange.copy(alpha = 0.15f),
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = "SPECIFIC TRAINEE",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = StatusLateOrange,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }

                                // Delete Icon at top right
                                IconButton(
                                    onClick = { notifToDelete = notif },
                                    modifier = Modifier
                                        .size(38.dp)
                                        .testTag("btn_delete_notif_${notif.notificationId}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete Announcement",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 10.dp),
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                            )
                        } else {
                            // Non-specific trainee: Trade Broadcast or Admin Broadcast
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isShowingAdminNotices || notif.senderRole == "admin") {
                                    Surface(
                                        color = Color(0xFFD35400).copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.AdminPanelSettings,
                                                contentDescription = null,
                                                tint = Color(0xFFD35400),
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Text(
                                                text = "INSTITUTE BROADCAST",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFD35400)
                                            )
                                        }
                                    }
                                } else {
                                    Surface(
                                        color = StatusPresentGreen.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Campaign,
                                                contentDescription = null,
                                                tint = StatusPresentGreen,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Text(
                                                text = "ALL $tradeName TRAINEES",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = StatusPresentGreen
                                            )
                                        }
                                    }
                                }

                                if (!isShowingAdminNotices) {
                                    IconButton(
                                        onClick = { notifToDelete = notif },
                                        modifier = Modifier
                                            .size(38.dp)
                                            .testTag("btn_delete_notif_${notif.notificationId}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete Announcement",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        // Notification Title
                        Text(
                            text = notif.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        // Sender and Timestamp
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "By ${notif.senderName} • ${DateUtils.formatDateTime(notif.timestamp)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Notification Message Body
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = notif.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (notifToDelete != null) {
        AlertDialog(
            onDismissRequest = { notifToDelete = null },
            title = { Text("Delete Announcement") },
            text = { Text("Are you sure you want to delete notification '${notifToDelete?.title}'? It will be removed from trainees' view.") },
            confirmButton = {
                Button(
                    onClick = {
                        notifToDelete?.let { onDeleteNotification(it.notificationId) }
                        notifToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { notifToDelete = null }) { Text("Cancel") }
            }
        )
    }

    if (showDeleteAllDialog) {
        val deleteDialogTitle = when (filterType) {
            "trainees" -> if (selectedTrainee != null) "Delete Announcements for ${selectedTrainee.name}?" else "Delete Trainee Announcements?"
            else -> "Delete My Announcements?"
        }
        val deleteDialogText = when (filterType) {
            "trainees" -> if (selectedTrainee != null) {
                "Are you sure you want to delete all ${filteredNotifications.size} announcements sent to ${selectedTrainee.name}? This action cannot be undone."
            } else {
                "Are you sure you want to delete all ${filteredNotifications.size} announcements sent to specific trainees? This action cannot be undone."
            }
            else -> "Are you sure you want to delete all ${filteredNotifications.size} announcements sent by you to all $tradeName trainees? This action cannot be undone."
        }

        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            icon = { Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text(deleteDialogTitle) },
            text = { Text(deleteDialogText) },
            confirmButton = {
                Button(
                    onClick = {
                        val idsToDelete = filteredNotifications.filter { it.senderRole != "admin" }.map { it.notificationId }
                        onDeleteNotifications?.invoke(idsToDelete)
                        showDeleteAllDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete (${filteredNotifications.size})")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstructorBroadcastNotificationDialog(
    tradeName: String,
    myTrainees: List<TraineeProfile>,
    onDismiss: () -> Unit,
    onSendNotification: (title: String, message: String, targetUserId: String?) -> Unit
) {
    var notifTitle by remember { mutableStateOf("") }
    var notifMsg by remember { mutableStateOf("") }
    var selectedTrainee by remember { mutableStateOf<TraineeProfile?>(null) } // null = All Trainees in Trade
    var recipientDropdownExpanded by remember { mutableStateOf(false) }

    val approvedTrainees = remember(myTrainees) {
        val filtered = myTrainees.filter { it.status.equals("approved", ignoreCase = true) }
        val targetList = if (filtered.isNotEmpty()) filtered else myTrainees
        targetList.sortedByTraineeIdAscending()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Campaign,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Send Trade Announcement",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Send announcement to all trainees in $tradeName or select a specific trainee.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text("Recipient Filter *", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)

                ExposedDropdownMenuBox(
                    expanded = recipientDropdownExpanded,
                    onExpandedChange = { recipientDropdownExpanded = !recipientDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedTrainee?.let { "${it.name} (${it.traineeId})" } ?: "📢 All $tradeName Trainees",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Send To (Filter)") },
                        leadingIcon = {
                            Icon(
                                imageVector = if (selectedTrainee == null) Icons.Default.Campaign else Icons.Default.Person,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = recipientDropdownExpanded) },
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                            .testTag("dropdown_recipient_filter")
                    )
                    ExposedDropdownMenu(
                        expanded = recipientDropdownExpanded,
                        onDismissRequest = { recipientDropdownExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Campaign, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("All $tradeName Trainees (Broadcast)", fontWeight = FontWeight.Bold)
                                }
                            },
                            onClick = {
                                selectedTrainee = null
                                recipientDropdownExpanded = false
                            },
                            modifier = Modifier.testTag("dropdown_item_all_trainees")
                        )

                        if (approvedTrainees.isNotEmpty()) {
                            androidx.compose.material3.HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            approvedTrainees.forEach { t ->
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(t.name, fontWeight = FontWeight.SemiBold)
                                                Text("ID: ${t.traineeId}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    },
                                    onClick = {
                                        selectedTrainee = t
                                        recipientDropdownExpanded = false
                                    },
                                    modifier = Modifier.testTag("dropdown_item_trainee_${t.uid}")
                                )
                            }
                        }
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    FilterChip(
                        selected = selectedTrainee == null,
                        onClick = { selectedTrainee = null },
                        label = { Text("All Trainees") },
                        modifier = Modifier.testTag("chip_target_all_trade")
                    )
                    FilterChip(
                        selected = selectedTrainee != null,
                        onClick = {
                            if (selectedTrainee == null && approvedTrainees.isNotEmpty()) {
                                selectedTrainee = approvedTrainees.first()
                            }
                        },
                        label = { Text(if (selectedTrainee == null) "Select Trainee" else "Specific Trainee") },
                        modifier = Modifier.testTag("chip_target_specific_trainee")
                    )
                }

                OutlinedTextField(
                    value = notifTitle,
                    onValueChange = { notifTitle = it },
                    label = { Text("Notification Title *") },
                    placeholder = { Text("e.g. Workshop Session Rescheduled") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_instructor_notif_title")
                )

                OutlinedTextField(
                    value = notifMsg,
                    onValueChange = { notifMsg = it },
                    label = { Text("Notification Message *") },
                    placeholder = { Text("Enter detailed announcement text...") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth().testTag("input_instructor_notif_msg")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (notifTitle.isNotBlank() && notifMsg.isNotBlank()) {
                        onSendNotification(
                            notifTitle.trim(),
                            notifMsg.trim(),
                            selectedTrainee?.uid
                        )
                    }
                },
                enabled = notifTitle.isNotBlank() && notifMsg.isNotBlank(),
                modifier = Modifier.testTag("btn_send_instructor_broadcast")
            ) {
                Text("Send Notification")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
