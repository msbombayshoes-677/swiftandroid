package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AccountStatus
import com.example.data.model.Trade
import com.example.data.model.UserRole
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusBadge
import com.example.ui.theme.ItiOrangeSecondary
import com.example.ui.viewmodels.AuthUiState
import com.example.ui.viewmodels.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    viewModel: AuthViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    var isRegisterMode by remember { mutableStateOf(false) }
    var showForgotPasswordDialog by remember { mutableStateOf(false) }

    // Form inputs
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var parentage by remember { mutableStateOf("") }
    var guardianContact by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var selectedTrade by remember { mutableStateOf<Trade?>(null) }
    var traineeIdInput by remember { mutableStateOf(TextFieldValue("")) }
    var parentPinInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }
    var validationError by remember { mutableStateOf<String?>(null) }

    // Trade defaults to unselected (empty) so user must select from dropdown
    // Removed auto-selection of first trade

    // Home page unique background color (applied to Home Page only)
    val homeBackgroundColor = Color(0xFFE4EDE4)

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = homeBackgroundColor
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(homeBackgroundColor)
                .padding(paddingValues)
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Hero Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary)
                    .padding(horizontal = 24.dp, vertical = 28.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Row 1: Jammu & Kashmir
                    Text(
                        text = "Jammu & Kashmir",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = 0.5.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    // Row 2: Government
                    Text(
                        text = "Government",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White.copy(alpha = 0.9f),
                        letterSpacing = 1.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Row 3: India Emblem Icon
                    Surface(
                        shape = CircleShape,
                        color = Color.White.copy(alpha = 0.15f),
                        modifier = Modifier.size(72.dp)
                    ) {
                        val painter = runCatching { painterResource(id = R.drawable.img_india_emblem) }.getOrNull()
                        if (painter != null) {
                            Image(
                                painter = painter,
                                contentDescription = "Emblem of India",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .padding(8.dp)
                                    .clip(CircleShape)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.AccountBalance,
                                contentDescription = "Emblem of India",
                                tint = Color.White,
                                modifier = Modifier
                                    .padding(12.dp)
                                    .size(48.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Row 4: Industrial Training Institute
                    Text(
                        text = "Industrial Training Institute",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = 0.5.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    // Row 5: ITI ANANTNAG
                    Text(
                        text = "ITI ANANTNAG",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.Black,
                        letterSpacing = 1.2.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Real-time GPS Trainee Attendance System",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Role Selection Tabs
            ScrollableTabRow(
                selectedTabIndex = uiState.selectedRole.ordinal,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(12.dp)),
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                edgePadding = 8.dp,
                divider = {}
            ) {
                UserRole.entries.forEach { role ->
                    val isSelected = uiState.selectedRole == role
                    Tab(
                        selected = isSelected,
                        onClick = {
                            viewModel.selectRoleTab(role)
                            isRegisterMode = false
                            selectedTrade = null
                            confirmPassword = ""
                            validationError = null
                            viewModel.clearMessages()
                        },
                        icon = {
                            Icon(
                                imageVector = when (role) {
                                    UserRole.ADMIN -> Icons.Default.AccountBalance
                                    UserRole.INSTRUCTOR -> Icons.Default.Badge
                                    UserRole.TRAINEE -> Icons.Default.School
                                    UserRole.PARENT -> Icons.Default.FamilyRestroom
                                },
                                contentDescription = null,
                                modifier = Modifier.size(20.dp),
                                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        text = {
                            Text(
                                text = role.displayName,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.sp,
                                maxLines = 1,
                                softWrap = false,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        modifier = Modifier.testTag("tab_role_${role.roleName}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Auth Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    // Title
                    Text(
                        text = when (uiState.selectedRole) {
                            UserRole.ADMIN -> "Institute Portal Login"
                            UserRole.INSTRUCTOR -> if (isRegisterMode) "Instructor Registration" else "Instructor Login"
                            UserRole.TRAINEE -> if (isRegisterMode) "Trainee Admission / Registration" else "Trainee Login"
                            UserRole.PARENT -> "Parent Monitoring Login"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Text(
                        text = when (uiState.selectedRole) {
                            UserRole.ADMIN -> "Enter authorized institute credentials"
                            UserRole.INSTRUCTOR -> if (isRegisterMode) "Register under an active ITI trade (requires Admin approval)" else "Sign in to manage trade attendance & trainees"
                            UserRole.TRAINEE -> if (isRegisterMode) "Register for daily GPS attendance (requires approval)" else "Sign in to mark daily GPS attendance"
                            UserRole.PARENT -> "Enter Trainee ID & Parent Access PIN"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Error & Success alerts
                    val displayError = validationError ?: uiState.errorMessage
                    if (displayError != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Text(
                                text = displayError,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    if (uiState.successMessage != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Text(
                                text = uiState.successMessage ?: "",
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    // Form Fields based on role & mode
                    when (uiState.selectedRole) {
                        UserRole.ADMIN -> {
                            OutlinedTextField(
                                value = email,
                                onValueChange = { email = it },
                                label = { Text("Institute Email") },
                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_admin_email"),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = password,
                                onValueChange = { password = it },
                                label = { Text("Password") },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                trailingIcon = {
                                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                        Icon(
                                            imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = null
                                        )
                                    }
                                },
                                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_admin_password"),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = { viewModel.login(email, password, context) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("btn_admin_login"),
                                enabled = !uiState.isLoading,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                if (uiState.isLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                } else {
                                    Text("Login as Institute", fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            TextButton(
                                onClick = { showForgotPasswordDialog = true },
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            ) {
                                Text("Forgot Institute Password?")
                            }

                            // Quick Demo Admin Autofill helper
                            FilledTonalButton(
                                onClick = {
                                    email = "admin@iti.edu"
                                    password = "password123"
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("btn_autofill_admin")
                            ) {
                                Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Autofill Demo Institute (admin@iti.edu)")
                            }
                        }

                        UserRole.INSTRUCTOR -> {
                            if (isRegisterMode) {
                                OutlinedTextField(
                                    value = name,
                                    onValueChange = { name = it; validationError = null },
                                    label = { Text("Full Name") },
                                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_instructor_name"),
                                    singleLine = true
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = email,
                                    onValueChange = { email = it; validationError = null },
                                    label = { Text("Email Address") },
                                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_instructor_email"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = password,
                                    onValueChange = { password = it; validationError = null },
                                    label = { Text("Password (min 6 chars)") },
                                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                    trailingIcon = {
                                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                            Icon(
                                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                contentDescription = "Toggle Password Visibility"
                                            )
                                        }
                                    },
                                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_instructor_password"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = confirmPassword,
                                    onValueChange = { confirmPassword = it; validationError = null },
                                    label = { Text("Confirm Password") },
                                    leadingIcon = { Icon(Icons.Default.LockReset, contentDescription = null) },
                                    trailingIcon = {
                                        IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                                            Icon(
                                                imageVector = if (confirmPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                contentDescription = "Toggle Confirm Password Visibility"
                                            )
                                        }
                                    },
                                    visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_instructor_confirm_password"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = contact,
                                    onValueChange = { contact = it; validationError = null },
                                    label = { Text("Contact Number") },
                                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_instructor_contact"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                                )
                                Spacer(modifier = Modifier.height(10.dp))

                                // Trade Dropdown
                                TradeDropdownSelector(
                                    trades = uiState.availableTrades,
                                    selectedTrade = selectedTrade,
                                    onTradeSelected = { selectedTrade = it; validationError = null }
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = {
                                        if (name.isBlank()) {
                                            validationError = "Please enter your full name."
                                            return@Button
                                        }
                                        if (email.isBlank() || !email.contains("@")) {
                                            validationError = "Please enter a valid email address."
                                            return@Button
                                        }
                                        if (password.length < 6) {
                                            validationError = "Password must be at least 6 characters."
                                            return@Button
                                        }
                                        if (password != confirmPassword) {
                                            validationError = "Passwords do not match."
                                            return@Button
                                        }
                                        if (contact.isBlank()) {
                                            validationError = "Please enter your contact number."
                                            return@Button
                                        }
                                        if (selectedTrade == null) {
                                            validationError = "Please select a trade."
                                            return@Button
                                        }

                                        validationError = null
                                        viewModel.registerInstructor(
                                            name = name.trim(),
                                            email = email.trim(),
                                            pass = password,
                                            contact = contact.trim(),
                                            tradeId = selectedTrade?.tradeId ?: "",
                                            tradeName = selectedTrade?.tradeName ?: "",
                                            context = context
                                        )
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("btn_instructor_register"),
                                    enabled = !uiState.isLoading,
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    if (uiState.isLoading) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                    } else {
                                        Text("Submit Instructor Registration", fontWeight = FontWeight.Bold)
                                    }
                                }

                                TextButton(
                                    onClick = {
                                        isRegisterMode = false
                                        confirmPassword = ""
                                        validationError = null
                                    },
                                    modifier = Modifier.align(Alignment.CenterHorizontally)
                                ) {
                                    Text("Already registered? Login here")
                                }
                            } else {
                                OutlinedTextField(
                                    value = email,
                                    onValueChange = { email = it },
                                    label = { Text("Instructor Email") },
                                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_instructor_login_email"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedTextField(
                                    value = password,
                                    onValueChange = { password = it },
                                    label = { Text("Password") },
                                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                    trailingIcon = {
                                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                            Icon(
                                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                contentDescription = "Toggle Password Visibility"
                                            )
                                        }
                                    },
                                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_instructor_login_password"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = { viewModel.login(email, password, context) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("btn_instructor_login"),
                                    enabled = !uiState.isLoading,
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    if (uiState.isLoading) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                    } else {
                                        Text("Login as Instructor", fontWeight = FontWeight.Bold)
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    TextButton(onClick = { showForgotPasswordDialog = true }) {
                                        Text("Forgot Password?")
                                    }
                                    TextButton(onClick = {
                                        isRegisterMode = true
                                        selectedTrade = null
                                        confirmPassword = ""
                                        validationError = null
                                    }) {
                                        Text("New Instructor? Register")
                                    }
                                }
                            }
                        }

                        UserRole.TRAINEE -> {
                            if (isRegisterMode) {
                                OutlinedTextField(
                                    value = name,
                                    onValueChange = { name = it; validationError = null },
                                    label = { Text("Trainee Full Name") },
                                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_trainee_name"),
                                    singleLine = true
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = parentage,
                                    onValueChange = { parentage = it; validationError = null },
                                    label = { Text("Parentage (Father / Guardian Name)") },
                                    leadingIcon = { Icon(Icons.Default.FamilyRestroom, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_trainee_parentage"),
                                    singleLine = true
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = guardianContact,
                                    onValueChange = { guardianContact = it; validationError = null },
                                    label = { Text("Father/Guardian No.") },
                                    placeholder = { Text("e.g. 9876543210") },
                                    leadingIcon = { Icon(Icons.Default.PhoneIphone, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_trainee_guardian_contact"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = email,
                                    onValueChange = { email = it; validationError = null },
                                    label = { Text("Email Address") },
                                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_trainee_email"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = password,
                                    onValueChange = { password = it; validationError = null },
                                    label = { Text("Password (min 6 chars)") },
                                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                    trailingIcon = {
                                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                            Icon(
                                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                contentDescription = "Toggle Password Visibility"
                                            )
                                        }
                                    },
                                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_trainee_password"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = confirmPassword,
                                    onValueChange = { confirmPassword = it; validationError = null },
                                    label = { Text("Confirm Password") },
                                    leadingIcon = { Icon(Icons.Default.LockReset, contentDescription = null) },
                                    trailingIcon = {
                                        IconButton(onClick = { confirmPasswordVisible = !confirmPasswordVisible }) {
                                            Icon(
                                                imageVector = if (confirmPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                contentDescription = "Toggle Confirm Password Visibility"
                                            )
                                        }
                                    },
                                    visualTransformation = if (confirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_trainee_confirm_password"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = contact,
                                    onValueChange = { contact = it; validationError = null },
                                    label = { Text("Contact Number") },
                                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_trainee_contact"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = address,
                                    onValueChange = { address = it; validationError = null },
                                    label = { Text("Residential Address") },
                                    leadingIcon = { Icon(Icons.Default.Home, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_trainee_address"),
                                    singleLine = true
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                // Trade Dropdown
                                TradeDropdownSelector(
                                    trades = uiState.availableTrades,
                                    selectedTrade = selectedTrade,
                                    onTradeSelected = { selectedTrade = it; validationError = null }
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = {
                                        if (name.isBlank()) {
                                            validationError = "Please enter your full name."
                                            return@Button
                                        }
                                        if (parentage.isBlank()) {
                                            validationError = "Please enter parentage (father / guardian name)."
                                            return@Button
                                        }
                                        if (email.isBlank() || !email.contains("@")) {
                                            validationError = "Please enter a valid email address."
                                            return@Button
                                        }
                                        if (password.length < 6) {
                                            validationError = "Password must be at least 6 characters."
                                            return@Button
                                        }
                                        if (password != confirmPassword) {
                                            validationError = "Passwords do not match."
                                            return@Button
                                        }
                                        if (contact.isBlank()) {
                                            validationError = "Please enter your contact number."
                                            return@Button
                                        }
                                        if (address.isBlank()) {
                                            validationError = "Please enter residential address."
                                            return@Button
                                        }
                                        if (selectedTrade == null) {
                                            validationError = "Please select a trade."
                                            return@Button
                                        }

                                        validationError = null
                                        viewModel.registerTrainee(
                                            name = name.trim(),
                                            parentage = parentage.trim(),
                                            guardianContact = guardianContact.trim(),
                                            email = email.trim(),
                                            pass = password,
                                            contact = contact.trim(),
                                            address = address.trim(),
                                            tradeId = selectedTrade?.tradeId ?: "",
                                            tradeName = selectedTrade?.tradeName ?: "",
                                            instructorId = "",
                                            instructorName = "",
                                            context = context
                                        )
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("btn_trainee_register"),
                                    enabled = !uiState.isLoading,
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    if (uiState.isLoading) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                    } else {
                                        Text("Submit Trainee Admission", fontWeight = FontWeight.Bold)
                                    }
                                }

                                TextButton(
                                    onClick = {
                                        isRegisterMode = false
                                        confirmPassword = ""
                                        validationError = null
                                    },
                                    modifier = Modifier.align(Alignment.CenterHorizontally)
                                ) {
                                    Text("Already registered? Login here")
                                }
                            } else {
                                OutlinedTextField(
                                    value = email,
                                    onValueChange = { email = it },
                                    label = { Text("Trainee Email") },
                                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_trainee_login_email"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedTextField(
                                    value = password,
                                    onValueChange = { password = it },
                                    label = { Text("Password") },
                                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                    trailingIcon = {
                                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                            Icon(
                                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                contentDescription = "Toggle Password Visibility"
                                            )
                                        }
                                    },
                                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("input_trainee_login_password"),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = { viewModel.login(email, password, context) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("btn_trainee_login"),
                                    enabled = !uiState.isLoading,
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    if (uiState.isLoading) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                    } else {
                                        Text("Login as Trainee", fontWeight = FontWeight.Bold)
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    TextButton(onClick = { showForgotPasswordDialog = true }) {
                                        Text("Forgot Password?")
                                    }
                                    TextButton(onClick = {
                                        isRegisterMode = true
                                        selectedTrade = null
                                        confirmPassword = ""
                                        validationError = null
                                    }) {
                                        Text("New Trainee? Register")
                                    }
                                }
                            }
                        }

                        UserRole.PARENT -> {
                            OutlinedTextField(
                                value = traineeIdInput,
                                onValueChange = { traineeIdInput = formatTraineeIdTextFieldValue(it) },
                                label = { Text("Trainee ID (e.g. ITI-2026-00001)") },
                                leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_parent_trainee_id"),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = parentPinInput,
                                onValueChange = { parentPinInput = it },
                                label = { Text("4-Digit Parent Access PIN") },
                                leadingIcon = { Icon(Icons.Default.Pin, contentDescription = null) },
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_parent_pin"),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = { viewModel.parentLogin(traineeIdInput.text, parentPinInput, context) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("btn_parent_login"),
                                enabled = !uiState.isLoading,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                if (uiState.isLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                } else {
                                    Text("Monitor Trainee Attendance", fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Note: The 4-digit Parent PIN is provided upon trainee admission approval.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            // Pending Approval Notification Banner if applicable
            val pendingProfileStatus = uiState.currentInstructor?.status ?: uiState.currentTrainee?.status
            if (pendingProfileStatus == AccountStatus.PENDING.statusName) {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.HourglassTop, contentDescription = null, tint = ItiOrangeSecondary, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Account Awaiting Institute Approval",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Your registration has been submitted. Daily attendance marking will be unlocked once approved by the ITI Administration / Trade Instructor.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        FilledTonalButton(onClick = { viewModel.refreshProfile() }) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Check Approval Status")
                        }
                    }
                }
            } else if (pendingProfileStatus == AccountStatus.INACTIVE.statusName || pendingProfileStatus == "deactivated") {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Block, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Account Deactivated",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Your trainee account has been deactivated by your instructor. You cannot access your profile while deactivated. Please contact your instructor to reactivate your account.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.85f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        FilledTonalButton(onClick = { viewModel.refreshProfile() }) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Check Activation Status")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Developer Credit
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Developed By: V/I NAJEEB REHMAN :   Principal: Er. BILAL AHMAD WANI",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("developer_credit_auth")
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Forgot Password Dialog
    if (showForgotPasswordDialog) {
        val isTrainee = uiState.selectedRole == UserRole.TRAINEE
        var resetMethod by remember(uiState.selectedRole) { mutableStateOf(if (isTrainee) 0 else 1) } // 0: Instant Phone Reset (Trainee only), 1: Email Link
        var resetEmail by remember { mutableStateOf(email) }
        var resetContact by remember { mutableStateOf("") }
        var parentPinResetInput by remember { mutableStateOf("") }
        var newResetPassword by remember { mutableStateOf("") }
        var confirmResetPassword by remember { mutableStateOf("") }
        var resetPassVisible by remember { mutableStateOf(false) }
        var localDialogError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = {
                showForgotPasswordDialog = false
                localDialogError = null
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LockReset,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Recover / Reset Password", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    // Method Selector Tabs (Only shown for Trainee)
                    if (isTrainee) {
                        PrimaryTabRow(
                            selectedTabIndex = resetMethod,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Tab(
                                selected = resetMethod == 0,
                                onClick = { resetMethod = 0; localDialogError = null },
                                text = { Text("Instant Phone Reset", fontSize = 12.sp, fontWeight = if (resetMethod == 0) FontWeight.Bold else FontWeight.Normal) }
                            )
                            Tab(
                                selected = resetMethod == 1,
                                onClick = { resetMethod = 1; localDialogError = null },
                                text = { Text("Email Reset Link", fontSize = 12.sp, fontWeight = if (resetMethod == 1) FontWeight.Bold else FontWeight.Normal) }
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    if (localDialogError != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        ) {
                            Text(
                                text = localDialogError ?: "",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    if (resetMethod == 0) {
                        // Instant Phone Reset
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FlashOn,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (uiState.selectedRole == UserRole.TRAINEE)
                                        "Reset password instantly by verifying your registered 10-digit mobile number and 4-digit parent access pin."
                                    else
                                        "Reset password instantly by verifying your registered 10-digit mobile number.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = resetEmail,
                            onValueChange = { resetEmail = it; localDialogError = null },
                            label = { Text("Registered Email Address") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_reset_email"),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = resetContact,
                            onValueChange = { resetContact = it.filter { ch -> ch.isDigit() }.take(10); localDialogError = null },
                            label = { Text("Registered Mobile Number (10 digits)") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_reset_contact"),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                        )

                        if (uiState.selectedRole == UserRole.TRAINEE) {
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = parentPinResetInput,
                                onValueChange = { parentPinResetInput = it.filter { ch -> ch.isDigit() }.take(4); localDialogError = null },
                                label = { Text("4-Digit Parent Access PIN") },
                                leadingIcon = { Icon(Icons.Default.Pin, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_reset_parent_pin"),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = newResetPassword,
                            onValueChange = { newResetPassword = it; localDialogError = null },
                            label = { Text("New Password (min 6 chars)") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            trailingIcon = {
                                IconButton(onClick = { resetPassVisible = !resetPassVisible }) {
                                    Icon(
                                        imageVector = if (resetPassVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = null
                                    )
                                }
                            },
                            visualTransformation = if (resetPassVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_reset_new_password"),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = confirmResetPassword,
                            onValueChange = { confirmResetPassword = it; localDialogError = null },
                            label = { Text("Confirm New Password") },
                            leadingIcon = { Icon(Icons.Default.LockClock, contentDescription = null) },
                            visualTransformation = if (resetPassVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_reset_confirm_password"),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )
                    } else {
                        // Email Reset Link
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    text = "A password recovery email will be dispatched to your registered address.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "⚠️ SENDER: noreply@itianantnag-6d0cd.firebaseapp.com\nPlease check SPAM / JUNK / PROMOTIONS folder if not found in Inbox.",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = resetEmail,
                            onValueChange = { resetEmail = it; localDialogError = null },
                            label = { Text("Registered Email Address") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_reset_email_only"),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (resetMethod == 0) {
                            if (resetEmail.isBlank()) {
                                localDialogError = "Please enter your registered email address."
                                return@Button
                            }
                            if (resetContact.length < 10) {
                                localDialogError = "Please enter your 10-digit registered mobile number."
                                return@Button
                            }
                            if (newResetPassword.length < 6) {
                                localDialogError = "New password must be at least 6 characters."
                                return@Button
                            }
                            if (newResetPassword != confirmResetPassword) {
                                localDialogError = "New password and confirm password do not match."
                                return@Button
                            }
                            if (uiState.selectedRole == UserRole.TRAINEE) {
                                if (parentPinResetInput.length != 4) {
                                    localDialogError = "Please enter your 4-digit Parent Access PIN."
                                    return@Button
                                }
                                viewModel.resetTraineePasswordWithMobileAndPin(
                                    email = resetEmail,
                                    contact = resetContact,
                                    parentAccessPin = parentPinResetInput,
                                    newPassword = newResetPassword,
                                    onSuccess = {
                                        email = resetEmail
                                        password = newResetPassword
                                        showForgotPasswordDialog = false
                                    }
                                )
                            } else {
                                viewModel.resetInstructorPasswordWithMobile(
                                    email = resetEmail,
                                    contact = resetContact,
                                    newPassword = newResetPassword,
                                    onSuccess = {
                                        email = resetEmail
                                        password = newResetPassword
                                        showForgotPasswordDialog = false
                                    }
                                )
                            }
                        } else {
                            if (resetEmail.isBlank()) {
                                localDialogError = "Please enter your registered email address."
                                return@Button
                            }
                            viewModel.sendPasswordReset(resetEmail)
                            showForgotPasswordDialog = false
                        }
                    },
                    modifier = Modifier.testTag("btn_confirm_reset_password")
                ) {
                    if (uiState.isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White)
                    } else {
                        Text(if (resetMethod == 0) "Reset Password Now" else "Send Reset Email")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showForgotPasswordDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Password Reset Result Dialog
    if (uiState.isPasswordResetSent) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissPasswordResetSent() },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(48.dp)
                )
            },
            title = {
                Text(
                    text = "Password Reset Status",
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = uiState.successMessage ?: "Password reset instructions have been processed.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "💡 Didn't receive the email?",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "1. Check your SPAM / JUNK / PROMOTIONS folder.\n2. Search your mailbox for 'itianantnag'.\n3. Use 'Instant Phone Reset' to update password directly without waiting for email.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.dismissPasswordResetSent() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Continue to Login")
                }
            }
        )
    }

    // Registration Successful Popup Dialog (Wait for Approval)
    if (uiState.isRegisteredPending) {
        AlertDialog(
            onDismissRequest = {
                viewModel.dismissRegistrationPending()
                isRegisterMode = false
            },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(48.dp)
                )
            },
            title = {
                Text(
                    text = "Registration Successful!",
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = uiState.successMessage ?: "Your registration details have been submitted successfully.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.HourglassEmpty,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Awaiting Approval:\nYour account registration has been submitted for administration approval. Please wait for approval before logging in.",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.dismissRegistrationPending()
                        isRegisterMode = false
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_dismiss_registration_success")
                ) {
                    Text("OK, Got It", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeDropdownSelector(
    trades: List<Trade>,
    selectedTrade: Trade?,
    onTradeSelected: (Trade) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
        modifier = Modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = selectedTrade?.tradeName ?: "",
            placeholder = { Text("Select ITI Trade") },
            onValueChange = {},
            readOnly = true,
            label = { Text("Trade") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
                .testTag("dropdown_trade_selector")
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            trades.forEach { trade ->
                DropdownMenuItem(
                    text = {
                        Column {
                            Text(trade.tradeName, fontWeight = FontWeight.Bold)
                            Text("${trade.tradeCode} • ${trade.scheme} (${trade.duration})", style = MaterialTheme.typography.bodySmall)
                        }
                    },
                    onClick = {
                        onTradeSelected(trade)
                        expanded = false
                    },
                    modifier = Modifier.testTag("dropdown_item_${trade.tradeId}")
                )
            }
        }
    }
}

private fun rawToFormattedIndex(cleanIndex: Int): Int {
    return when {
        cleanIndex <= 3 -> cleanIndex
        cleanIndex in 4..7 -> cleanIndex + 1
        else -> (cleanIndex + 2).coerceAtMost(14)
    }
}

private fun formatTraineeIdTextFieldValue(newValue: TextFieldValue): TextFieldValue {
    val clean = newValue.text.uppercase().filter { it.isLetterOrDigit() }.take(12)
    val sb = StringBuilder()
    for (i in clean.indices) {
        if (i == 3 || i == 7) {
            sb.append('-')
        }
        sb.append(clean[i])
    }
    val formattedText = sb.toString()

    val cursorEnd = newValue.selection.end.coerceAtMost(newValue.text.length)
    val cleanCharsBeforeCursor = newValue.text.substring(0, cursorEnd)
        .filter { it.isLetterOrDigit() }
        .length
        .coerceAtMost(clean.length)

    val newCursorPos = rawToFormattedIndex(cleanCharsBeforeCursor).coerceAtMost(formattedText.length)

    return TextFieldValue(
        text = formattedText,
        selection = TextRange(newCursorPos)
    )
}
