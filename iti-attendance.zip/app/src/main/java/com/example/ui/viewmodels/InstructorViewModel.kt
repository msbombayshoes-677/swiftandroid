package com.example.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AttendanceRecord
import com.example.data.model.DashboardStats
import com.example.data.model.InstituteNotification
import com.example.data.model.DiaryNote
import com.example.data.model.InstructorProfile
import com.example.data.model.InstituteSettings
import com.example.data.model.Trade
import com.example.data.model.TraineeProfile
import com.example.data.repository.AttendanceRepository
import com.example.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

data class TraineeAttendanceStat(
    val trainee: TraineeProfile,
    val presentDays: Int,
    val totalDays: Int,
    val percentage: Double
)

data class InstructorUiState(
    val isLoading: Boolean = false,
    val instructorProfile: InstructorProfile? = null,
    val currentTrade: Trade? = null,
    val stats: DashboardStats = DashboardStats(),
    val myTrainees: List<TraineeProfile> = emptyList(),
    val pendingTrainees: List<TraineeProfile> = emptyList(),
    val todayAttendance: List<AttendanceRecord> = emptyList(),
    val selectedDate: String = DateUtils.getTodayDateString(),
    val notifications: List<InstituteNotification> = emptyList(),
    val receivedAdminNotifications: List<InstituteNotification> = emptyList(),
    val diaryNotes: List<DiaryNote> = emptyList(),
    val searchQuery: String = "",
    val filterStatus: String = "all", // all, present, absent, late, pending
    val goodAttendanceCount: Int = 0,
    val poorAttendanceCount: Int = 0,
    val monthlyTraineeStats: List<TraineeAttendanceStat> = emptyList(),
    val monthlyTradeAttendancePercentage: Double = 0.0,
    val monthlyRecordedDaysCount: Int = 0,
    val message: String? = null,
    val error: String? = null,
    val selectedTraineeForHistory: TraineeProfile? = null,
    val traineeHistory: List<AttendanceRecord> = emptyList(),
    val instituteSettings: InstituteSettings = InstituteSettings()
)

class InstructorViewModel(
    private val repo: AttendanceRepository = AttendanceRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(InstructorUiState())
    val uiState: StateFlow<InstructorUiState> = _uiState.asStateFlow()

    fun setInstructor(instructor: InstructorProfile) {
        _uiState.update { it.copy(instructorProfile = instructor) }
        loadInstructorData(instructor.tradeId)
    }

    fun loadInstructorData(tradeId: String) {
        if (tradeId.isBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            
            // Fetch everything in parallel using async
            val currentMonthStr = DateUtils.getTodayDateString().take(7)
            val instructorUid = _uiState.value.instructorProfile?.uid
            val profileDeferred = async { if (!instructorUid.isNullOrBlank()) repo.getInstructorProfile(instructorUid) else null }
            val tradeDeferred = async { repo.getTrade(tradeId) }
            val statsDeferred = async { repo.getTradeStats(tradeId) }
            val traineesDeferred = async { repo.getTraineesByTrade(tradeId) }
            val pendingDeferred = async { repo.getPendingTraineesByTrade(tradeId) }
            val attendanceDeferred = async { repo.getTradeAttendance(tradeId, _uiState.value.selectedDate) }
            val monthlyAttendanceDeferred = async { repo.getTradeMonthlyAttendance(tradeId, currentMonthStr) }
            val notifsDeferred = async { repo.getInstructorSentNotifications(instructorUid = instructorUid ?: "", tradeId = tradeId) }
            val adminNotifsDeferred = async { repo.getAllNotifications() }
            val diaryDeferred = async { repo.getDiaryNotesForTrade(tradeId) }
            val settingsDeferred = async { repo.getInstituteSettings() }

            // Await all results simultaneously
            val freshProfile = profileDeferred.await()
            val currentTrade = tradeDeferred.await()
            val stats = statsDeferred.await()
            val trainees = traineesDeferred.await()
            val pending = pendingDeferred.await()
            val attendance = attendanceDeferred.await()
            val monthlyAttendance = monthlyAttendanceDeferred.await()
            val notifs = notifsDeferred.await()
            val allInstituteNotifs = adminNotifsDeferred.await()
            val instituteSettings = settingsDeferred.await()
            val adminNotifs = allInstituteNotifs.filter { notif ->
                val isNotFromCurrentInstructor = notif.senderUserId != instructorUid &&
                        !notif.senderRole.equals("instructor", ignoreCase = true) &&
                        !notif.senderName.contains("Instructor", ignoreCase = true)

                val isNotSystem = notif.senderName != "Attendance Engine" &&
                        !notif.senderName.contains("Engine", ignoreCase = true) &&
                        !notif.senderName.contains("System", ignoreCase = true)

                val isNotAutomated = !notif.title.contains("Late Punch", ignoreCase = true) &&
                        !notif.title.contains("Punch", ignoreCase = true) &&
                        !notif.title.contains("Account Approved", ignoreCase = true) &&
                        !notif.title.contains("Registration Approved", ignoreCase = true) &&
                        !notif.title.contains("Approved", ignoreCase = true) &&
                        !notif.title.contains("Rejected", ignoreCase = true) &&
                        !notif.title.contains("Diary Note", ignoreCase = true) &&
                        !notif.title.contains("Attendance", ignoreCase = true)

                val matchesTrade = notif.targetTradeId.isNullOrBlank() || notif.targetTradeId == tradeId
                val matchesUser = notif.targetUserId.isNullOrBlank() || notif.targetUserId == instructorUid

                isNotFromCurrentInstructor && isNotSystem && isNotAutomated && matchesTrade && matchesUser
            }
            val diary = diaryDeferred.await()

            val approvedTrainees = trainees.filter { it.status == "approved" }
            val distinctRecordedDates = monthlyAttendance.map { it.date }.distinct()
            val totalRecordedDays = distinctRecordedDates.size

            var goodCount = 0
            var poorCount = 0
            var totalPresentOrLateSum = 0
            var totalPossiblePunches = 0
            val traineeStatsList = mutableListOf<TraineeAttendanceStat>()

            if (approvedTrainees.isNotEmpty() && totalRecordedDays > 0) {
                approvedTrainees.forEach { trainee ->
                    val traineeRecords = monthlyAttendance.filter { it.traineeId == trainee.uid }
                    val presentDays = traineeRecords.count { it.attendanceStatus == "present" || it.attendanceStatus == "late" }
                    totalPresentOrLateSum += presentDays
                    val rate = (presentDays.toDouble() / totalRecordedDays.toDouble()) * 100.0
                    if (rate >= 80.0) {
                        goodCount++
                    }
                    if (rate <= 60.0) {
                        poorCount++
                    }
                    traineeStatsList.add(
                        TraineeAttendanceStat(
                            trainee = trainee,
                            presentDays = presentDays,
                            totalDays = totalRecordedDays,
                            percentage = rate
                        )
                    )
                }
                totalPossiblePunches = approvedTrainees.size * totalRecordedDays
            } else if (approvedTrainees.isNotEmpty()) {
                approvedTrainees.forEach { trainee ->
                    traineeStatsList.add(
                        TraineeAttendanceStat(
                            trainee = trainee,
                            presentDays = 0,
                            totalDays = 0,
                            percentage = 0.0
                        )
                    )
                }
            }

            val monthlyTradePct = if (totalPossiblePunches > 0) {
                (totalPresentOrLateSum.toDouble() / totalPossiblePunches.toDouble()) * 100.0
            } else 0.0

            val resolvedTradeName = currentTrade?.tradeName?.ifBlank { null }
                ?: freshProfile?.tradeName?.ifBlank { null }
                ?: _uiState.value.instructorProfile?.tradeName ?: ""

            val updatedProfile = (freshProfile ?: _uiState.value.instructorProfile)?.copy(
                tradeName = resolvedTradeName
            )

            _uiState.update {
                it.copy(
                    isLoading = false,
                    instructorProfile = updatedProfile,
                    currentTrade = currentTrade,
                    stats = stats,
                    myTrainees = trainees,
                    pendingTrainees = pending,
                    todayAttendance = attendance,
                    goodAttendanceCount = goodCount,
                    poorAttendanceCount = poorCount,
                    monthlyTraineeStats = traineeStatsList,
                    monthlyTradeAttendancePercentage = monthlyTradePct,
                    monthlyRecordedDaysCount = totalRecordedDays,
                    notifications = notifs,
                    receivedAdminNotifications = adminNotifs,
                    diaryNotes = diary,
                    instituteSettings = instituteSettings
                )
            }
        }
    }

    fun addDiaryNote(traineeId: String, traineeName: String, title: String, content: String) {
        val instructor = _uiState.value.instructorProfile ?: return
        val currentTradeName = _uiState.value.currentTrade?.tradeName?.ifBlank { null } ?: instructor.tradeName
        if (title.isBlank() || content.isBlank() || traineeId.isBlank()) {
            _uiState.update { it.copy(error = "Trainee, Title, and Content are required.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.addDiaryNote(
                traineeId = traineeId,
                traineeName = traineeName,
                tradeId = instructor.tradeId,
                tradeName = currentTradeName,
                instructorId = instructor.uid,
                instructorName = instructor.name,
                title = title,
                content = content
            )
            if (success) {
                _uiState.update { it.copy(message = "Diary note added successfully.") }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to add diary note.") }
            }
        }
    }

    fun deleteDiaryNote(noteId: String) {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteDiaryNote(noteId)
            if (success) {
                _uiState.update { it.copy(message = "Diary note deleted successfully.") }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete diary note.") }
            }
        }
    }

    fun updateDiaryNote(noteId: String, title: String, content: String) {
        val instructor = _uiState.value.instructorProfile ?: return
        if (title.isBlank() || content.isBlank() || noteId.isBlank()) {
            _uiState.update { it.copy(error = "Title and Content are required.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.updateDiaryNote(noteId, title, content)
            if (success) {
                _uiState.update { it.copy(message = "Diary note updated successfully.") }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to update diary note.") }
            }
        }
    }

    fun selectDate(date: String) {
        val tradeId = _uiState.value.instructorProfile?.tradeId ?: return
        viewModelScope.launch {
            val records = repo.getTradeAttendance(tradeId, date)
            _uiState.update { it.copy(selectedDate = date, todayAttendance = records) }
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setFilterStatus(status: String) {
        _uiState.update { it.copy(filterStatus = status) }
    }

    fun approveTrainee(traineeUid: String) {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.approveTrainee(traineeUid, instructor.uid, instructor.name, "instructor")
            if (success) {
                _uiState.update { it.copy(message = "Trainee approved and assigned unique Trainee ID.") }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to approve trainee.") }
            }
        }
    }

    fun rejectTrainee(traineeUid: String, reason: String) {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.rejectTrainee(traineeUid, reason, instructor.uid, instructor.name, "instructor")
            if (success) {
                _uiState.update { it.copy(message = "Trainee application rejected.") }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to reject trainee.") }
            }
        }
    }

    fun correctAttendance(
        record: AttendanceRecord,
        newStatus: String,
        reason: String
    ) {
        val instructor = _uiState.value.instructorProfile ?: return
        if (reason.isBlank()) {
            _uiState.update { it.copy(error = "Correction reason is mandatory for the audit log.") }
            return
        }

        viewModelScope.launch {
            val success = repo.manualCorrectAttendance(
                attendanceId = record.attendanceId,
                traineeUid = record.traineeId,
                traineeUniqueId = record.traineeUniqueId,
                traineeName = record.traineeName,
                date = record.date,
                oldStatus = record.attendanceStatus,
                newStatus = newStatus,
                reason = reason,
                reviewerId = instructor.uid,
                reviewerName = instructor.name,
                reviewerRole = "instructor"
            )
            if (success) {
                _uiState.update { it.copy(message = "Attendance corrected and logged in audit trail.") }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(error = "Failed to update attendance correction.") }
            }
        }
    }

    fun viewTraineeHistory(trainee: TraineeProfile) {
        viewModelScope.launch {
            _uiState.update { it.copy(selectedTraineeForHistory = trainee, isLoading = true) }
            val history = repo.getTraineeAttendanceHistory(trainee.uid, trainee.traineeId)
            _uiState.update { it.copy(traineeHistory = history, isLoading = false) }
        }
    }

    fun clearTraineeHistorySelection() {
        _uiState.update { it.copy(selectedTraineeForHistory = null, traineeHistory = emptyList()) }
    }

    fun updateTraineeDetails(
        traineeUid: String,
        name: String,
        parentage: String,
        contact: String,
        guardianContact: String,
        address: String,
        onSuccess: (() -> Unit)? = null
    ) {
        val instructor = _uiState.value.instructorProfile ?: return
        val existingTrainee = _uiState.value.myTrainees.find { it.uid == traineeUid }
        val email = existingTrainee?.email ?: ""
        val parentAccessPin = existingTrainee?.parentAccessPin ?: "1234"

        if (name.isBlank()) {
            _uiState.update { it.copy(error = "Trainee name is required.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.updateTraineeProfile(
                traineeUid = traineeUid,
                name = name,
                parentage = parentage,
                contact = contact,
                guardianContact = guardianContact,
                email = email,
                address = address,
                parentAccessPin = parentAccessPin,
                updatedBy = instructor.uid,
                updatedByName = instructor.name,
                updatedByRole = "instructor"
            )
            if (success) {
                _uiState.update { it.copy(message = "Trainee details updated successfully.") }
                loadInstructorData(instructor.tradeId)
                onSuccess?.invoke()
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to update trainee details.") }
            }
        }
    }

    fun toggleTraineeStatus(traineeUid: String, currentStatus: String, onSuccess: (() -> Unit)? = null) {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.toggleTraineeStatus(
                traineeUid = traineeUid,
                currentStatus = currentStatus,
                adminId = instructor.uid,
                adminName = instructor.name
            )
            if (success) {
                val newStatus = if (currentStatus.equals("approved", ignoreCase = true)) "inactive" else "approved"
                val actionWord = if (newStatus == "approved") "activated" else "deactivated"
                _uiState.update { state ->
                    val updatedList = state.myTrainees.map {
                        if (it.uid == traineeUid) it.copy(status = newStatus) else it
                    }
                    state.copy(
                        isLoading = false,
                        myTrainees = updatedList,
                        message = "Trainee $actionWord successfully."
                    )
                }
                onSuccess?.invoke()
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to update trainee status.") }
            }
        }
    }

    suspend fun getAttendanceForDate(date: String): List<AttendanceRecord> {
        val instructor = _uiState.value.instructorProfile ?: return emptyList()
        val tradeId = instructor.tradeId
        val tradeName = _uiState.value.currentTrade?.tradeName?.ifBlank { null } ?: instructor.tradeName
        val traineeUids = _uiState.value.myTrainees.map { it.uid }.toSet() + _uiState.value.myTrainees.map { it.traineeId }.toSet()
        return repo.getTradeAttendance(
            tradeId = tradeId,
            date = date,
            tradeName = tradeName,
            traineeUids = traineeUids
        )
    }

    suspend fun getMonthlyAttendance(yearMonth: String): List<AttendanceRecord> {
        val instructor = _uiState.value.instructorProfile ?: return emptyList()
        val tradeId = instructor.tradeId
        val tradeName = _uiState.value.currentTrade?.tradeName?.ifBlank { null } ?: instructor.tradeName
        val traineeUids = _uiState.value.myTrainees.map { it.uid }.toSet() + _uiState.value.myTrainees.map { it.traineeId }.toSet()
        return repo.getTradeMonthlyAttendance(
            tradeId = tradeId,
            yearMonth = yearMonth,
            tradeName = tradeName,
            traineeUids = traineeUids
        )
    }

    fun sendTradeBroadcastNotification(
        title: String,
        message: String,
        targetUserId: String? = null,
        onSuccess: (() -> Unit)? = null
    ) {
        val instructor = _uiState.value.instructorProfile ?: return
        if (title.isBlank() || message.isBlank()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val senderLabel = "Instructor ${instructor.name} (${instructor.tradeName})"
            val success = repo.sendNotification(
                title = title,
                message = message,
                targetRole = "trainee",
                targetTradeId = instructor.tradeId,
                targetUserId = targetUserId,
                senderName = senderLabel,
                senderRole = "instructor",
                senderUserId = instructor.uid
            )
            if (success) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        message = "Broadcast notification sent successfully!"
                    )
                }
                onSuccess?.invoke()
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to send broadcast notification.") }
            }
        }
    }

    fun deleteNotification(notificationId: String) {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteNotification(notificationId)
            if (success) {
                _uiState.update { state ->
                    val updatedNotifs = state.notifications.filter { it.notificationId != notificationId }
                    state.copy(isLoading = false, notifications = updatedNotifs, message = "Notification deleted successfully.")
                }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete notification.") }
            }
        }
    }

    fun deleteNotifications(notificationIds: List<String>) {
        if (notificationIds.isEmpty()) return
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteNotifications(notificationIds)
            if (success) {
                _uiState.update { state ->
                    val updatedNotifs = state.notifications.filter { it.notificationId !in notificationIds }
                    state.copy(isLoading = false, notifications = updatedNotifs, message = "Notifications deleted successfully.")
                }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete notifications.") }
            }
        }
    }

    fun deleteAllNotifications() {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteInstructorNotifications(instructor.uid, instructor.tradeId)
            if (success) {
                _uiState.update { state ->
                    state.copy(isLoading = false, notifications = emptyList(), message = "All sent notifications deleted.")
                }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete notifications.") }
            }
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(message = null, error = null) }
    }
}
