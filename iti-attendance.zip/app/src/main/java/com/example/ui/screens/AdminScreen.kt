package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountStatus
import com.example.data.model.AdminProfile
import com.example.data.model.AttendanceRecord
import com.example.data.model.Holiday
import com.example.data.model.InstituteNotification
import com.example.data.model.InstructorProfile
import com.example.data.model.Trade
import com.example.data.model.TraineeProfile
import com.example.data.model.sortedByTraineeIdAscending
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodels.AdminViewModel
import com.example.util.CsvExportUtils
import com.example.util.DateUtils
import com.example.util.NotificationPreferenceManager

enum class AdminTab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard),
    ATTENDANCE("Attendance", Icons.Default.EventAvailable),
    REPORTS("Reports", Icons.Default.Assessment),
    DIARY("Diary", Icons.Default.MenuBook),
    TRADES("Trades", Icons.Default.Engineering),
    INSTRUCTORS("Instructors", Icons.Default.Badge),
    TRAINEES("Trainees", Icons.Default.School),
    NOTIFICATIONS("Notifications", Icons.Default.Campaign),
    AUDIT("Corrections & System Log", Icons.Default.History),
    ADD_ADMIN("Add Admin", Icons.Default.PersonAdd),
    SETTINGS("Settings", Icons.Default.Settings)
}

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun AdminScreen(
    admin: AdminProfile,
    viewModel: AdminViewModel,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf(AdminTab.DASHBOARD) }

    LaunchedEffect(selectedTab) {
        when (selectedTab) {
            AdminTab.INSTRUCTORS -> {
                viewModel.loadInstructorsData()
                viewModel.loadTradesData()
                viewModel.loadTraineesData()
            }
            AdminTab.TRADES -> {
                viewModel.loadTradesData()
                viewModel.loadInstructorsData()
                viewModel.loadTraineesData()
            }
            AdminTab.TRAINEES -> viewModel.loadTraineesData()
            AdminTab.DIARY -> viewModel.loadDiaryData()
            AdminTab.REPORTS -> {
                viewModel.loadTradesData()
                viewModel.loadTraineesData()
            }
            else -> {}
        }
    }

    val context = LocalContext.current
    var acknowledgedNotifIds by remember {
        mutableStateOf(NotificationPreferenceManager.getAcknowledgedNotificationIds(context, "admin"))
    }
    val unacknowledgedNotifs = remember(uiState.notifications, acknowledgedNotifIds) {
        uiState.notifications.filter {
            it.senderRole != "admin" &&
            (it.targetRole == "all" || it.targetRole.equals("admin", ignoreCase = true)) &&
            it.notificationId !in acknowledgedNotifIds
        }
    }

    // Dialog states
    var showAddTradeDialog by remember { mutableStateOf(false) }
    var tradeCreatedSuccessName by remember { mutableStateOf<String?>(null) }
    var showBroadcastDialog by remember { mutableStateOf(false) }
    var rejectionTargetId by remember { mutableStateOf<String?>(null) }
    var isRejectingInstructor by remember { mutableStateOf(false) }
    var rejectionReason by remember { mutableStateOf("") }
    var tradeToDelete by remember { mutableStateOf<Trade?>(null) }
    var tradeToEdit by remember { mutableStateOf<Trade?>(null) }
    var instructorToDelete by remember { mutableStateOf<InstructorProfile?>(null) }
    var instructorToModify by remember { mutableStateOf<InstructorProfile?>(null) }
    var instructorModifiedSuccessName by remember { mutableStateOf<String?>(null) }
    var traineeToDelete by remember { mutableStateOf<TraineeProfile?>(null) }
    var traineeToModify by remember { mutableStateOf<TraineeProfile?>(null) }
    var traineeModifiedSuccessName by remember { mutableStateOf<String?>(null) }
    var traineeForDiaryNote by remember { mutableStateOf<TraineeProfile?>(null) }
    var diaryNoteToEdit by remember { mutableStateOf<com.example.data.model.DiaryNote?>(null) }
    var diaryNoteToDelete by remember { mutableStateOf<com.example.data.model.DiaryNote?>(null) }
    var showSettingsUpdatedSuccess by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Column {
                ItiTopAppBar(
                    title = "Admin Console",
                    subtitle = admin.email.ifBlank { if (admin.name.isNotBlank() && admin.name != "Institute Admin") admin.name else "admin@iti.ac.in" },
                    roleLabel = null,
                    onBroadcast = { showBroadcastDialog = true },
                    onNotificationClick = { selectedTab = AdminTab.NOTIFICATIONS },
                    notificationCount = uiState.notifications.size,
                    onRefresh = { viewModel.loadAllAdminData() },
                    onLogout = onLogout
                )
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp,
                    shadowElevation = 4.dp
                ) {
                    ScrollableTabRow(
                        selectedTabIndex = AdminTab.entries.indexOf(selectedTab).let { if (it >= 0) it else 0 },
                        edgePadding = 8.dp,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.primary,
                        divider = { HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)) }
                    ) {
                        AdminTab.entries.forEach { tab ->
                            val isSelected = selectedTab == tab
                            Tab(
                                selected = isSelected,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.title,
                                        modifier = Modifier.size(20.dp),
                                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                text = {
                                    Text(
                                        text = if (tab == AdminTab.NOTIFICATIONS && uiState.notifications.isNotEmpty()) "${tab.title} (${uiState.notifications.size})" else tab.title,
                                        maxLines = 1,
                                        softWrap = false,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                },
                                modifier = Modifier.testTag("nav_admin_${tab.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Message alerts
            if (uiState.message != null) {
                Surface(
                    color = StatusPresentGreen.copy(alpha = 0.15f),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(uiState.message ?: "", style = MaterialTheme.typography.bodySmall, color = StatusPresentGreen)
                        IconButton(onClick = { viewModel.clearMessages() }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = StatusPresentGreen)
                        }
                    }
                }
            }

            // Tab Content
            when (selectedTab) {
                AdminTab.DASHBOARD -> AdminDashboardTab(
                    uiState = uiState,
                    onNavigate = { selectedTab = it }
                )
                AdminTab.ATTENDANCE -> AdminAttendanceTab(
                    todayAttendance = uiState.todayAttendance,
                    trades = uiState.trades,
                    trainees = uiState.trainees,
                    selectedDate = uiState.selectedDate,
                    onDateChange = { viewModel.selectDate(it) },
                    admin = admin,
                    viewModel = viewModel
                )
                AdminTab.REPORTS -> AdminReportsTab(
                    trades = uiState.trades,
                    trainees = uiState.trainees.filter { it.status == "approved" },
                    todayAttendance = uiState.todayAttendance,
                    stats = uiState.stats,
                    workingDaysList = uiState.instituteSettings.workingDays,
                    holidays = uiState.instituteSettings.holidays,
                    onFetchDayAttendance = { date, tradeId, tradeName ->
                        viewModel.getAttendanceForDate(date, tradeId, tradeName)
                    },
                    onFetchMonthlyAttendance = { month, tradeId, tradeName ->
                        viewModel.getMonthlyAttendance(month, tradeId, tradeName)
                    }
                )
                AdminTab.DIARY -> AdminDiaryTab(
                    diaryNotes = uiState.diaryNotes,
                    trainees = uiState.trainees,
                    trades = uiState.trades,
                    onEditNote = { note -> diaryNoteToEdit = note },
                    onDeleteNote = { note -> diaryNoteToDelete = note }
                )
                AdminTab.TRADES -> AdminTradesTab(
                    trades = uiState.trades,
                    instructors = uiState.instructors,
                    trainees = uiState.trainees,
                    onAddTrade = { showAddTradeDialog = true },
                    onEditTrade = { tradeToEdit = it },
                    onToggleStatus = { tradeId, status ->
                        viewModel.toggleTradeStatus(tradeId, status, admin.uid, admin.name)
                    },
                    onDeleteTrade = { trade ->
                        tradeToDelete = trade
                    }
                )
                AdminTab.INSTRUCTORS -> AdminInstructorsTab(
                    instructors = uiState.instructors,
                    pending = uiState.pendingInstructors,
                    trades = uiState.trades,
                    trainees = uiState.trainees,
                    onApprove = { viewModel.approveInstructor(it, admin.uid, admin.name) },
                    onReject = {
                        rejectionTargetId = it
                        isRejectingInstructor = true
                    },
                    onToggleStatus = { instructorId, status ->
                        viewModel.toggleInstructorStatus(instructorId, status, admin.uid, admin.name)
                    },
                    onDeleteInstructor = { instructor ->
                        instructorToDelete = instructor
                    },
                    onModifyInstructor = { instructor ->
                        instructorToModify = instructor
                    }
                )
                AdminTab.TRAINEES -> AdminTraineesTab(
                    trainees = uiState.trainees,
                    pending = uiState.pendingTrainees,
                    trades = uiState.trades,
                    searchQuery = uiState.searchQuery,
                    selectedTradeFilter = uiState.selectedTradeFilter,
                    onSearchChange = { viewModel.updateSearchQuery(it) },
                    onFilterChange = { viewModel.filterByTrade(it) },
                    onApprove = { viewModel.approveTrainee(it, admin.uid, admin.name) },
                    onReject = {
                        rejectionTargetId = it
                        isRejectingInstructor = false
                    },
                    onToggleStatus = { traineeUid, status ->
                        viewModel.toggleTraineeStatus(traineeUid, status, admin.uid, admin.name)
                    },
                    onDeleteTrainee = { trainee ->
                        traineeToDelete = trainee
                    },
                    onAddDiaryNote = { trainee ->
                        traineeForDiaryNote = trainee
                    },
                    onModifyTrainee = { trainee ->
                        traineeToModify = trainee
                    }
                )
                AdminTab.NOTIFICATIONS -> AdminNotificationsTab(
                    notifications = uiState.notifications,
                    onDeleteNotification = { notifId ->
                        viewModel.deleteNotification(notifId)
                    },
                    onDeleteNotifications = { notifIds ->
                        viewModel.deleteNotifications(notifIds)
                    }
                )
                AdminTab.ADD_ADMIN -> AdminAddAdminTab(
                    admins = uiState.admins,
                    currentAdmin = admin,
                    viewModel = viewModel
                )
                AdminTab.SETTINGS -> AdminSettingsTab(
                    settings = uiState.instituteSettings,
                    onSave = { name, address, lat, lng, radius, repTime, lateTime, cutOffTime ->
                        viewModel.updateInstituteSettings(name, address, lat, lng, radius, repTime, lateTime, cutOffTime, admin.uid, admin.name)
                        showSettingsUpdatedSuccess = true
                    },
                    onAddHoliday = { date, name, desc ->
                        viewModel.addHoliday(date, name, desc, admin.uid, admin.name)
                    },
                    onDeleteHoliday = { holidayId ->
                        viewModel.deleteHoliday(holidayId, admin.uid, admin.name)
                    }
                )
                AdminTab.AUDIT -> AdminAuditTab(
                    auditLogs = uiState.auditLogs,
                    corrections = uiState.corrections,
                    onDeleteAllCorrections = { viewModel.clearAttendanceCorrections() },
                    onDeleteAllAuditLogs = { viewModel.clearAuditLogs() }
                )
            }
        }
    }

    // High-Priority Institute Pop-up Window Dialog on Login / New Announcement
    if (unacknowledgedNotifs.isNotEmpty()) {
        InstituteNotificationPopupDialog(
            notifications = unacknowledgedNotifs,
            onDismiss = { ids ->
                NotificationPreferenceManager.markNotificationsAcknowledged(context, ids, "admin")
                acknowledgedNotifIds = NotificationPreferenceManager.getAcknowledgedNotificationIds(context, "admin")
            }
        )
    }

    // Add Trade Dialog
    if (showAddTradeDialog) {
        var tName by remember { mutableStateOf("") }
        var tCode by remember { mutableStateOf("") }
        var tScheme by remember { mutableStateOf("CTS") }
        var tDuration by remember { mutableStateOf("1 Year") }
        var selectedInstructorId by remember { mutableStateOf("") }
        var selectedInstructorName by remember { mutableStateOf("") }
        var instructorDropdownExpanded by remember { mutableStateOf(false) }

        val approvedInstructors = remember(uiState.instructors) {
            uiState.instructors.filter { it.status.equals("approved", ignoreCase = true) }
        }

        AlertDialog(
            onDismissRequest = { showAddTradeDialog = false },
            title = { Text("Add New ITI Trade") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    OutlinedTextField(
                        value = tName,
                        onValueChange = { tName = it },
                        label = { Text("Trade Name (e.g. Electrician)") },
                        modifier = Modifier.fillMaxWidth().testTag("input_trade_name"),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = tCode,
                        onValueChange = { tCode = it.uppercase() },
                        label = { Text("Trade Code (e.g. ITI-ELC)") },
                        modifier = Modifier.fillMaxWidth().testTag("input_trade_code"),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = tScheme,
                        onValueChange = { tScheme = it },
                        label = { Text("Scheme (CTS / Self Finance / PMKVY)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = tDuration,
                        onValueChange = { tDuration = it },
                        label = { Text("Duration (e.g. 1 Year, 2 Years)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (tName.isNotBlank() && tCode.isNotBlank()) {
                            viewModel.addTrade(
                                name = tName,
                                code = tCode,
                                scheme = tScheme,
                                duration = tDuration,
                                adminId = admin.uid,
                                adminName = admin.name
                            )
                            tradeCreatedSuccessName = tName
                            showAddTradeDialog = false
                        }
                    },
                    modifier = Modifier.testTag("btn_confirm_add_trade")
                ) {
                    Text("Add Trade")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTradeDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Success Popup Window for Trade Creation
    if (tradeCreatedSuccessName != null) {
        AlertDialog(
            onDismissRequest = { tradeCreatedSuccessName = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(40.dp)
                )
            },
            title = {
                Text(
                    text = "Trade Created Successfully!",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "The trade '${tradeCreatedSuccessName}' has been successfully added to ITI Anantnag.",
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = { tradeCreatedSuccessName = null },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_close_trade_success_dialog")
                ) {
                    Text("OK")
                }
            }
        )
    }

    // Success Popup Window for Institute Settings Update
    if (showSettingsUpdatedSuccess) {
        AlertDialog(
            onDismissRequest = { showSettingsUpdatedSuccess = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(44.dp)
                )
            },
            title = {
                Text(
                    text = "Successfully Updated",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Institute settings and configurations have been successfully updated.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "GPS Geofence: ${String.format("%.4f", uiState.instituteSettings.latitude)}, ${String.format("%.4f", uiState.instituteSettings.longitude)} (${uiState.instituteSettings.radiusMeters.toInt()}m radius)\nReporting: ${uiState.instituteSettings.reportingTime} • Late Threshold: ${uiState.instituteSettings.lateTimeThreshold}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showSettingsUpdatedSuccess = false },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_close_settings_success_dialog")
                ) {
                    Text("OK", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Edit Trade Dialog
    if (tradeToEdit != null) {
        val targetTrade = tradeToEdit!!
        var tName by remember { mutableStateOf(targetTrade.tradeName) }
        var tCode by remember { mutableStateOf(targetTrade.tradeCode) }
        var tScheme by remember { mutableStateOf(targetTrade.scheme) }
        var tDuration by remember { mutableStateOf(targetTrade.duration) }

        AlertDialog(
            onDismissRequest = { tradeToEdit = null },
            title = { Text("Modify Trade: ${targetTrade.tradeName}") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    OutlinedTextField(
                        value = tName,
                        onValueChange = { tName = it },
                        label = { Text("Trade Name") },
                        modifier = Modifier.fillMaxWidth().testTag("input_edit_trade_name"),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = tCode,
                        onValueChange = { tCode = it.uppercase() },
                        label = { Text("Trade Code") },
                        modifier = Modifier.fillMaxWidth().testTag("input_edit_trade_code"),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = tScheme,
                        onValueChange = { tScheme = it },
                        label = { Text("Scheme") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = tDuration,
                        onValueChange = { tDuration = it },
                        label = { Text("Duration") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (tName.isNotBlank() && tCode.isNotBlank()) {
                            val updated = targetTrade.copy(
                                tradeName = tName.trim(),
                                tradeCode = tCode.trim().uppercase(),
                                scheme = tScheme,
                                duration = tDuration
                            )
                            viewModel.updateTrade(updated, admin.uid, admin.name)
                            tradeToEdit = null
                        }
                    },
                    modifier = Modifier.testTag("btn_confirm_update_trade")
                ) {
                    Text("Update Trade")
                }
            },
            dismissButton = {
                TextButton(onClick = { tradeToEdit = null }) { Text("Cancel") }
            }
        )
    }

    // Delete Trade Confirmation Dialog
    if (tradeToDelete != null) {
        val targetTrade = tradeToDelete!!
        AlertDialog(
            onDismissRequest = { tradeToDelete = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Delete Trade?") },
            text = {
                Text("Are you sure you want to permanently delete the trade '${targetTrade.tradeName}' (${targetTrade.tradeCode})? This action cannot be undone.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteTrade(targetTrade.tradeId, targetTrade.tradeName, admin.uid, admin.name)
                        tradeToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("btn_confirm_delete_trade")
                ) {
                    Text("Delete Trade")
                }
            },
            dismissButton = {
                TextButton(onClick = { tradeToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete Instructor Confirmation Dialog
    if (instructorToDelete != null) {
        val targetInstructor = instructorToDelete!!
        AlertDialog(
            onDismissRequest = { instructorToDelete = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Delete Instructor?") },
            text = {
                Text("Are you sure you want to permanently delete instructor '${targetInstructor.name}' (${targetInstructor.tradeName}) and remove their account? This action cannot be undone.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteInstructor(targetInstructor.uid, targetInstructor.name, admin.uid, admin.name)
                        instructorToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("btn_confirm_delete_instructor")
                ) {
                    Text("Delete Instructor")
                }
            },
            dismissButton = {
                TextButton(onClick = { instructorToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete Trainee Confirmation Dialog
    if (traineeToDelete != null) {
        val targetTrainee = traineeToDelete!!
        AlertDialog(
            onDismissRequest = { traineeToDelete = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Delete Trainee?") },
            text = {
                Text("Are you sure you want to permanently delete trainee '${targetTrainee.name}' (${targetTrainee.traineeId}) and all their records? This action cannot be undone.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteTrainee(targetTrainee.uid, targetTrainee.name, admin.uid, admin.name)
                        traineeToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("btn_confirm_delete_trainee")
                ) {
                    Text("Delete Trainee")
                }
            },
            dismissButton = {
                TextButton(onClick = { traineeToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Modify Instructor Dialog
    if (instructorToModify != null) {
        val targetInst = instructorToModify!!
        ModifyInstructorDialog(
            instructor = targetInst,
            onDismiss = { instructorToModify = null },
            onSave = { name, contact ->
                val targetName = name
                instructorToModify = null
                viewModel.updateInstructorDetails(
                    instructorId = targetInst.uid,
                    name = name,
                    contact = contact,
                    adminId = admin.uid,
                    adminName = admin.name
                ) {
                    instructorModifiedSuccessName = targetName
                }
            }
        )
    }

    // Modify Instructor Success Dialog Popup
    if (instructorModifiedSuccessName != null) {
        AlertDialog(
            onDismissRequest = {
                instructorModifiedSuccessName = null
                instructorToModify = null
            },
            icon = {
                Surface(
                    shape = CircleShape,
                    color = StatusPresentGreen.copy(alpha = 0.15f),
                    modifier = Modifier.size(56.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = StatusPresentGreen,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
            },
            title = {
                Text(
                    text = "Instructor Details Updated!",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Instructor profile for $instructorModifiedSuccessName has been modified successfully.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        instructorModifiedSuccessName = null
                        instructorToModify = null
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_close_modify_instructor_success_dialog")
                ) {
                    Text("OK", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Modify Trainee Dialog
    if (traineeToModify != null) {
        val targetTrainee = traineeToModify!!
        ModifyTraineeDialog(
            trainee = targetTrainee,
            onDismiss = { traineeToModify = null },
            onSave = { name, parentage, contact, guardianContact, address ->
                val targetName = name
                traineeToModify = null
                viewModel.updateTraineeDetails(
                    traineeUid = targetTrainee.uid,
                    name = name,
                    parentage = parentage,
                    contact = contact,
                    guardianContact = guardianContact,
                    address = address,
                    adminId = admin.uid,
                    adminName = admin.name
                ) {
                    traineeModifiedSuccessName = targetName
                }
            }
        )
    }

    // Modify Trainee Success Dialog Popup
    if (traineeModifiedSuccessName != null) {
        AlertDialog(
            onDismissRequest = {
                traineeModifiedSuccessName = null
                traineeToModify = null
            },
            icon = {
                Surface(
                    shape = CircleShape,
                    color = StatusPresentGreen.copy(alpha = 0.15f),
                    modifier = Modifier.size(56.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = StatusPresentGreen,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
            },
            title = {
                Text(
                    text = "Details Updated Successfully!",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Trainee profile for $traineeModifiedSuccessName has been modified successfully.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        traineeModifiedSuccessName = null
                        traineeToModify = null
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_close_modify_trainee_success_dialog")
                ) {
                    Text("OK", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Add Diary Note Dialog for Trainee (Admin)
    if (traineeForDiaryNote != null) {
        val targetTrainee = traineeForDiaryNote!!
        AdminAddDiaryNoteDialog(
            trainee = targetTrainee,
            onDismiss = { traineeForDiaryNote = null },
            onSave = { title, content ->
                viewModel.addDiaryNote(
                    traineeId = targetTrainee.uid,
                    traineeName = targetTrainee.name,
                    tradeId = targetTrainee.tradeId,
                    tradeName = targetTrainee.tradeName,
                    adminId = admin.uid,
                    adminName = admin.name,
                    title = title,
                    content = content
                )
                traineeForDiaryNote = null
            }
        )
    }

    // Rejection Reason Dialog
    if (rejectionTargetId != null) {
        AlertDialog(
            onDismissRequest = { rejectionTargetId = null },
            title = { Text(if (isRejectingInstructor) "Reject Instructor Registration" else "Reject Trainee Registration") },
            text = {
                Column {
                    Text("Please provide an official reason for rejection:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = rejectionReason,
                        onValueChange = { rejectionReason = it },
                        label = { Text("Rejection Reason") },
                        modifier = Modifier.fillMaxWidth().testTag("input_rejection_reason"),
                        minLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val target = rejectionTargetId ?: return@Button
                        if (isRejectingInstructor) {
                            viewModel.rejectInstructor(target, rejectionReason, admin.uid, admin.name)
                        } else {
                            viewModel.rejectTrainee(target, rejectionReason, admin.uid, admin.name)
                        }
                        rejectionTargetId = null
                        rejectionReason = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("btn_confirm_reject")
                ) {
                    Text("Confirm Rejection")
                }
            },
            dismissButton = {
                TextButton(onClick = { rejectionTargetId = null }) { Text("Cancel") }
            }
        )
    }

    // Edit Diary Note Dialog
    if (diaryNoteToEdit != null) {
        val targetNote = diaryNoteToEdit!!
        AdminEditDiaryNoteDialog(
            note = targetNote,
            onDismiss = { diaryNoteToEdit = null },
            onSave = { title, content ->
                viewModel.updateDiaryNote(targetNote.noteId, title, content)
                diaryNoteToEdit = null
            }
        )
    }

    // Delete Diary Note Dialog
    if (diaryNoteToDelete != null) {
        val targetNote = diaryNoteToDelete!!
        AlertDialog(
            onDismissRequest = { diaryNoteToDelete = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Delete Diary Note?", fontWeight = FontWeight.Bold) },
            text = {
                Text("Are you sure you want to permanently delete the diary note '${targetNote.title}' for trainee '${targetNote.traineeName}'? This action cannot be undone.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteDiaryNote(targetNote.noteId)
                        diaryNoteToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("btn_confirm_delete_admin_diary")
                ) {
                    Text("Delete Note")
                }
            },
            dismissButton = {
                TextButton(onClick = { diaryNoteToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Broadcast Notification Dialog
    if (showBroadcastDialog) {
        var notifTitle by remember { mutableStateOf("") }
        var notifMsg by remember { mutableStateOf("") }
        var targetRole by remember { mutableStateOf("all") }

        AlertDialog(
            onDismissRequest = { showBroadcastDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Campaign,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Broadcast Notification",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = notifTitle,
                        onValueChange = { notifTitle = it },
                        label = { Text("Notification Title *") },
                        placeholder = { Text("e.g. Urgent Holiday / Event Notice") },
                        modifier = Modifier.fillMaxWidth().testTag("input_broadcast_title"),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = notifMsg,
                        onValueChange = { notifMsg = it },
                        label = { Text("Message Body *") },
                        placeholder = { Text("Enter announcement details (will pop up on login)...") },
                        modifier = Modifier.fillMaxWidth().testTag("input_broadcast_message"),
                        shape = RoundedCornerShape(10.dp),
                        minLines = 3,
                        maxLines = 5
                    )

                    Column {
                        Text(
                            text = "Target Audience:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        // Clear, well-spaced, highly visible target selection chips in a flow layout
                        androidx.compose.foundation.layout.FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val targets = listOf(
                                "all" to "All Users",
                                "both" to "Both (Instr & Trainee)",
                                "instructor" to "Instructors",
                                "trainee" to "Trainees",
                                "parent" to "Parents"
                            )
                            targets.forEach { (role, label) ->
                                FilterChip(
                                    selected = targetRole == role,
                                    onClick = { targetRole = role },
                                    label = {
                                        Text(
                                            text = label,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = if (targetRole == role) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    leadingIcon = if (targetRole == role) {
                                        {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    } else null,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .height(36.dp)
                                        .testTag("chip_broadcast_target_$role")
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (notifTitle.isNotBlank() && notifMsg.isNotBlank()) {
                            viewModel.sendBroadcastNotification(notifTitle.trim(), notifMsg.trim(), targetRole, admin.name)
                            showBroadcastDialog = false
                        }
                    },
                    enabled = notifTitle.isNotBlank() && notifMsg.isNotBlank(),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_send_broadcast")
                ) {
                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Send Broadcast", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showBroadcastDialog = false },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

data class TradeAttendanceStat(
    val trade: Trade,
    val totalTrainees: Int,
    val presentTrainees: Int,
    val lateTrainees: Int,
    val absentTrainees: Int,
    val percentage: Double,
    val assignedInstructorName: String
)

@Composable
fun AdminDashboardTab(
    uiState: com.example.ui.viewmodels.AdminUiState,
    onNavigate: (AdminTab) -> Unit
) {
    val approvedTrainees = remember(uiState.trainees) {
        uiState.trainees.filter { it.status.equals("approved", ignoreCase = true) }
    }
    val todayAttendanceMap = remember(uiState.todayAttendance) {
        uiState.todayAttendance.associateBy { it.traineeId.ifBlank { it.traineeUniqueId } }
    }

    val isPastCutOff = remember(uiState.selectedDate, uiState.instituteSettings.cutOffTime) {
        DateUtils.isPastCutOff(uiState.selectedDate, uiState.instituteSettings.cutOffTime)
    }

    val tradeStatsList = remember(uiState.trades, approvedTrainees, todayAttendanceMap, uiState.instructors, isPastCutOff) {
        uiState.trades.map { trade ->
            val tradeTrainees = approvedTrainees.filter { tr ->
                tr.tradeId == trade.tradeId || (tr.tradeId.isBlank() && tr.tradeName.equals(trade.tradeName, ignoreCase = true))
            }
            var present = 0
            var late = 0
            var absent = 0
            tradeTrainees.forEach { tr ->
                val rec = todayAttendanceMap[tr.uid] ?: todayAttendanceMap[tr.traineeId]
                val st = rec?.attendanceStatus?.trim() ?: ""
                val effective = if (st.isNotBlank()) {
                    st.lowercase()
                } else if (isPastCutOff) {
                    "absent"
                } else {
                    "not_marked"
                }
                when (effective) {
                    "present" -> present++
                    "late" -> late++
                    "absent" -> absent++
                }
            }
            val total = tradeTrainees.size
            val pct = if (total > 0) ((present + late).toDouble() / total) * 100.0 else 0.0
            val instructor = uiState.instructors.firstOrNull { inst ->
                inst.tradeId == trade.tradeId || (inst.tradeId.isBlank() && inst.tradeName.equals(trade.tradeName, ignoreCase = true))
            }?.name ?: "Unassigned"

            TradeAttendanceStat(
                trade = trade,
                totalTrainees = total,
                presentTrainees = present,
                lateTrainees = late,
                absentTrainees = absent,
                percentage = pct,
                assignedInstructorName = instructor
            )
        }
    }

    val goodTrades = remember(tradeStatsList) { tradeStatsList.filter { it.percentage >= 75.0 } }
    val averageTrades = remember(tradeStatsList) { tradeStatsList.filter { it.percentage >= 50.0 && it.percentage < 75.0 } }
    val poorTrades = remember(tradeStatsList) { tradeStatsList.filter { it.percentage < 50.0 } }

    var selectedTradeCategoryDialogIndex by remember { mutableStateOf<Int?>(null) }
    var selectedStatusDetailType by remember { mutableStateOf<String?>(null) }

    val halfDayRecords = remember(uiState.todayAttendance) {
        uiState.todayAttendance.filter {
            it.attendanceStatus.equals("half_day", ignoreCase = true) ||
            it.attendanceStatus.equals("halfday", ignoreCase = true) ||
            it.attendanceStatus.equals("half day", ignoreCase = true)
        }
    }
    val leaveRecords = remember(uiState.todayAttendance) {
        uiState.todayAttendance.filter {
            it.attendanceStatus.equals("leave", ignoreCase = true)
        }
    }
    val halfDayCount = maxOf(halfDayRecords.size, uiState.stats.halfDayToday)
    val leaveCount = maxOf(leaveRecords.size, uiState.stats.leaveToday)

    val presentCount = remember(uiState.todayAttendance) {
        uiState.todayAttendance.count { it.attendanceStatus.equals("present", ignoreCase = true) || it.attendanceStatus.equals("late", ignoreCase = true) }
    }

    val explicitAbsentRecords = remember(uiState.todayAttendance) {
        uiState.todayAttendance.filter { it.attendanceStatus.equals("absent", ignoreCase = true) }
    }

    val unpunchedTrainees = remember(approvedTrainees, uiState.todayAttendance) {
        approvedTrainees.filter { tr ->
            uiState.todayAttendance.none { att ->
                (tr.uid.isNotBlank() && att.traineeId == tr.uid) ||
                (tr.traineeId.isNotBlank() && att.traineeUniqueId == tr.traineeId)
            }
        }
    }

    // Cutoff logic:
    // Before cutoff time: all not punched trainees are shown in 'not marked' card.
    // Absent card shows only explicitly marked absent trainees (or 0 if none).
    // Once cutoff is reached: all not punched trainees are shown in 'Absent' card.
    // 'Not marked' card becomes 0.
    // Mutually exclusive: never show in both cards at the same time.
    val notMarkedCount = if (isPastCutOff) 0 else unpunchedTrainees.size
    val absentCount = if (isPastCutOff) {
        if (approvedTrainees.isNotEmpty()) {
            (approvedTrainees.size - presentCount - halfDayCount - leaveCount).coerceAtLeast(0)
        } else {
            uiState.stats.absentToday
        }
    } else {
        explicitAbsentRecords.size
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                // Institute Summary Header Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = uiState.instituteSettings.instituteName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = uiState.instituteSettings.instituteAddress,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface
                            ) {
                                Text(
                                    text = "GPS Geofence: ${uiState.instituteSettings.radiusMeters.toInt()}m Radius",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface
                            ) {
                                Text(
                                    text = "Shift: ${uiState.instituteSettings.reportingTime} (Late > ${uiState.instituteSettings.lateTimeThreshold})",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Stats Grid
            item {
                Row(modifier = Modifier.fillMaxWidth()) {
                    StatCard(
                        title = "Total Trades",
                        value = uiState.stats.totalTrades.toString(),
                        icon = Icons.Default.Engineering,
                        accentColor = ItiNavyPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Instructors",
                        value = uiState.stats.totalInstructors.toString(),
                        icon = Icons.Default.Badge,
                        accentColor = ItiTertiary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(modifier = Modifier.fillMaxWidth()) {
                    StatCard(
                        title = "Trainees",
                        value = uiState.stats.totalTrainees.toString(),
                        icon = Icons.Default.School,
                        accentColor = ItiOrangeSecondary,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Attendance %",
                        value = "${String.format("%.1f", uiState.stats.attendancePercentage)}%",
                        icon = Icons.Default.CheckCircle,
                        accentColor = StatusPresentGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(modifier = Modifier.fillMaxWidth()) {
                    StatCard(
                        title = "Present Today",
                        value = uiState.stats.presentToday.toString(),
                        icon = Icons.Default.CheckCircle,
                        accentColor = StatusPresentGreen,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Absent Today",
                        value = absentCount.toString(),
                        icon = Icons.Default.PersonOff,
                        accentColor = StatusAbsentRed,
                        subtitle = if (isPastCutOff) "Cutoff Reached" else if (explicitAbsentRecords.isNotEmpty()) "Marked Absent" else "0 Absent",
                        onClick = { selectedStatusDetailType = "absent" },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(modifier = Modifier.fillMaxWidth()) {
                    StatCard(
                        title = "Late Today",
                        value = uiState.stats.lateToday.toString(),
                        icon = Icons.Default.Schedule,
                        accentColor = StatusLateOrange,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Not Marked Today",
                        value = notMarkedCount.toString(),
                        icon = Icons.Default.PendingActions,
                        accentColor = Color(0xFF757575),
                        subtitle = if (isPastCutOff) "Cutoff Passed (0)" else "Pending Punch-in",
                        onClick = { selectedStatusDetailType = "not_marked" },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(modifier = Modifier.fillMaxWidth()) {
                    StatCard(
                        title = "Half Day Today",
                        value = halfDayCount.toString(),
                        icon = Icons.Default.HourglassBottom,
                        accentColor = Color(0xFF00796B),
                        subtitle = "Instructor Marked",
                        onClick = { selectedStatusDetailType = "half_day" },
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Leave Today",
                        value = leaveCount.toString(),
                        icon = Icons.Default.EventBusy,
                        accentColor = StatusLeaveBlue,
                        subtitle = "Instructor Marked",
                        onClick = { selectedStatusDetailType = "leave" },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Trade Attendance Performance Section Header
            item {
                Column(modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)) {
                    Text(
                        text = "Trade Attendance Performance",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Attendance tiers based on today's present ratio",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Good & Average Trades Cards
            item {
                Row(modifier = Modifier.fillMaxWidth()) {
                    StatCard(
                        title = "Good\nAttendance",
                        value = "${goodTrades.size} ${if (goodTrades.size == 1) "Trade" else "Trades"}",
                        icon = Icons.Default.ThumbUp,
                        accentColor = StatusPresentGreen,
                        subtitle = ">= 75% Attendance",
                        onClick = { selectedTradeCategoryDialogIndex = 0 },
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Average\nAttendance",
                        value = "${averageTrades.size} ${if (averageTrades.size == 1) "Trade" else "Trades"}",
                        icon = Icons.Default.ThumbsUpDown,
                        accentColor = StatusLateOrange,
                        subtitle = "50% - 74% Attendance",
                        onClick = { selectedTradeCategoryDialogIndex = 1 },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Poor Trades Card
            item {
                Row(modifier = Modifier.fillMaxWidth()) {
                    StatCard(
                        title = "Poor\nAttendance",
                        value = "${poorTrades.size} ${if (poorTrades.size == 1) "Trade" else "Trades"}",
                        icon = Icons.Default.ThumbDown,
                        accentColor = StatusAbsentRed,
                        subtitle = "< 50% Attendance",
                        onClick = { selectedTradeCategoryDialogIndex = 2 },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Pending Approvals Banner
            if (uiState.stats.pendingTraineeApprovals > 0 || uiState.stats.pendingInstructorRegistrations > 0) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "Pending Action Items",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Text(
                                    text = "${uiState.stats.pendingInstructorRegistrations} Instructors • ${uiState.stats.pendingTraineeApprovals} Trainees awaiting review",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                                )
                            }
                            Button(onClick = { onNavigate(AdminTab.TRAINEES) }) {
                                Text("Review")
                            }
                        }
                    }
                }
            }

            // Developer Credit
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp, bottom = 8.dp, end = 4.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Developed By: V/I NAJEEB REHMAN :   Principal: Er. BILAL AHMAD WANI",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("developer_credit_admin")
                    )
                }
            }
        }

        if (selectedTradeCategoryDialogIndex != null) {
            TradeCategoryDetailDialog(
                initialCategoryIndex = selectedTradeCategoryDialogIndex!!,
                goodTrades = goodTrades,
                averageTrades = averageTrades,
                poorTrades = poorTrades,
                onDismiss = { selectedTradeCategoryDialogIndex = null },
                onSelectTrade = { stat ->
                    selectedTradeCategoryDialogIndex = null
                    onNavigate(AdminTab.ATTENDANCE)
                }
            )
        }

        if (selectedStatusDetailType != null) {
            val statusType = selectedStatusDetailType!!
            val (title, icon, accentColor) = when (statusType) {
                "half_day" -> Triple("Half Day Trainees Today", Icons.Default.HourglassBottom, Color(0xFF00796B))
                "leave" -> Triple("Leave Trainees Today", Icons.Default.EventBusy, StatusLeaveBlue)
                "absent" -> Triple("Absent Trainees Today", Icons.Default.PersonOff, StatusAbsentRed)
                else -> Triple("Not Marked Trainees Today", Icons.Default.PendingActions, Color(0xFF757575))
            }
            val subtitle = when (statusType) {
                "half_day" -> "${halfDayRecords.size} marked by instructors today"
                "leave" -> "${leaveRecords.size} marked by instructors today"
                "absent" -> if (isPastCutOff) {
                    "${absentCount} absent (cutoff passed at ${uiState.instituteSettings.cutOffTime})"
                } else {
                    "${explicitAbsentRecords.size} marked absent before cutoff (${uiState.instituteSettings.cutOffTime})"
                }
                else -> if (isPastCutOff) {
                    "0 unpunched (all marked Absent after cutoff ${uiState.instituteSettings.cutOffTime})"
                } else {
                    "${unpunchedTrainees.size} pending punch-in before cutoff (${uiState.instituteSettings.cutOffTime})"
                }
            }

            AlertDialog(
                onDismissRequest = { selectedStatusDetailType = null },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(32.dp)
                    )
                },
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                },
                text = {
                    when (statusType) {
                        "half_day" -> {
                            if (halfDayRecords.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "No trainees marked as Half Day today.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = 360.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(halfDayRecords, key = { it.attendanceId.ifBlank { "${it.traineeId}_${it.date}" } }) { record ->
                                        Card(
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.2f)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = record.traineeName.ifBlank { "Trainee" },
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Surface(
                                                        color = accentColor.copy(alpha = 0.15f),
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text(
                                                            text = "HALF DAY",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = accentColor,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                if (record.tradeName.isNotBlank()) {
                                                    Text(
                                                        text = "Trade: ${record.tradeName}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                if (record.traineeUniqueId.isNotBlank()) {
                                                    Text(
                                                        text = "Roll ID: ${record.traineeUniqueId}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                if (!record.remarks.isNullOrBlank()) {
                                                    Spacer(modifier = Modifier.height(2.dp))
                                                    Text(
                                                        text = record.remarks ?: "",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        "leave" -> {
                            if (leaveRecords.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "No trainees marked on Leave today.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = 360.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(leaveRecords, key = { it.attendanceId.ifBlank { "${it.traineeId}_${it.date}" } }) { record ->
                                        Card(
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.2f)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = record.traineeName.ifBlank { "Trainee" },
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Surface(
                                                        color = accentColor.copy(alpha = 0.15f),
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text(
                                                            text = "LEAVE",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = accentColor,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                if (record.tradeName.isNotBlank()) {
                                                    Text(
                                                        text = "Trade: ${record.tradeName}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                if (record.traineeUniqueId.isNotBlank()) {
                                                    Text(
                                                        text = "Roll ID: ${record.traineeUniqueId}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                if (!record.remarks.isNullOrBlank()) {
                                                    Spacer(modifier = Modifier.height(2.dp))
                                                    Text(
                                                        text = record.remarks ?: "",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        "absent" -> {
                            if (absentCount == 0) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "No trainees are marked absent today.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = 360.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(explicitAbsentRecords, key = { "absent_${it.attendanceId.ifBlank { it.traineeId }}" }) { record ->
                                        Card(
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.2f)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = record.traineeName.ifBlank { "Trainee" },
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Surface(
                                                        color = accentColor.copy(alpha = 0.15f),
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text(
                                                            text = "ABSENT",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = accentColor,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                if (record.tradeName.isNotBlank()) {
                                                    Text(
                                                        text = "Trade: ${record.tradeName}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                if (record.traineeUniqueId.isNotBlank()) {
                                                    Text(
                                                        text = "Roll ID: ${record.traineeUniqueId}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                if (!record.remarks.isNullOrBlank()) {
                                                    Spacer(modifier = Modifier.height(2.dp))
                                                    Text(
                                                        text = record.remarks ?: "",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    if (isPastCutOff) {
                                        items(unpunchedTrainees, key = { "unpunched_${it.uid.ifBlank { it.traineeId }}" }) { trainee ->
                                            Card(
                                                shape = RoundedCornerShape(12.dp),
                                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                                border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.2f)),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(modifier = Modifier.padding(12.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = trainee.name,
                                                            style = MaterialTheme.typography.titleSmall,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                        Surface(
                                                            color = accentColor.copy(alpha = 0.15f),
                                                            shape = RoundedCornerShape(6.dp)
                                                        ) {
                                                            Text(
                                                                text = "AUTO ABSENT",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                fontWeight = FontWeight.Bold,
                                                                color = accentColor,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                            )
                                                        }
                                                    }
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(
                                                        text = "Trade: ${trainee.tradeName}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                    Text(
                                                        text = "Roll ID: ${trainee.traineeId}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                    Spacer(modifier = Modifier.height(2.dp))
                                                    Text(
                                                        text = "Did not punch in before cutoff (${uiState.instituteSettings.cutOffTime})",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.error
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else -> { // "not_marked"
                            if (isPastCutOff) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "Cutoff Time Passed",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "The institute cutoff time (${uiState.instituteSettings.cutOffTime}) has passed.\nAll trainees who did not punch in have been marked as Absent and are now displayed under the Absent card.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else if (unpunchedTrainees.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "All approved trainees have punched in today.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(max = 360.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(unpunchedTrainees, key = { "unpunched_${it.uid.ifBlank { it.traineeId }}" }) { trainee ->
                                        Card(
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.2f)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = trainee.name,
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Surface(
                                                        color = accentColor.copy(alpha = 0.15f),
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text(
                                                            text = "PENDING PUNCH-IN",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = accentColor,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = "Trade: ${trainee.tradeName}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Text(
                                                    text = "Roll ID: ${trainee.traineeId}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = "Awaiting punch-in before cutoff (${uiState.instituteSettings.cutOffTime})",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.outline
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            selectedStatusDetailType = null
                            onNavigate(AdminTab.ATTENDANCE)
                        }
                    ) {
                        Text("View in Attendance")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedStatusDetailType = null }) {
                        Text("Close")
                    }
                }
            )
        }
    }
}

@Composable
fun TradeCategoryDetailDialog(
    initialCategoryIndex: Int,
    goodTrades: List<TradeAttendanceStat>,
    averageTrades: List<TradeAttendanceStat>,
    poorTrades: List<TradeAttendanceStat>,
    onDismiss: () -> Unit,
    onSelectTrade: (TradeAttendanceStat) -> Unit
) {
    var selectedTab by remember { mutableStateOf(initialCategoryIndex) }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        },
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Trade Attendance Breakdown",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Real-time attendance tier analysis",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    edgePadding = 0.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.ThumbUp, contentDescription = null, modifier = Modifier.size(16.dp), tint = StatusPresentGreen)
                                Text("Good (${goodTrades.size})", fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.ThumbsUpDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = StatusLateOrange)
                                Text("Average (${averageTrades.size})", fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.ThumbDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = StatusAbsentRed)
                                Text("Poor (${poorTrades.size})", fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                }

                val currentList = when (selectedTab) {
                    0 -> goodTrades
                    1 -> averageTrades
                    else -> poorTrades
                }

                val categoryBadgeColor = when (selectedTab) {
                    0 -> StatusPresentGreen
                    1 -> StatusLateOrange
                    else -> StatusAbsentRed
                }

                if (currentList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                modifier = Modifier.size(40.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No trades in this category today",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(currentList, key = { it.trade.tradeId }) { stat ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = stat.trade.tradeName,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "Code: ${stat.trade.tradeCode} • ${stat.trade.scheme} (${stat.trade.duration})",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Surface(
                                            color = categoryBadgeColor.copy(alpha = 0.15f),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(
                                                text = "${String.format("%.1f", stat.percentage)}%",
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.Bold,
                                                color = categoryBadgeColor,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = "Present: ${stat.presentTrainees} / ${stat.totalTrainees} Trainees",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "Instructor: ${stat.assignedInstructorName}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        OutlinedButton(
                                            onClick = { onSelectTrade(stat) },
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("View Roster", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun AdminTradesTab(
    trades: List<Trade>,
    instructors: List<InstructorProfile> = emptyList(),
    trainees: List<TraineeProfile> = emptyList(),
    onAddTrade: () -> Unit,
    onEditTrade: (Trade) -> Unit,
    onToggleStatus: (String, String) -> Unit,
    onDeleteTrade: (Trade) -> Unit
) {
    var subTab by remember { mutableStateOf(0) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        ScrollableTabRow(
            selectedTabIndex = subTab,
            edgePadding = 8.dp,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)),
            divider = {}
        ) {
            Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = { Text("All Trades (${trades.size})", maxLines = 1, softWrap = false) },
                modifier = Modifier.testTag("tab_all_trades")
            )
            Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("View & Print", maxLines = 1, softWrap = false)
                    }
                },
                modifier = Modifier.testTag("tab_view_print_trades")
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (subTab == 1) {
            TradeViewAndPrintSection(
                trades = trades,
                instructors = instructors,
                trainees = trainees
            )
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ITI Trades (${trades.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = onAddTrade,
                    modifier = Modifier.testTag("btn_add_trade")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Trade")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (trades.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Engineering,
                    title = "No Trades Configured",
                    subtitle = "Click 'Add Trade' to configure technical education trades."
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(trades) { trade ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth().testTag("trade_item_${trade.tradeId}")
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = trade.tradeName,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${trade.tradeCode} • ${trade.scheme} • ${trade.duration}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    StatusBadge(status = trade.status)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        TextButton(
                                            onClick = { onEditTrade(trade) },
                                            modifier = Modifier.testTag("btn_edit_trade_${trade.tradeId}")
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Modify")
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        TextButton(
                                            onClick = { onToggleStatus(trade.tradeId, trade.status) }
                                        ) {
                                            Text(if (trade.status == "active") "Deactivate" else "Activate")
                                        }
                                        IconButton(
                                            onClick = { onDeleteTrade(trade) },
                                            modifier = Modifier.size(36.dp).testTag("btn_delete_trade_${trade.tradeId}")
                                        ) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "Delete Trade",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminInstructorsTab(
    instructors: List<InstructorProfile>,
    pending: List<InstructorProfile>,
    trades: List<Trade> = emptyList(),
    trainees: List<TraineeProfile> = emptyList(),
    onApprove: (String) -> Unit,
    onReject: (String) -> Unit,
    onToggleStatus: (String, String) -> Unit,
    onDeleteInstructor: (InstructorProfile) -> Unit,
    onModifyInstructor: (InstructorProfile) -> Unit = {}
) {
    var subTab by remember { mutableStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        ScrollableTabRow(
            selectedTabIndex = subTab,
            edgePadding = 8.dp,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)),
            divider = {}
        ) {
            Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = { Text("Approved (${instructors.count { it.status == "approved" || it.status == "inactive" }})", maxLines = 1, softWrap = false) },
                modifier = Modifier.testTag("tab_approved_instructors")
            )
            Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = { Text("Pending (${pending.size})", maxLines = 1, softWrap = false) },
                modifier = Modifier.testTag("tab_pending_instructors")
            )
            Tab(
                selected = subTab == 2,
                onClick = { subTab = 2 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("View & Print", maxLines = 1, softWrap = false)
                    }
                },
                modifier = Modifier.testTag("tab_view_print_instructors")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (subTab == 2) {
            InstructorViewAndPrintSection(
                instructors = instructors.filter { it.status == "approved" || it.status == "inactive" },
                trades = trades,
                trainees = trainees
            )
        } else {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by Name, Trade, or Email...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth().testTag("input_search_instructors"),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

        val baseList = if (subTab == 0) {
            instructors.filter { it.status == "approved" || it.status == "inactive" }
        } else {
            pending
        }

        val filteredList = baseList.filter { inst ->
            searchQuery.isBlank() ||
                    inst.name.contains(searchQuery, ignoreCase = true) ||
                    inst.tradeName.contains(searchQuery, ignoreCase = true) ||
                    inst.email.contains(searchQuery, ignoreCase = true) ||
                    inst.contact.contains(searchQuery, ignoreCase = true)
        }

        if (filteredList.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.Badge,
                title = if (subTab == 0) "No Instructors Found" else "No Pending Registrations",
                subtitle = if (subTab == 0) "Try adjusting your search query." else "All instructor registrations are reviewed."
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filteredList, key = { it.uid }) { inst ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth().testTag("instructor_item_${inst.uid}")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(inst.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text(inst.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                StatusBadge(status = inst.status)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Trade: ${inst.tradeName}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Text("Contact: ${inst.contact}", style = MaterialTheme.typography.bodySmall)

                            if (subTab == 0) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    OutlinedButton(
                                        onClick = { onToggleStatus(inst.uid, inst.status) },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .height(34.dp)
                                            .testTag("btn_toggle_instructor_${inst.uid}")
                                    ) {
                                        Text(
                                            text = if (inst.status.equals("approved", ignoreCase = true)) "Deactivate" else "Activate",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }

                                    Row(
                                        verticalAlignment = Alignment.Top,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = { onModifyInstructor(inst) },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier
                                                .height(34.dp)
                                                .testTag("btn_modify_instructor_${inst.uid}")
                                        ) {
                                            Icon(
                                                Icons.Default.Edit,
                                                contentDescription = null,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "Modify",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1
                                            )
                                        }

                                        IconButton(
                                            onClick = { onDeleteInstructor(inst) },
                                            modifier = Modifier
                                                .size(34.dp)
                                                .testTag("btn_delete_instructor_${inst.uid}")
                                        ) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "Delete Instructor",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            } else if (subTab == 1) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    OutlinedButton(
                                        onClick = { onReject(inst.uid) },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                        modifier = Modifier.testTag("btn_reject_instructor_${inst.uid}")
                                    ) {
                                        Text("Reject")
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Button(
                                        onClick = { onApprove(inst.uid) },
                                        modifier = Modifier.testTag("btn_approve_instructor_${inst.uid}")
                                    ) {
                                        Text("Approve")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}

@Composable
fun AdminTraineesTab(
    trainees: List<TraineeProfile>,
    pending: List<TraineeProfile>,
    trades: List<Trade>,
    searchQuery: String,
    selectedTradeFilter: String?,
    onSearchChange: (String) -> Unit,
    onFilterChange: (String?) -> Unit,
    onApprove: (String) -> Unit,
    onReject: (String) -> Unit,
    onToggleStatus: (String, String) -> Unit,
    onDeleteTrainee: (TraineeProfile) -> Unit,
    onAddDiaryNote: (TraineeProfile) -> Unit,
    onModifyTrainee: (TraineeProfile) -> Unit = {}
) {
    var subTab by remember { mutableStateOf(0) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        ScrollableTabRow(
            selectedTabIndex = subTab,
            edgePadding = 8.dp,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)),
            divider = {}
        ) {
            Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = { Text("Approved (${trainees.count { it.status == "approved" }})", maxLines = 1, softWrap = false) },
                modifier = Modifier.testTag("tab_approved_trainees")
            )
            Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = { Text("Pending (${pending.size})", maxLines = 1, softWrap = false) },
                modifier = Modifier.testTag("tab_pending_trainees")
            )
            Tab(
                selected = subTab == 2,
                onClick = { subTab = 2 },
                text = { Text("Inactive (${trainees.count { it.status == "inactive" || it.status == "deactive" || it.status == "suspended" || it.status == "rejected" }})", maxLines = 1, softWrap = false) },
                modifier = Modifier.testTag("tab_inactive_trainees")
            )
            Tab(
                selected = subTab == 3,
                onClick = { subTab = 3 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("View & Print", maxLines = 1, softWrap = false)
                    }
                },
                modifier = Modifier.testTag("tab_view_print_trainees")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (subTab == 3) {
            // "View & Print" Table Tab
            TraineeViewAndPrintSection(
                trainees = trainees.filter { it.status == "approved" || it.status == "inactive" },
                trades = trades
            )
        } else {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("Search by Name or Trainee ID...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth().testTag("input_search_trainees"),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            val baseList = when (subTab) {
                0 -> trainees.filter { it.status == "approved" }
                1 -> pending
                else -> trainees.filter { it.status == "inactive" || it.status == "deactive" || it.status == "suspended" || it.status == "rejected" }
            }
            val filteredList = baseList.filter { t ->
                val matchQuery = searchQuery.isBlank() || t.name.contains(searchQuery, ignoreCase = true) || t.traineeId.contains(searchQuery, ignoreCase = true)
                val matchTrade = selectedTradeFilter == null || t.tradeId == selectedTradeFilter
                matchQuery && matchTrade
            }.sortedByTraineeIdAscending()

            if (filteredList.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.School,
                    title = when (subTab) {
                        0 -> "No Approved Trainees Found"
                        1 -> "No Pending Trainees"
                        else -> "No Inactive Trainees Found"
                    },
                    subtitle = when (subTab) {
                        0 -> "Try adjusting search query."
                        1 -> "All trainee applications are approved/reviewed."
                        else -> "No inactive or deactivated trainees."
                    }
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filteredList) { trainee ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth().testTag("trainee_item_${trainee.uid}")
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(trainee.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text("Father: ${trainee.parentage}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    StatusBadge(status = trainee.status)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("ID: ${trainee.traineeId}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = ItiNavyPrimary)
                                    Text("Trade: ${trainee.tradeName}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                                }
                                Text("Email: ${trainee.email} • Phone: ${trainee.contact}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                if (trainee.guardianContact.isNotBlank()) {
                                    Text("Father/Guardian No: ${trainee.guardianContact}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium, color = ItiNavyPrimary)
                                }
                                if (trainee.address.isNotBlank()) {
                                    Text("Address: ${trainee.address}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text("Parent Access PIN: ${trainee.parentAccessPin}", style = MaterialTheme.typography.bodySmall, color = ItiOrangeSecondary, fontWeight = FontWeight.SemiBold)

                                if (subTab == 0 || subTab == 2) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        OutlinedButton(
                                            onClick = { onToggleStatus(trainee.uid, trainee.status) },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier
                                                .height(34.dp)
                                                .testTag("btn_toggle_trainee_${trainee.uid}")
                                        ) {
                                            Text(
                                                text = if (trainee.status.equals("approved", ignoreCase = true)) "Deactivate" else "Activate",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                        Row(
                                            verticalAlignment = Alignment.Top,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            OutlinedButton(
                                                onClick = { onModifyTrainee(trainee) },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier
                                                    .height(34.dp)
                                                    .testTag("btn_modify_${trainee.uid}")
                                            ) {
                                                Icon(
                                                    Icons.Default.Edit,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = "Modify",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.SemiBold,
                                                    maxLines = 1
                                                )
                                            }
                                            FilledTonalButton(
                                                onClick = { onAddDiaryNote(trainee) },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier
                                                    .height(34.dp)
                                                    .testTag("btn_add_note_trainee_${trainee.uid}")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.NoteAdd,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = "Add Note",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.SemiBold,
                                                    maxLines = 1
                                                )
                                            }
                                            IconButton(
                                                onClick = { onDeleteTrainee(trainee) },
                                                modifier = Modifier
                                                    .size(34.dp)
                                                    .testTag("btn_delete_trainee_${trainee.uid}")
                                            ) {
                                                Icon(
                                                    Icons.Default.Delete,
                                                    contentDescription = "Delete Trainee",
                                                    tint = MaterialTheme.colorScheme.error,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                } else if (subTab == 1) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        OutlinedButton(
                                            onClick = { onReject(trainee.uid) },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                            modifier = Modifier.testTag("btn_reject_trainee_${trainee.uid}")
                                        ) {
                                            Text("Reject")
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Button(
                                            onClick = { onApprove(trainee.uid) },
                                            modifier = Modifier.testTag("btn_approve_trainee_${trainee.uid}")
                                        ) {
                                            Text("Approve & Assign ID")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ExportAttendanceDialog(
    initialDate: String,
    trades: List<Trade>,
    todayAttendance: List<AttendanceRecord>,
    onFetchMonthlyAttendance: suspend (String) -> List<AttendanceRecord>,
    onDismiss: () -> Unit
) {
    var exportTab by remember { mutableStateOf(0) } // 0: Day-Wise, 1: Monthly
    var selectedMonthIndex by remember { mutableStateOf(0) }
    var selectedTradeFilterId by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current
    val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current

    val availableMonths = remember {
        val list = mutableListOf<Pair<String, String>>()
        val cal = java.util.Calendar.getInstance()
        val sdfVal = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault())
        val sdfLbl = java.text.SimpleDateFormat("MMMM yyyy", java.util.Locale.getDefault())
        for (i in 0..11) {
            list.add(sdfVal.format(cal.time) to sdfLbl.format(cal.time))
            cal.add(java.util.Calendar.MONTH, -1)
        }
        list
    }

    var monthlyAttendanceRecords by remember { mutableStateOf<List<AttendanceRecord>>(emptyList()) }
    var isLoadingMonthly by remember { mutableStateOf(false) }

    val currentYearMonth = availableMonths.getOrNull(selectedMonthIndex)?.first ?: ""

    LaunchedEffect(exportTab, selectedMonthIndex) {
        if (exportTab == 1 && currentYearMonth.isNotBlank()) {
            isLoadingMonthly = true
            monthlyAttendanceRecords = onFetchMonthlyAttendance(currentYearMonth)
            isLoadingMonthly = false
        }
    }

    val activeRecords = remember(exportTab, todayAttendance, monthlyAttendanceRecords, selectedTradeFilterId) {
        val baseList = if (exportTab == 0) todayAttendance else monthlyAttendanceRecords
        if (selectedTradeFilterId == null) {
            baseList
        } else {
            baseList.filter { it.tradeId == selectedTradeFilterId }
        }
    }

    val csvText = remember(activeRecords) {
        buildString {
            append("Date,Trainee ID,Trainee Name,Trade,Punch In,Punch Out,Status,Punch In Distance(m),Remarks\n")
            activeRecords.sortedWith(compareBy({ it.date }, { it.traineeUniqueId })).forEach { a ->
                append("${a.date},${a.traineeUniqueId},${a.traineeName},${a.tradeName},${DateUtils.formatTime(a.punchInTime)},${DateUtils.formatTime(a.punchOutTime)},${a.attendanceStatus},${a.punchInDistance ?: ""},${a.remarks ?: ""}\n")
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = {
                    val sanitizedDate = initialDate.replace("/", "-").replace(" ", "_")
                    val fileName = if (exportTab == 0) {
                        "attendance_export_day_${sanitizedDate}.csv"
                    } else {
                        val sanitizedMonth = currentYearMonth.replace("/", "-").replace(" ", "_")
                        "attendance_export_month_${sanitizedMonth}.csv"
                    }
                    val downloaded = CsvExportUtils.downloadCsvFile(context, fileName, csvText)
                    if (downloaded) {
                        android.widget.Toast.makeText(context, "CSV downloaded: $fileName to Downloads folder", android.widget.Toast.LENGTH_LONG).show()
                    } else {
                        clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(csvText))
                        android.widget.Toast.makeText(context, "CSV copied to clipboard!", android.widget.Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.testTag("btn_download_csv")
            ) {
                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Download CSV")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        },
        title = {
            Column {
                Text("Export Attendance Data", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Day-Wise or Monthly CSV Export", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TabRow(selectedTabIndex = exportTab) {
                    Tab(
                        selected = exportTab == 0,
                        onClick = { exportTab = 0 },
                        text = { Text("Day-Wise", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = exportTab == 1,
                        onClick = { exportTab = 1 },
                        text = { Text("Monthly", fontWeight = FontWeight.Bold) }
                    )
                }

                if (exportTab == 0) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Target Date:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = "${DateUtils.formatDateForDisplay(initialDate)} ($initialDate)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Select Month:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            itemsIndexed(availableMonths) { index, pair ->
                                FilterChip(
                                    selected = selectedMonthIndex == index,
                                    onClick = { selectedMonthIndex = index },
                                    label = { Text(pair.second) }
                                )
                            }
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Filter Trade:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item {
                            FilterChip(
                                selected = selectedTradeFilterId == null,
                                onClick = { selectedTradeFilterId = null },
                                label = { Text("All Trades") }
                            )
                        }
                        items(trades, key = { it.tradeId }) { tr ->
                            FilterChip(
                                selected = selectedTradeFilterId == tr.tradeId,
                                onClick = { selectedTradeFilterId = if (selectedTradeFilterId == tr.tradeId) null else tr.tradeId },
                                label = { Text(tr.tradeName) }
                            )
                        }
                    }
                }

                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (exportTab == 0) "Day Records: ${activeRecords.size}" else "Monthly Records: ${activeRecords.size}",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Present: ${activeRecords.count { it.attendanceStatus == "present" || it.attendanceStatus == "late" }} | Absent: ${activeRecords.count { it.attendanceStatus == "absent" }}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (exportTab == 1 && isLoadingMonthly) {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(140.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Fetching monthly records...", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                } else {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(150.dp)
                    ) {
                        Text(
                            text = csvText,
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminSettingsTab(
    settings: com.example.data.model.InstituteSettings,
    onSave: (String, String, Double, Double, Double, String, String, String) -> Unit,
    onAddHoliday: ((String, String, String) -> Unit)? = null,
    onDeleteHoliday: ((String) -> Unit)? = null
) {
    var instName by remember(settings) { mutableStateOf(settings.instituteName) }
    var instAddr by remember(settings) { mutableStateOf(settings.instituteAddress) }
    var latStr by remember(settings) { mutableStateOf(settings.latitude.toString()) }
    var lngStr by remember(settings) { mutableStateOf(settings.longitude.toString()) }
    var radiusStr by remember(settings) { mutableStateOf(settings.radiusMeters.toString()) }
    var repTime by remember(settings) { mutableStateOf(settings.reportingTime) }
    var lateTime by remember(settings) { mutableStateOf(settings.lateTimeThreshold) }
    var cutOffTime by remember(settings) { mutableStateOf(settings.cutOffTime) }

    // Holiday Management State
    var showAddHolidayDialog by remember { mutableStateOf(false) }
    var holidayToDelete by remember { mutableStateOf<Holiday?>(null) }
    var newHolidayDate by remember { mutableStateOf(DateUtils.getTodayDateString()) }
    var newHolidayName by remember { mutableStateOf("") }
    var newHolidayDesc by remember { mutableStateOf("") }
    var showHolidayDatePickerDialog by remember { mutableStateOf(false) }

    // Holiday Date Picker Dialog
    if (showHolidayDatePickerDialog) {
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = try {
                val sdf = java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.getDefault())
                sdf.parse(newHolidayDate.replace("-", "/"))?.time
            } catch (_: Exception) { null }
        )
        DatePickerDialog(
            onDismissRequest = { showHolidayDatePickerDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val selectedMillis = datePickerState.selectedDateMillis
                        if (selectedMillis != null) {
                            newHolidayDate = DateUtils.formatUtcMillisToDate(selectedMillis)
                        }
                        showHolidayDatePickerDialog = false
                    }
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showHolidayDatePickerDialog = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    // Add Holiday Dialog
    if (showAddHolidayDialog) {
        AlertDialog(
            onDismissRequest = { showAddHolidayDialog = false },
            icon = {
                Icon(
                    Icons.Default.EventBusy,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text("Mark Institute Holiday", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "Marking a day as a holiday excludes it from the working days count in attendance reports. Trainees will not be counted as absent on this day.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedCard(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Selected Date", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = "${DateUtils.formatDateForDisplay(newHolidayDate)} ($newHolidayDate)",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Button(
                                onClick = { showHolidayDatePickerDialog = true },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("btn_select_holiday_date")
                            ) {
                                Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Change Date")
                            }
                        }
                    }

                    OutlinedTextField(
                        value = newHolidayName,
                        onValueChange = { newHolidayName = it },
                        label = { Text("Holiday Name / Reason *") },
                        placeholder = { Text("e.g. Republic Day, Eid-ul-Fitr, Diwali") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_holiday_name"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = newHolidayDesc,
                        onValueChange = { newHolidayDesc = it },
                        label = { Text("Additional Description / Notes (Optional)") },
                        placeholder = { Text("e.g. Official Government Holiday") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_holiday_desc"),
                        maxLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newHolidayName.isNotBlank() && onAddHoliday != null) {
                            onAddHoliday(newHolidayDate, newHolidayName.trim(), newHolidayDesc.trim())
                            showAddHolidayDialog = false
                            newHolidayName = ""
                            newHolidayDesc = ""
                        }
                    },
                    enabled = newHolidayName.isNotBlank(),
                    modifier = Modifier.testTag("btn_confirm_mark_holiday")
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Mark Holiday")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddHolidayDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete Holiday Confirmation Dialog
    if (holidayToDelete != null) {
        val targetHoliday = holidayToDelete!!
        AlertDialog(
            onDismissRequest = { holidayToDelete = null },
            icon = {
                Icon(
                    Icons.Default.DeleteForever,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text("Remove Holiday?", fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "Are you sure you want to remove the holiday '${targetHoliday.name}' on ${DateUtils.formatDateForDisplay(targetHoliday.date)}? This date will once again be counted as a regular working day in attendance reports."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (onDeleteHoliday != null) {
                            onDeleteHoliday(targetHoliday.holidayId)
                        }
                        holidayToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("btn_confirm_delete_holiday")
                ) {
                    Text("Remove Holiday")
                }
            },
            dismissButton = {
                TextButton(onClick = { holidayToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    val sortedHolidays = remember(settings.holidays) {
        settings.holidays.sortedBy { it.date }
    }
    val todayDateStr = remember { DateUtils.getTodayDateString().replace("/", "-") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Institute Profile & GPS Coordinates", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Configure the official ITI location and attendance geofence radius.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        item {
            OutlinedTextField(
                value = instName,
                onValueChange = { instName = it },
                label = { Text("Institute Name") },
                modifier = Modifier.fillMaxWidth().testTag("input_setting_name"),
                singleLine = true
            )
        }

        item {
            OutlinedTextField(
                value = instAddr,
                onValueChange = { instAddr = it },
                label = { Text("Campus Address") },
                modifier = Modifier.fillMaxWidth().testTag("input_setting_address"),
                singleLine = true
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = latStr,
                    onValueChange = { latStr = it },
                    label = { Text("Latitude") },
                    modifier = Modifier.weight(1f).testTag("input_setting_lat"),
                    singleLine = true
                )
                OutlinedTextField(
                    value = lngStr,
                    onValueChange = { lngStr = it },
                    label = { Text("Longitude") },
                    modifier = Modifier.weight(1f).testTag("input_setting_lng"),
                    singleLine = true
                )
            }
        }

        item {
            OutlinedTextField(
                value = radiusStr,
                onValueChange = { radiusStr = it },
                label = { Text("Attendance Radius (Meters) - Default 100m") },
                modifier = Modifier.fillMaxWidth().testTag("input_setting_radius"),
                singleLine = true
            )
        }

        item {
            Text("Shift & Timing Configuration", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = repTime,
                    onValueChange = { repTime = it },
                    label = { Text("Reporting Time (HH:mm)") },
                    modifier = Modifier.weight(1f).testTag("input_setting_reporting_time"),
                    singleLine = true
                )
                OutlinedTextField(
                    value = lateTime,
                    onValueChange = { lateTime = it },
                    label = { Text("Late Threshold (HH:mm)") },
                    modifier = Modifier.weight(1f).testTag("input_setting_late_time"),
                    singleLine = true
                )
            }
        }

        item {
            OutlinedTextField(
                value = cutOffTime,
                onValueChange = { cutOffTime = it },
                label = { Text("CutOff Time (HH:mm)") },
                placeholder = { Text("17:00") },
                supportingText = {
                    Text("All trainees remain in Unmarked status before CutOff Time. Once CutOff Time is reached, all unmarked trainees are automatically marked as Absent.")
                },
                modifier = Modifier.fillMaxWidth().testTag("input_setting_cutoff_time"),
                singleLine = true
            )
        }

        item {
            Button(
                onClick = {
                    val lat = latStr.toDoubleOrNull() ?: settings.latitude
                    val lng = lngStr.toDoubleOrNull() ?: settings.longitude
                    val rad = radiusStr.toDoubleOrNull() ?: settings.radiusMeters
                    onSave(instName, instAddr, lat, lng, rad, repTime, lateTime, cutOffTime)
                },
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("btn_save_settings"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Save Institute Configuration", fontWeight = FontWeight.Bold)
            }
        }

        // -------------------------------------------------------------
        // MARK HOLIDAYS SECTION
        // -------------------------------------------------------------
        item {
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(8.dp))
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Mark Holidays (Non-Working Days)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Designate official holidays. Days marked as holidays are excluded from attendance calculation working days.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                FilledTonalButton(
                    onClick = {
                        newHolidayDate = DateUtils.getTodayDateString()
                        newHolidayName = ""
                        newHolidayDesc = ""
                        showAddHolidayDialog = true
                    },
                    modifier = Modifier.testTag("btn_open_add_holiday_dialog"),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Mark Holiday")
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f),
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "When a date is marked as a holiday, it is not counted as a working day in attendance reports and percentage calculations for all trainees.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        if (sortedHolidays.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.EventAvailable,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.size(40.dp)
                        )
                        Text(
                            "No holidays marked yet",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            "Click 'Mark Holiday' to select a date and exclude it from attendance working days.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(sortedHolidays) { holiday ->
                val holDateNorm = holiday.date.replace("/", "-")
                val isToday = holDateNorm == todayDateStr
                val isUpcoming = holDateNorm > todayDateStr

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isToday) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                        else MaterialTheme.colorScheme.surface
                    ),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth().testTag("holiday_card_${holiday.holidayId}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                color = if (isToday) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer,
                                contentColor = if (isToday) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onPrimaryContainer,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Default.BeachAccess,
                                        contentDescription = null,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = holiday.name,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Surface(
                                        color = when {
                                            isToday -> StatusPresentGreen.copy(alpha = 0.15f)
                                            isUpcoming -> StatusLateOrange.copy(alpha = 0.15f)
                                            else -> MaterialTheme.colorScheme.surfaceVariant
                                        },
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = when {
                                                isToday -> "Today"
                                                isUpcoming -> "Upcoming"
                                                else -> "Past"
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = when {
                                                isToday -> StatusPresentGreen
                                                isUpcoming -> StatusLateOrange
                                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                                            },
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = "${DateUtils.formatDateForDisplay(holiday.date)} (${holiday.date})",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                if (holiday.description.isNotBlank()) {
                                    Text(
                                        text = holiday.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Text(
                                    text = "Non-working day • Excluded from attendance denominator",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }

                        IconButton(
                            onClick = { holidayToDelete = holiday },
                            modifier = Modifier.testTag("btn_delete_holiday_${holiday.holidayId}")
                        ) {
                            Icon(
                                Icons.Default.DeleteOutline,
                                contentDescription = "Remove Holiday",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun AdminAuditTab(
    auditLogs: List<com.example.data.model.AuditLogEntry>,
    corrections: List<com.example.data.model.AttendanceCorrection>,
    onDeleteAllCorrections: () -> Unit = {},
    onDeleteAllAuditLogs: () -> Unit = {}
) {
    var subTab by remember { mutableStateOf(0) }
    var showDeleteCorrectionsConfirmDialog by remember { mutableStateOf(false) }
    var showDeleteAuditLogsConfirmDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            ScrollableTabRow(
                selectedTabIndex = subTab,
                edgePadding = 8.dp,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp)),
                divider = {}
            ) {
                Tab(
                    selected = subTab == 0,
                    onClick = { subTab = 0 },
                    text = { Text("Attendance Corrections (${corrections.size})", maxLines = 1, softWrap = false) },
                    modifier = Modifier.testTag("tab_attendance_corrections")
                )
                Tab(
                    selected = subTab == 1,
                    onClick = { subTab = 1 },
                    text = { Text("System Log (${auditLogs.size})", maxLines = 1, softWrap = false) },
                    modifier = Modifier.testTag("tab_system_logs")
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Delete Icon button for current tab
            IconButton(
                onClick = {
                    if (subTab == 0) {
                        showDeleteCorrectionsConfirmDialog = true
                    } else {
                        showDeleteAuditLogsConfirmDialog = true
                    }
                },
                enabled = if (subTab == 0) corrections.isNotEmpty() else auditLogs.isNotEmpty(),
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .border(
                        1.dp,
                        if ((if (subTab == 0) corrections.isNotEmpty() else auditLogs.isNotEmpty()))
                            MaterialTheme.colorScheme.error.copy(alpha = 0.5f)
                        else
                            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                        RoundedCornerShape(10.dp)
                    )
                    .testTag(if (subTab == 0) "btn_delete_all_corrections" else "btn_delete_all_system_logs")
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = if (subTab == 0) "Delete All Attendance Corrections" else "Delete All System Logs",
                    tint = if ((if (subTab == 0) corrections.isNotEmpty() else auditLogs.isNotEmpty()))
                        MaterialTheme.colorScheme.error
                    else
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (subTab == 0) {
            if (corrections.isEmpty()) {
                EmptyStateView(icon = Icons.Default.EditNote, title = "No Manual Corrections", subtitle = "Manual instructor attendance adjustments will appear here.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(corrections) { corr ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth().testTag("card_correction_${corr.correctionId}")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${corr.traineeName} (${corr.traineeUniqueId})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    Text(DateUtils.formatDateForDisplay(corr.date), style = MaterialTheme.typography.labelSmall)
                                 }
                                Text("Corrected: ${corr.oldValue} ➔ ${corr.newValue}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = StatusLateOrange)
                                Text("By: ${corr.correctedByName} (${corr.correctedByRole})", style = MaterialTheme.typography.bodySmall)
                                Text("Reason: ${corr.reason}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        } else {
            if (auditLogs.isEmpty()) {
                EmptyStateView(icon = Icons.Default.History, title = "No System Logs", subtitle = "Administrative and system actions will be recorded here.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(auditLogs) { log ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth().testTag("card_audit_log_${log.logId}")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(log.action, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = ItiNavyPrimary)
                                    Text(DateUtils.formatDateTime(log.timestamp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text("Performed by: ${log.performedByName} (${log.performedByRole})", style = MaterialTheme.typography.bodySmall)
                                if (log.reason != null) {
                                    Text("Reason: ${log.reason}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Confirmation Dialog for Deleting All Attendance Corrections
    if (showDeleteCorrectionsConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteCorrectionsConfirmDialog = false },
            icon = {
                Icon(
                    Icons.Default.DeleteForever,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = { Text("Delete All Corrections?") },
            text = {
                Text("Are you sure you want to delete all ${corrections.size} attendance correction records? This action cannot be undone.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteCorrectionsConfirmDialog = false
                        onDeleteAllCorrections()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("btn_confirm_delete_all_corrections")
                ) {
                    Text("Delete All")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDeleteCorrectionsConfirmDialog = false },
                    modifier = Modifier.testTag("btn_cancel_delete_all_corrections")
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // Confirmation Dialog for Deleting All System Logs
    if (showDeleteAuditLogsConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAuditLogsConfirmDialog = false },
            icon = {
                Icon(
                    Icons.Default.DeleteForever,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = { Text("Delete All System Logs?") },
            text = {
                Text("Are you sure you want to delete all ${auditLogs.size} system log entries? This action cannot be undone.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteAuditLogsConfirmDialog = false
                        onDeleteAllAuditLogs()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("btn_confirm_delete_all_system_logs")
                ) {
                    Text("Delete All")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDeleteAuditLogsConfirmDialog = false },
                    modifier = Modifier.testTag("btn_cancel_delete_all_system_logs")
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDiaryTab(
    diaryNotes: List<com.example.data.model.DiaryNote>,
    trainees: List<TraineeProfile>,
    trades: List<Trade>,
    onEditNote: (com.example.data.model.DiaryNote) -> Unit = {},
    onDeleteNote: (com.example.data.model.DiaryNote) -> Unit = {}
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedTradeId by remember { mutableStateOf<String?>(null) }
    var selectedTraineeUid by remember { mutableStateOf<String?>(null) }

    val filteredTrainees = remember(trainees, selectedTradeId, searchQuery) {
        val targetTrade = trades.find { it.tradeId == selectedTradeId }
        trainees.filter { t ->
            val matchesTrade = selectedTradeId == null ||
                    t.tradeId == selectedTradeId ||
                    (targetTrade != null && t.tradeName.equals(targetTrade.tradeName, ignoreCase = true))

            val matchesSearch = searchQuery.isBlank() ||
                    t.name.contains(searchQuery, ignoreCase = true) ||
                    t.traineeId.contains(searchQuery, ignoreCase = true)
            matchesTrade && matchesSearch
        }.sortedByTraineeIdAscending()
    }

    val filteredNotes = remember(diaryNotes, selectedTraineeUid, selectedTradeId, searchQuery) {
        val targetTrade = trades.find { it.tradeId == selectedTradeId }
        diaryNotes.filter { note ->
            val matchesTrainee = selectedTraineeUid == null || note.traineeId == selectedTraineeUid
            val matchesTrade = selectedTradeId == null ||
                    note.tradeId == selectedTradeId ||
                    (targetTrade != null && note.tradeName.equals(targetTrade.tradeName, ignoreCase = true))

            val matchesSearch = searchQuery.isBlank() ||
                    note.traineeName.contains(searchQuery, ignoreCase = true) ||
                    note.title.contains(searchQuery, ignoreCase = true) ||
                    note.content.contains(searchQuery, ignoreCase = true) ||
                    note.instructorName.contains(searchQuery, ignoreCase = true)
            matchesTrainee && matchesTrade && matchesSearch
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Diary Notes",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "${filteredNotes.size} note${if (filteredNotes.size != 1) "s" else ""}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }

        // Compact Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search trainee, title or remark...", style = MaterialTheme.typography.bodySmall) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                    }
                }
            },
            singleLine = true,
            textStyle = MaterialTheme.typography.bodySmall,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_admin_diary_search")
        )

        // Compact Trade Filter Row
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "Trade:",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Bold
            )
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.weight(1f)
            ) {
                item {
                    FilterChip(
                        selected = selectedTradeId == null,
                        onClick = { selectedTradeId = null; selectedTraineeUid = null },
                        label = { Text("All (${diaryNotes.size})", style = MaterialTheme.typography.labelSmall) },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(30.dp)
                    )
                }
                items(trades, key = { it.tradeId }) { trade ->
                    FilterChip(
                        selected = selectedTradeId == trade.tradeId,
                        onClick = {
                            selectedTradeId = if (selectedTradeId == trade.tradeId) null else trade.tradeId
                            selectedTraineeUid = null
                        },
                        label = { Text(trade.tradeName, style = MaterialTheme.typography.labelSmall) },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(30.dp)
                    )
                }
            }
        }

        // Compact Trainee Filter Row
        if (filteredTrainees.isNotEmpty()) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Trainee:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    item {
                        FilterChip(
                            selected = selectedTraineeUid == null,
                            onClick = { selectedTraineeUid = null },
                            label = { Text("All (${filteredNotes.size})", style = MaterialTheme.typography.labelSmall) },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(30.dp)
                        )
                    }
                    items(filteredTrainees, key = { it.uid }) { t ->
                        FilterChip(
                            selected = selectedTraineeUid == t.uid,
                            onClick = {
                                selectedTraineeUid = if (selectedTraineeUid == t.uid) null else t.uid
                            },
                            label = { Text("${t.name} (${t.traineeId})", style = MaterialTheme.typography.labelSmall) },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(30.dp)
                        )
                    }
                }
            }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

        // Notes List
        if (filteredNotes.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.MenuBook,
                title = "No Diary Notes Found",
                subtitle = "No remarks match the selected trainee, trade, or search filter."
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredNotes, key = { it.noteId }) { note ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth().testTag("admin_diary_card_${note.noteId}")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Header: Trainee Info & Actions
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f, fill = false)
                                ) {
                                    Surface(
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = note.traineeName,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                    Text(
                                        text = note.tradeName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = DateUtils.formatDateForDisplay(note.dateString.ifBlank { DateUtils.getTodayDateString() }),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(note.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = note.content,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(8.dp))

                            // Bottom Bar: Instructor Name + Clear, High-Contrast Action Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "By: ${note.instructorName}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.weight(1f, fill = false)
                                )

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    FilledTonalButton(
                                        onClick = { onEditNote(note) },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("btn_action_edit_diary_${note.noteId}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = "Modify Note",
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Modify",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    Button(
                                        onClick = { onDeleteNote(note) },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.error,
                                            contentColor = MaterialTheme.colorScheme.onError
                                        ),
                                        modifier = Modifier.testTag("btn_action_delete_diary_${note.noteId}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete Note",
                                            tint = MaterialTheme.colorScheme.onError,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Delete",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onError
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAttendanceTab(
    todayAttendance: List<com.example.data.model.AttendanceRecord>,
    trades: List<Trade>,
    trainees: List<TraineeProfile>,
    selectedDate: String,
    onDateChange: (String) -> Unit,
    admin: AdminProfile,
    viewModel: AdminViewModel
) {
    var selectedTradeId by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf<String?>(null) }
    var showDatePickerDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }

    if (showDatePickerDialog) {
        val initialMillis = remember(selectedDate) {
            DateUtils.parseDateToUtcMillis(selectedDate)
        }
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = initialMillis
        )
        DatePickerDialog(
            onDismissRequest = { showDatePickerDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        val selectedMillis = datePickerState.selectedDateMillis
                        if (selectedMillis != null) {
                            val formatted = DateUtils.formatUtcMillisToDate(selectedMillis)
                            onDateChange(formatted)
                        }
                        showDatePickerDialog = false
                    },
                    modifier = Modifier.testTag("btn_apply_date_picker")
                ) {
                    Text("Apply Date")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePickerDialog = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(
                state = datePickerState,
                title = {
                    Text(
                        "Select Trainee Attendance Date",
                        modifier = Modifier.padding(start = 24.dp, end = 12.dp, top = 16.dp),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            )
        }
    }

    val approvedTrainees = remember(trainees) {
        trainees.filter { it.status.equals("approved", ignoreCase = true) }
    }

    val uiState by viewModel.uiState.collectAsState()
    val isPastCutOff = remember(selectedDate, uiState.instituteSettings.cutOffTime) {
        DateUtils.isPastCutOff(selectedDate, uiState.instituteSettings.cutOffTime)
    }

    val tradeTrainees = remember(approvedTrainees, selectedTradeId) {
        if (selectedTradeId == null) approvedTrainees
        else approvedTrainees.filter { it.tradeId == selectedTradeId }
    }

    val attendanceMap = remember(todayAttendance) {
        todayAttendance.associateBy { it.traineeId.ifBlank { it.traineeUniqueId } }
    }

    val totalTraineesCount = tradeTrainees.size
    var presentCount = 0
    var lateCount = 0
    var absentCount = 0
    var halfDayCount = 0
    var leaveCount = 0
    var notMarkedCount = 0

    tradeTrainees.forEach { t ->
        val record = attendanceMap[t.uid] ?: attendanceMap[t.traineeId]
        val status = record?.attendanceStatus?.trim() ?: ""
        val effectiveStatus = if (status.isNotBlank()) {
            status.lowercase()
        } else if (isPastCutOff) {
            "absent"
        } else {
            "not_marked"
        }
        when (effectiveStatus) {
            "present" -> presentCount++
            "late" -> lateCount++
            "absent" -> absentCount++
            "half_day", "halfday", "half day" -> halfDayCount++
            "leave" -> leaveCount++
            else -> notMarkedCount++
        }
    }

    val presentOrLateCount = presentCount + lateCount
    val attendancePercentage = if (totalTraineesCount > 0) {
        ((presentOrLateCount.toDouble() / totalTraineesCount) * 100).toInt()
    } else 0

    val filteredRoster = remember(tradeTrainees, attendanceMap, searchQuery, statusFilter, isPastCutOff) {
        tradeTrainees.filter { t ->
            val record = attendanceMap[t.uid] ?: attendanceMap[t.traineeId]
            val status = record?.attendanceStatus?.trim() ?: ""
            val effectiveStatus = if (status.isNotBlank()) {
                status.lowercase()
            } else if (isPastCutOff) {
                "absent"
            } else {
                "not_marked"
            }

            val matchesSearch = searchQuery.isBlank() ||
                    t.name.contains(searchQuery, ignoreCase = true) ||
                    t.traineeId.contains(searchQuery, ignoreCase = true) ||
                    t.tradeName.contains(searchQuery, ignoreCase = true)

            val matchesStatus = when (statusFilter) {
                null -> true
                "half_day" -> effectiveStatus in listOf("half_day", "halfday", "half day")
                "leave" -> effectiveStatus == "leave"
                else -> effectiveStatus.equals(statusFilter, ignoreCase = true)
            }

            matchesSearch && matchesStatus
        }.sortedByTraineeIdAscending()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header & Date Controls
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Trade Attendance",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Real-time attendance stats & trade-wise breakdown",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        FilledTonalButton(
                            onClick = { showExportDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("btn_export_attendance_reports")
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export CSV")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier.clickable { showDatePickerDialog = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = "Select Date", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                Column {
                                    Text(
                                        text = DateUtils.formatDateForDisplay(selectedDate),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = selectedDate,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (selectedDate == DateUtils.getTodayDateString()) {
                                    Surface(
                                        color = StatusPresentGreen.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            "TODAY",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = StatusPresentGreen,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                } else if (selectedDate == DateUtils.getYesterdayDateString()) {
                                    Surface(
                                        color = ItiOrangeSecondary.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            "YESTERDAY",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = ItiOrangeSecondary,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { onDateChange(DateUtils.getPreviousDate(selectedDate)) },
                                modifier = Modifier.size(34.dp).testTag("btn_prev_date")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.NavigateBefore, contentDescription = "Previous Day")
                            }
                            Surface(
                                onClick = { showDatePickerDialog = true },
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("btn_pick_date")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(22.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.EditCalendar,
                                                contentDescription = "Pick Date",
                                                tint = MaterialTheme.colorScheme.onPrimary,
                                                modifier = Modifier.size(13.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "Pick Date",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                            IconButton(
                                onClick = { onDateChange(DateUtils.getNextDate(selectedDate)) },
                                modifier = Modifier.size(34.dp).testTag("btn_next_date")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.NavigateNext, contentDescription = "Next Day")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Date quick shortcut chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = selectedDate == DateUtils.getTodayDateString(),
                            onClick = { onDateChange(DateUtils.getTodayDateString()) },
                            label = { Text("Today") },
                            leadingIcon = { Icon(Icons.Default.Today, contentDescription = null, modifier = Modifier.size(14.dp)) },
                            modifier = Modifier.testTag("chip_date_today")
                        )
                        FilterChip(
                            selected = selectedDate == DateUtils.getYesterdayDateString(),
                            onClick = { onDateChange(DateUtils.getYesterdayDateString()) },
                            label = { Text("Yesterday") },
                            modifier = Modifier.testTag("chip_date_yesterday")
                        )
                        FilterChip(
                            selected = selectedDate != DateUtils.getTodayDateString() && selectedDate != DateUtils.getYesterdayDateString(),
                            onClick = { showDatePickerDialog = true },
                            label = { Text("Specific Date...") },
                            leadingIcon = { Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(14.dp)) },
                            modifier = Modifier.testTag("chip_date_specific")
                        )
                    }
                }
            }
        }

        // Trade Filter Chips
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Select Trade:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = selectedTradeId == null,
                            onClick = { selectedTradeId = null },
                            label = { Text("All Trades (${approvedTrainees.size})") },
                            leadingIcon = { Icon(Icons.Default.Engineering, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            modifier = Modifier.testTag("chip_trade_all")
                        )
                    }
                    items(trades, key = { it.tradeId }) { trade ->
                        val count = approvedTrainees.count { it.tradeId == trade.tradeId }
                        FilterChip(
                            selected = selectedTradeId == trade.tradeId,
                            onClick = { selectedTradeId = if (selectedTradeId == trade.tradeId) null else trade.tradeId },
                            label = { Text("${trade.tradeName} ($count)") },
                            modifier = Modifier.testTag("chip_trade_${trade.tradeCode.lowercase()}")
                        )
                    }
                }
            }
        }

        // Attendance Overview Stat Cards
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (selectedTradeId == null) "Overall Attendance Overview" else "Trade Attendance Stats",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            color = if (attendancePercentage >= 75) StatusPresentGreen.copy(alpha = 0.15f) else StatusLateOrange.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "$attendancePercentage% Present",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (attendancePercentage >= 75) StatusPresentGreen else StatusLateOrange,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { attendancePercentage / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp)),
                        color = StatusPresentGreen,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatCardMini(
                            label = "Enrolled",
                            value = "$totalTraineesCount",
                            color = MaterialTheme.colorScheme.primary,
                            isSelected = statusFilter == null,
                            onClick = { statusFilter = null },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_overview_enrolled")
                        )
                        StatCardMini(
                            label = "Present",
                            value = "$presentCount",
                            color = StatusPresentGreen,
                            isSelected = statusFilter == "present",
                            onClick = { statusFilter = if (statusFilter == "present") null else "present" },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_overview_present")
                        )
                        StatCardMini(
                            label = "Late",
                            value = "$lateCount",
                            color = StatusLateOrange,
                            isSelected = statusFilter == "late",
                            onClick = { statusFilter = if (statusFilter == "late") null else "late" },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_overview_late")
                        )
                        StatCardMini(
                            label = "Absent",
                            value = "$absentCount",
                            color = StatusAbsentRed,
                            isSelected = statusFilter == "absent",
                            onClick = { statusFilter = if (statusFilter == "absent") null else "absent" },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_overview_absent")
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatCardMini(
                            label = "Half Day",
                            value = "$halfDayCount",
                            color = Color(0xFF00796B),
                            isSelected = statusFilter == "half_day",
                            onClick = { statusFilter = if (statusFilter == "half_day") null else "half_day" },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_overview_half_day")
                        )
                        StatCardMini(
                            label = "Leave",
                            value = "$leaveCount",
                            color = StatusLeaveBlue,
                            isSelected = statusFilter == "leave",
                            onClick = { statusFilter = if (statusFilter == "leave") null else "leave" },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_overview_leave")
                        )
                        StatCardMini(
                            label = "Not Marked",
                            value = "$notMarkedCount",
                            color = Color(0xFF757575),
                            isSelected = statusFilter == "not_marked",
                            onClick = { statusFilter = if (statusFilter == "not_marked") null else "not_marked" },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_overview_not_marked")
                        )
                    }
                }
            }
        }

        // Trade-by-Trade Breakdown Cards (if "All Trades" selected)
        if (selectedTradeId == null && trades.isNotEmpty()) {
            item {
                Text(
                    text = "Trade-wise Summary",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            items(trades, key = { "breakdown_${it.tradeId}" }) { trade ->
                val tradeTraineesList = approvedTrainees.filter { it.tradeId == trade.tradeId }
                var tPresent = 0
                var tLate = 0
                var tAbsent = 0
                var tNotMarked = 0

                tradeTraineesList.forEach { tr ->
                    val rec = attendanceMap[tr.uid] ?: attendanceMap[tr.traineeId]
                    val st = rec?.attendanceStatus?.trim() ?: ""
                    val effective = if (st.isNotBlank()) {
                        st.lowercase()
                    } else if (isPastCutOff) {
                        "absent"
                    } else {
                        "not_marked"
                    }
                    when (effective) {
                        "present" -> tPresent++
                        "late" -> tLate++
                        "absent" -> tAbsent++
                        "half_day", "halfday", "half day", "leave" -> {}
                        else -> tNotMarked++
                    }
                }

                val total = tradeTraineesList.size
                val pct = if (total > 0) (((tPresent + tLate).toDouble() / total) * 100).toInt() else 0

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    onClick = { selectedTradeId = trade.tradeId },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("card_trade_summary_${trade.tradeCode.lowercase()}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(trade.tradeName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("${trade.tradeCode} • ${trade.scheme} • Total Trainees: $total", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            Surface(
                                color = if (pct >= 75) StatusPresentGreen.copy(alpha = 0.15f) else StatusLateOrange.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "$pct%",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (pct >= 75) StatusPresentGreen else StatusLateOrange,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Present: $tPresent", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = StatusPresentGreen)
                                Text("Late: $tLate", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = StatusLateOrange)
                                Text("Absent: $tAbsent", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = StatusAbsentRed)
                                if (tNotMarked > 0) {
                                    Text("Unmarked: $tNotMarked", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Text("View Roster ➔", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Detailed Roster Title & Filters
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 8.dp)) {
                Text("Trainee Attendance Roster", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search trainee name, ID, or trade...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_admin_attendance_search")
                )

                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    item {
                        FilterChip(
                            selected = statusFilter == null,
                            onClick = { statusFilter = null },
                            label = { Text("All (${tradeTrainees.size})", fontWeight = if (statusFilter == null) FontWeight.Bold else FontWeight.Normal) },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .height(38.dp)
                                .testTag("chip_status_all")
                        )
                    }
                    item {
                        FilterChip(
                            selected = statusFilter == "present",
                            onClick = { statusFilter = if (statusFilter == "present") null else "present" },
                            label = { Text("Present ($presentCount)", fontWeight = if (statusFilter == "present") FontWeight.Bold else FontWeight.Normal) },
                            leadingIcon = {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(StatusPresentGreen)
                                )
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .height(38.dp)
                                .testTag("chip_status_present")
                        )
                    }
                    item {
                        FilterChip(
                            selected = statusFilter == "late",
                            onClick = { statusFilter = if (statusFilter == "late") null else "late" },
                            label = { Text("Late ($lateCount)", fontWeight = if (statusFilter == "late") FontWeight.Bold else FontWeight.Normal) },
                            leadingIcon = {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(StatusLateOrange)
                                )
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .height(38.dp)
                                .testTag("chip_status_late")
                        )
                    }
                    item {
                        FilterChip(
                            selected = statusFilter == "absent",
                            onClick = { statusFilter = if (statusFilter == "absent") null else "absent" },
                            label = { Text("Absent ($absentCount)", fontWeight = if (statusFilter == "absent") FontWeight.Bold else FontWeight.Normal) },
                            leadingIcon = {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(StatusAbsentRed)
                                )
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .height(38.dp)
                                .testTag("chip_status_absent")
                        )
                    }
                    item {
                        FilterChip(
                            selected = statusFilter == "not_marked",
                            onClick = { statusFilter = if (statusFilter == "not_marked") null else "not_marked" },
                            label = { Text("Not Marked ($notMarkedCount)", fontWeight = if (statusFilter == "not_marked") FontWeight.Bold else FontWeight.Normal) },
                            leadingIcon = {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(Color.Gray)
                                )
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .height(38.dp)
                                .testTag("chip_status_not_marked")
                        )
                    }
                }
            }
        }

        // Detailed Trainees Roster List
        if (filteredRoster.isEmpty()) {
            item {
                EmptyStateView(
                    icon = Icons.Default.EventAvailable,
                    title = "No Trainees Found",
                    subtitle = "No attendance records match the selected filters."
                )
            }
        } else {
            items(filteredRoster, key = { it.uid }) { trainee ->
                val record = attendanceMap[trainee.uid] ?: attendanceMap[trainee.traineeId]
                val statusStr = record?.attendanceStatus ?: "not_marked"

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_attendance_card_${trainee.traineeId}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(42.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.School,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }

                            Column {
                                Text(trainee.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Text("${trainee.traineeId} • ${trainee.tradeName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(3.dp))
                                if (record != null) {
                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Text(
                                                text = "Punch In:",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Icon(
                                                imageVector = Icons.Default.Login,
                                                contentDescription = "Punch In",
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Text(
                                                text = DateUtils.formatTime(record.punchInTime) +
                                                        if (record.punchInDistance != null) " (${record.punchInDistance.toInt()}m)" else "",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Text(
                                                text = "Punch Out:",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (record.punchOutTime != null) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline
                                            )
                                            Icon(
                                                imageVector = Icons.Default.Logout,
                                                contentDescription = "Punch Out",
                                                tint = if (record.punchOutTime != null) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline,
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Text(
                                                text = DateUtils.formatTime(record.punchOutTime) +
                                                        if (record.punchOutDistance != null) " (${record.punchOutDistance.toInt()}m)" else "",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (record.punchOutTime != null) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline
                                            )
                                        }
                                    }
                                } else {
                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(2.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Text(
                                                text = "Punch In:",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.outline
                                            )
                                            Icon(
                                                imageVector = Icons.Default.Login,
                                                contentDescription = "Punch In",
                                                tint = MaterialTheme.colorScheme.outline,
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Text(
                                                text = "--:--",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.outline
                                            )
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Text(
                                                text = "Punch Out:",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.outline
                                            )
                                            Icon(
                                                imageVector = Icons.Default.Logout,
                                                contentDescription = "Punch Out",
                                                tint = MaterialTheme.colorScheme.outline,
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Text(
                                                text = "--:--",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.outline
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        val effectiveStatus = if (statusStr.isNotBlank() && !statusStr.equals("not_marked", ignoreCase = true)) {
                            statusStr.lowercase()
                        } else if (isPastCutOff) {
                            "absent"
                        } else {
                            "not_marked"
                        }

                        val (statusText, statusBg, statusFg) = when (effectiveStatus) {
                            "present" -> Triple("PRESENT", StatusPresentGreen.copy(alpha = 0.15f), StatusPresentGreen)
                            "late" -> Triple("LATE", StatusLateOrange.copy(alpha = 0.15f), StatusLateOrange)
                            "absent" -> Triple(if (isPastCutOff && record == null) "ABSENT (CUTOFF)" else "ABSENT", StatusAbsentRed.copy(alpha = 0.15f), StatusAbsentRed)
                            "half_day", "halfday", "half day" -> Triple("HALF DAY", Color(0xFF00796B).copy(alpha = 0.15f), Color(0xFF00796B))
                            "leave" -> Triple("LEAVE", StatusLeaveBlue.copy(alpha = 0.15f), StatusLeaveBlue)
                            else -> Triple("NOT MARKED", MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        Surface(
                            color = statusBg,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = statusFg,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showExportDialog) {
        ExportAttendanceDialog(
            initialDate = selectedDate,
            trades = trades,
            todayAttendance = todayAttendance,
            onFetchMonthlyAttendance = { ym -> viewModel.fetchMonthlyAttendance(ym) },
            onDismiss = { showExportDialog = false }
        )
    }
}

@Composable
fun StatCardMini(
    label: String,
    value: String,
    color: androidx.compose.ui.graphics.Color,
    isSelected: Boolean = false,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick ?: {},
        enabled = onClick != null,
        color = if (isSelected) color.copy(alpha = 0.22f) else color.copy(alpha = 0.10f),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) color else color.copy(alpha = 0.25f)
        ),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontSize = androidx.compose.ui.unit.TextUnit(10.5f, androidx.compose.ui.unit.TextUnitType.Sp),
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = color,
                maxLines = 1,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAddAdminTab(
    admins: List<AdminProfile>,
    currentAdmin: AdminProfile,
    viewModel: AdminViewModel
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var formError by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }
    var adminToDelete by remember { mutableStateOf<AdminProfile?>(null) }
    var newlyCreatedAdminName by remember { mutableStateOf<String?>(null) }
    var newlyCreatedAdminEmail by remember { mutableStateOf<String?>(null) }
    var showSuccessDialog by remember { mutableStateOf(false) }

    if (showSuccessDialog && newlyCreatedAdminName != null) {
        AlertDialog(
            onDismissRequest = {
                showSuccessDialog = false
                newlyCreatedAdminName = null
                newlyCreatedAdminEmail = null
            },
            icon = {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(52.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Success",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            },
            title = {
                Text(
                    text = "Admin Created Successfully!",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "New Administrator account has been registered and activated successfully.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center
                    )
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Name: ",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = newlyCreatedAdminName.orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Email: ",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = newlyCreatedAdminEmail.orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Role: ",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "ADMIN (Full System Access)",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessDialog = false
                        newlyCreatedAdminName = null
                        newlyCreatedAdminEmail = null
                    },
                    modifier = Modifier.testTag("btn_dismiss_admin_created_dialog")
                ) {
                    Text("OK")
                }
            }
        )
    }

    if (adminToDelete != null) {
        AlertDialog(
            onDismissRequest = { adminToDelete = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Delete Admin Account") },
            text = {
                Text("Are you sure you want to delete administrator '${adminToDelete?.name?.ifEmpty { adminToDelete?.email }}'? This will permanently revoke their access.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val target = adminToDelete
                        if (target != null) {
                            viewModel.deleteAdmin(
                                adminUid = target.uid,
                                adminName = target.name.ifEmpty { target.email },
                                currentAdminUid = currentAdmin.uid,
                                currentAdminName = currentAdmin.name
                            )
                        }
                        adminToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("btn_confirm_delete_admin")
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { adminToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Header card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primary,
                        shape = CircleShape,
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.PersonAdd,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Add New Administrator",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Create administrative account with full system access. Role will automatically be assigned as 'admin'.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }
                }
            }
        }

        item {
            // Add Admin Form Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Admin Profile Information",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    if (formError != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = formError!!,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    // Admin Name
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it; formError = null },
                        label = { Text("Admin Full Name") },
                        placeholder = { Text("e.g. Rahul Sharma") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("input_new_admin_name")
                    )

                    // Admin Email
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it; formError = null },
                        label = { Text("Admin Email Address") },
                        placeholder = { Text("e.g. rahul.admin@iti.edu") },
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Email
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("input_new_admin_email")
                    )

                    // Admin Password
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; formError = null },
                        label = { Text("Account Password") },
                        placeholder = { Text("Minimum 6 characters") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle Password Visibility"
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Password
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("input_new_admin_password")
                    )

                    // Confirm Password
                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it; formError = null },
                        label = { Text("Confirm Password") },
                        leadingIcon = { Icon(Icons.Default.LockReset, contentDescription = null) },
                        visualTransformation = if (passwordVisible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                            keyboardType = androidx.compose.ui.text.input.KeyboardType.Password
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("input_new_admin_confirm_password")
                    )

                    // Fixed Role Display (Role is admin)
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Role: ADMIN",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Text(
                                    text = "This user will have full administrative permissions across all trades & settings.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }

                    // Submit Button
                    Button(
                        onClick = {
                            if (name.isBlank()) {
                                formError = "Please enter Admin Full Name."
                                return@Button
                            }
                            if (email.isBlank() || !email.contains("@")) {
                                formError = "Please enter a valid email address."
                                return@Button
                            }
                            if (password.length < 6) {
                                formError = "Password must be at least 6 characters."
                                return@Button
                            }
                            if (password != confirmPassword) {
                                formError = "Passwords do not match."
                                return@Button
                            }

                            formError = null
                            isSubmitting = true
                            val submittedName = name.trim()
                            val submittedEmail = email.trim()
                            viewModel.addNewAdmin(
                                context = context,
                                name = submittedName,
                                email = submittedEmail,
                                password = password.trim(),
                                creatorAdminName = currentAdmin.name,
                                onSuccess = {
                                    isSubmitting = false
                                    name = ""
                                    email = ""
                                    password = ""
                                    confirmPassword = ""
                                    newlyCreatedAdminName = submittedName
                                    newlyCreatedAdminEmail = submittedEmail
                                    showSuccessDialog = true
                                }
                            )
                        },
                        enabled = !isSubmitting,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("btn_submit_new_admin")
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Creating Admin...")
                        } else {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Create Admin Account", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // List of Registered Admins Section
        item {
            Column {
                Text(
                    text = "Registered Institute Admins (${admins.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Current administrators with management access",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (admins.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Active Admin: ${currentAdmin.name} (${currentAdmin.email})", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        } else {
            items(admins, key = { it.uid }) { adminItem ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth().testTag("admin_card_${adminItem.uid}")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = CircleShape,
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = adminItem.name.ifBlank { "A" }.take(1).uppercase(),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = adminItem.name.ifBlank { adminItem.email.substringBefore("@") },
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                if (adminItem.uid == currentAdmin.uid) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Surface(
                                        color = MaterialTheme.colorScheme.tertiaryContainer,
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = "YOU",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = adminItem.email,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text(
                                text = "ADMIN",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        if (adminItem.uid != currentAdmin.uid) {
                            Spacer(modifier = Modifier.width(4.dp))
                            IconButton(
                                onClick = { adminToDelete = adminItem },
                                modifier = Modifier.size(36.dp).testTag("btn_delete_admin_${adminItem.uid}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete Admin",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminNotificationsTab(
    notifications: List<InstituteNotification>,
    onDeleteNotification: (String) -> Unit,
    onDeleteNotifications: ((List<String>) -> Unit)? = null
) {
    var historyFilterRole by remember { mutableStateOf("all") }
    var notifToDelete by remember { mutableStateOf<InstituteNotification?>(null) }
    var showDeleteAllDialog by remember { mutableStateOf(false) }

    val isInstituteNotif: (InstituteNotification) -> Boolean = { notif ->
        val isSenderAdmin = notif.senderRole.equals("admin", ignoreCase = true) ||
                notif.senderName.contains("Admin", ignoreCase = true) ||
                notif.senderName.contains("Administration", ignoreCase = true)
        val isNotSystem = notif.senderName != "Attendance Engine" &&
                !notif.senderName.contains("Engine", ignoreCase = true) &&
                !notif.senderName.contains("System", ignoreCase = true)
        val isNotAutomated = !notif.title.contains("Late Punch", ignoreCase = true) &&
                !notif.title.contains("Punch", ignoreCase = true) &&
                !notif.title.contains("Account Approved", ignoreCase = true) &&
                !notif.title.contains("Registration Approved", ignoreCase = true) &&
                !notif.title.contains("Approved", ignoreCase = true) &&
                !notif.title.contains("Rejected", ignoreCase = true) &&
                !notif.title.contains("Diary Note", ignoreCase = true) &&
                !notif.title.contains("Attendance", ignoreCase = true)

        isSenderAdmin && isNotSystem && isNotAutomated
    }

    val isTraineesNotif: (InstituteNotification) -> Boolean = { notif ->
        notif.targetRole.equals("trainee", ignoreCase = true) ||
        notif.targetRole.equals("trainees", ignoreCase = true) ||
        !notif.targetUserId.isNullOrBlank()
    }

    val isSystemNotif: (InstituteNotification) -> Boolean = { notif ->
        val isSystem = notif.senderName == "Attendance Engine" ||
                notif.senderName.contains("Engine", ignoreCase = true) ||
                notif.senderName.contains("System", ignoreCase = true) ||
                notif.senderRole.equals("system", ignoreCase = true)
        val isAutomated = notif.title.contains("Late Punch", ignoreCase = true) ||
                notif.title.contains("Punch", ignoreCase = true) ||
                notif.title.contains("Account Approved", ignoreCase = true) ||
                notif.title.contains("Registration Approved", ignoreCase = true) ||
                notif.title.contains("Approved", ignoreCase = true) ||
                notif.title.contains("Rejected", ignoreCase = true) ||
                notif.title.contains("Diary Note", ignoreCase = true) ||
                notif.title.contains("Attendance", ignoreCase = true)

        isSystem || isAutomated
    }

    val filteredNotifications = remember(notifications, historyFilterRole) {
        when (historyFilterRole) {
            "institute" -> notifications.filter(isInstituteNotif)
            "trainee" -> notifications.filter(isTraineesNotif)
            "system" -> notifications.filter(isSystemNotif)
            else -> notifications
        }
    }

    val allCount = notifications.size
    val instituteCount = remember(notifications) { notifications.count(isInstituteNotif) }
    val traineesCount = remember(notifications) { notifications.count(isTraineesNotif) }
    val systemCount = remember(notifications) { notifications.count(isSystemNotif) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section Title: Notification History
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Icon(
                                imageVector = Icons.Default.Campaign,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Sent Announcements (${filteredNotifications.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Broadcast history & pop-up announcements sent to users",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (filteredNotifications.isNotEmpty() && onDeleteNotifications != null) {
                    IconButton(
                        onClick = { showDeleteAllDialog = true },
                        modifier = Modifier.testTag("btn_delete_all_notifications")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Delete Displayed Announcements",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }

        // Filter chips for notification history
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf(
                    "all" to "All ($allCount)",
                    "institute" to "Institute ($instituteCount)",
                    "trainee" to "Trainees ($traineesCount)",
                    "system" to "System Triggers & Log ($systemCount)"
                ).forEach { (filterKey, filterLabel) ->
                    item {
                        FilterChip(
                            selected = (filterKey == "all" && historyFilterRole == "all") || (filterKey == historyFilterRole),
                            onClick = {
                                historyFilterRole = filterKey
                            },
                            label = { Text(filterLabel) },
                            leadingIcon = if ((filterKey == "all" && historyFilterRole == "all") || (filterKey == historyFilterRole)) {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                            } else null,
                            modifier = Modifier.testTag("chip_admin_filter_$filterKey")
                        )
                    }
                }
            }
        }

        // List of past notifications
        if (filteredNotifications.isEmpty()) {
            item {
                EmptyStateView(
                    icon = when (historyFilterRole) {
                        "institute" -> Icons.Default.Campaign
                        "trainee" -> Icons.Default.Person
                        "system" -> Icons.Default.Sensors
                        else -> Icons.Default.Campaign
                    },
                    title = when (historyFilterRole) {
                        "institute" -> "No Institute Broadcasts"
                        "trainee" -> "No Trainee Notifications"
                        "system" -> "No System Triggers or Logs"
                        else -> "No Notifications Sent"
                    },
                    subtitle = when (historyFilterRole) {
                        "institute" -> "Announcements created by administrators will appear here."
                        "trainee" -> "Announcements and alerts targeted to trainees will appear here."
                        "system" -> "Automated attendance triggers, approvals, and system logs will appear here."
                        else -> "Sent announcements and broadcasts will appear here."
                    }
                )
            }
        } else {
            items(filteredNotifications, key = { it.notificationId }) { notif ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth().testTag("card_notification_item_${notif.notificationId}")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = notif.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "By ${notif.senderName} • ${DateUtils.formatDateTime(notif.timestamp)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val (badgeBg, badgeFg, badgeText) = when (notif.targetRole.lowercase()) {
                                    "both", "instructor_trainee" -> Triple(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), MaterialTheme.colorScheme.primary, "BOTH (INSTR & TRAINEE)")
                                    "all" -> Triple(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer, "ALL USERS")
                                    "instructor" -> Triple(StatusLeaveBlue.copy(alpha = 0.15f), StatusLeaveBlue, "INSTRUCTORS")
                                    "trainee" -> Triple(StatusPresentGreen.copy(alpha = 0.15f), StatusPresentGreen, "TRAINEES")
                                    "parent" -> Triple(StatusLateOrange.copy(alpha = 0.15f), StatusLateOrange, "PARENTS")
                                    else -> Triple(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant, notif.targetRole.uppercase())
                                }
                                Surface(
                                    color = badgeBg,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = badgeText,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = badgeFg,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { notifToDelete = notif },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .testTag("btn_delete_notif_${notif.notificationId}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete Announcement",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = notif.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // Delete confirmation dialog
    if (notifToDelete != null) {
        AlertDialog(
            onDismissRequest = { notifToDelete = null },
            icon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Delete Notification") },
            text = { Text("Are you sure you want to delete '${notifToDelete?.title}'? It will no longer pop up for users.") },
            confirmButton = {
                Button(
                    onClick = {
                        notifToDelete?.let { onDeleteNotification(it.notificationId) }
                        notifToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { notifToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete Filtered confirmation dialog
    if (showDeleteAllDialog) {
        val deleteDialogTitle = when (historyFilterRole) {
            "institute" -> "Delete Institute Announcements?"
            "trainee" -> "Delete Trainee Notifications?"
            "system" -> "Delete System Triggers & Logs?"
            else -> "Delete All Sent Announcements?"
        }
        val deleteDialogDescription = when (historyFilterRole) {
            "institute" -> "Are you sure you want to delete all ${filteredNotifications.size} displayed Institute announcements? This action cannot be undone."
            "trainee" -> "Are you sure you want to delete all ${filteredNotifications.size} displayed Trainee notifications? This action cannot be undone."
            "system" -> "Are you sure you want to delete all ${filteredNotifications.size} displayed System triggers & logs? This action cannot be undone."
            else -> "Are you sure you want to delete all ${filteredNotifications.size} sent announcements? This action cannot be undone."
        }

        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            icon = { Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text(deleteDialogTitle) },
            text = { Text(deleteDialogDescription) },
            confirmButton = {
                Button(
                    onClick = {
                        val idsToDelete = filteredNotifications.map { it.notificationId }
                        onDeleteNotifications?.invoke(idsToDelete)
                        showDeleteAllDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete (${filteredNotifications.size})")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAddDiaryNoteDialog(
    trainee: TraineeProfile,
    onDismiss: () -> Unit,
    onSave: (title: String, content: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }

    val quickCategories = listOf(
        "Practical Conduct",
        "Theory Progress",
        "Discipline & Behavior",
        "Attendance Concern",
        "Academic Achievement",
        "General Remark"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.NoteAdd,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Add Diary Note for Trainee",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "${trainee.name} (${trainee.traineeId})",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Trade: ${trainee.tradeName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }

                // Quick Category Selectors
                Column {
                    Text(
                        "Quick Categories / Suggestions:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(quickCategories) { category ->
                            FilterChip(
                                selected = title.equals(category, ignoreCase = true),
                                onClick = { title = category },
                                label = { Text(category, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Note Title / Category *") },
                    placeholder = { Text("e.g. Practical Conduct, Warning, Commendation") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_admin_diary_title")
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Note Content / Remark *") },
                    placeholder = { Text("Enter detailed assessment, observation or instruction for the trainee...") },
                    minLines = 4,
                    maxLines = 8,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_admin_diary_content")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && content.isNotBlank()) {
                        onSave(title.trim(), content.trim())
                    }
                },
                enabled = title.isNotBlank() && content.isNotBlank(),
                modifier = Modifier.testTag("btn_save_admin_diary_note")
            ) {
                Text("Save to Diary")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("btn_cancel_admin_diary_note")
            ) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminEditDiaryNoteDialog(
    note: com.example.data.model.DiaryNote,
    onDismiss: () -> Unit,
    onSave: (title: String, content: String) -> Unit
) {
    var title by remember { mutableStateOf(note.title) }
    var content by remember { mutableStateOf(note.content) }

    val quickCategories = listOf(
        "Practical Conduct",
        "Theory Progress",
        "Discipline & Behavior",
        "Attendance Concern",
        "Academic Achievement",
        "General Remark"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Modify Diary Note",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Trainee: ${note.traineeName}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Trade: ${note.tradeName} • By: ${note.instructorName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }

                // Quick Category Selectors
                Column {
                    Text(
                        "Quick Categories / Suggestions:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(quickCategories) { category ->
                            FilterChip(
                                selected = title.equals(category, ignoreCase = true),
                                onClick = { title = category },
                                label = { Text(category, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Note Title / Category *") },
                    placeholder = { Text("e.g. Practical Conduct, Warning, Commendation") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_edit_admin_diary_title")
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Note Content / Remark *") },
                    placeholder = { Text("Enter detailed assessment, observation or instruction for the trainee...") },
                    minLines = 4,
                    maxLines = 8,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_edit_admin_diary_content")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && content.isNotBlank()) {
                        onSave(title.trim(), content.trim())
                    }
                },
                enabled = title.isNotBlank() && content.isNotBlank(),
                modifier = Modifier.testTag("btn_save_edit_admin_diary_note")
            ) {
                Text("Update Note")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("btn_cancel_edit_admin_diary_note")
            ) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun ModifyInstructorDialog(
    instructor: InstructorProfile,
    onDismiss: () -> Unit,
    onSave: (name: String, contact: String) -> Unit
) {
    var name by remember { mutableStateOf(instructor.name) }
    var contact by remember { mutableStateOf(instructor.contact) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Modify Instructor Details",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Trade: ${instructor.tradeName.ifBlank { "Unassigned" }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "Email: ${instructor.email}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Status: ${instructor.status.replaceFirstChar { it.uppercase() }}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Instructor Full Name *") },
                    placeholder = { Text("e.g. Rajesh Kumar") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_edit_instructor_name")
                )

                OutlinedTextField(
                    value = contact,
                    onValueChange = { contact = it },
                    label = { Text("Contact Number") },
                    placeholder = { Text("e.g. 9876543210") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_edit_instructor_contact")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(name.trim(), contact.trim())
                        onDismiss()
                    }
                },
                enabled = name.isNotBlank(),
                modifier = Modifier.testTag("btn_save_instructor_details")
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("btn_cancel_instructor_details")
            ) {
                Text("Cancel")
            }
        }
    )
}

