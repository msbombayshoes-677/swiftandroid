package com.example.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AdminProfile
import com.example.data.model.AttendanceCorrection
import com.example.data.model.AttendanceRecord
import com.example.data.model.AuditLogEntry
import com.example.data.model.DashboardStats
import com.example.data.model.DiaryNote
import com.example.data.model.InstituteNotification
import com.example.data.model.InstituteSettings
import com.example.data.model.InstructorProfile
import com.example.data.model.Trade
import com.example.data.model.TraineeProfile
import com.example.data.repository.AttendanceRepository
import com.example.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

data class AdminUiState(
    val isLoading: Boolean = false,
    val stats: DashboardStats = DashboardStats(),
    val trades: List<Trade> = emptyList(),
    val instructors: List<InstructorProfile> = emptyList(),
    val pendingInstructors: List<InstructorProfile> = emptyList(),
    val trainees: List<TraineeProfile> = emptyList(),
    val pendingTrainees: List<TraineeProfile> = emptyList(),
    val admins: List<AdminProfile> = emptyList(),
    val todayAttendance: List<AttendanceRecord> = emptyList(),
    val selectedDate: String = DateUtils.getTodayDateString(),
    val instituteSettings: InstituteSettings = InstituteSettings(),
    val auditLogs: List<AuditLogEntry> = emptyList(),
    val corrections: List<AttendanceCorrection> = emptyList(),
    val notifications: List<InstituteNotification> = emptyList(),
    val diaryNotes: List<DiaryNote> = emptyList(),
    val message: String? = null,
    val error: String? = null,
    val selectedTradeFilter: String? = null,
    val searchQuery: String = ""
)

class AdminViewModel(
    private val repo: AttendanceRepository = AttendanceRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(AdminUiState())
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

    private var instructorsListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var tradesListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var traineesListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var diaryListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var attendanceListener: com.google.firebase.firestore.ListenerRegistration? = null

    init {
        loadAllAdminData()
        startObservingRealtimeData()
    }

    private fun startObservingRealtimeData() {
        instructorsListener?.remove()
        instructorsListener = repo.observeInstructors { instructors, pending ->
            val tradesMap = _uiState.value.trades.associateBy { it.tradeId }
            val updatedInstructors = instructors.map { inst ->
                val matched = tradesMap[inst.tradeId]
                if (matched != null && matched.tradeName.isNotBlank() && matched.tradeName != inst.tradeName) {
                    inst.copy(tradeName = matched.tradeName)
                } else inst
            }
            val updatedPending = pending.map { inst ->
                val matched = tradesMap[inst.tradeId]
                if (matched != null && matched.tradeName.isNotBlank() && matched.tradeName != inst.tradeName) {
                    inst.copy(tradeName = matched.tradeName)
                } else inst
            }
            _uiState.update {
                it.copy(
                    instructors = updatedInstructors,
                    pendingInstructors = updatedPending
                )
            }
        }

        tradesListener?.remove()
        tradesListener = repo.observeTrades { trades ->
            _uiState.update { it.copy(trades = trades) }
        }

        traineesListener?.remove()
        traineesListener = repo.observeTrainees { trainees, pending ->
            _uiState.update { current ->
                val newStats = recomputeDashboardStats(
                    current = current,
                    records = current.todayAttendance,
                    trainees = trainees
                )
                current.copy(
                    trainees = trainees,
                    pendingTrainees = pending,
                    stats = newStats
                )
            }
        }

        diaryListener?.remove()
        diaryListener = repo.observeDiaryNotes { notes ->
            _uiState.update { it.copy(diaryNotes = notes) }
        }

        startObservingAttendance(_uiState.value.selectedDate)
    }

    private fun recomputeDashboardStats(
        current: AdminUiState,
        records: List<AttendanceRecord>,
        trainees: List<TraineeProfile> = current.trainees,
        date: String = current.selectedDate,
        cutOffTime: String = current.instituteSettings.cutOffTime
    ): DashboardStats {
        val halfDay = records.count {
            it.attendanceStatus.equals("half_day", ignoreCase = true) ||
            it.attendanceStatus.equals("halfday", ignoreCase = true) ||
            it.attendanceStatus.equals("half day", ignoreCase = true)
        }
        val leave = records.count {
            it.attendanceStatus.equals("leave", ignoreCase = true)
        }
        val present = records.count { it.attendanceStatus.equals("present", ignoreCase = true) || it.attendanceStatus.equals("late", ignoreCase = true) }
        val late = records.count { it.attendanceStatus.equals("late", ignoreCase = true) }
        val explicitAbsent = records.count { it.attendanceStatus.equals("absent", ignoreCase = true) }
        val approvedTrainees = trainees.filter { it.status == "approved" }
        val unpunchedCount = approvedTrainees.count { tr ->
            records.none { att ->
                (tr.uid.isNotBlank() && att.traineeId == tr.uid) ||
                (tr.traineeId.isNotBlank() && att.traineeUniqueId == tr.traineeId)
            }
        }
        val isPastCutOff = DateUtils.isPastCutOff(date, cutOffTime)
        val notMarked = if (isPastCutOff) 0 else unpunchedCount
        val absent = if (isPastCutOff) {
            (approvedTrainees.size - present - halfDay - leave).coerceAtLeast(0)
        } else {
            explicitAbsent
        }
        val pct = if (approvedTrainees.isNotEmpty()) {
            (present.toDouble() / approvedTrainees.size.toDouble()) * 100.0
        } else 0.0

        return current.stats.copy(
            totalTrainees = approvedTrainees.size,
            presentToday = present,
            lateToday = late,
            absentToday = absent,
            halfDayToday = halfDay,
            leaveToday = leave,
            notMarkedToday = notMarked,
            attendancePercentage = pct
        )
    }

    private fun startObservingAttendance(date: String) {
        attendanceListener?.remove()
        attendanceListener = repo.observeDailyAttendance(date) { records ->
            _uiState.update { current ->
                val newStats = recomputeDashboardStats(
                    current = current,
                    records = records,
                    date = date
                )
                current.copy(
                    todayAttendance = records,
                    stats = newStats
                )
            }
        }
    }

    fun loadInstructorsData() {
        viewModelScope.launch {
            val trades = if (_uiState.value.trades.isEmpty()) repo.getTrades() else _uiState.value.trades
            val instructors = repo.getInstructors()
            val pendingInst = repo.getPendingInstructors()
            val tradesMap = trades.associateBy { it.tradeId }

            val updatedInstructors = instructors.map { inst ->
                val matched = tradesMap[inst.tradeId]
                if (matched != null && matched.tradeName.isNotBlank() && matched.tradeName != inst.tradeName) {
                    inst.copy(tradeName = matched.tradeName)
                } else inst
            }
            val updatedPending = pendingInst.map { inst ->
                val matched = tradesMap[inst.tradeId]
                if (matched != null && matched.tradeName.isNotBlank() && matched.tradeName != inst.tradeName) {
                    inst.copy(tradeName = matched.tradeName)
                } else inst
            }

            _uiState.update {
                it.copy(
                    instructors = updatedInstructors,
                    pendingInstructors = updatedPending,
                    trades = if (it.trades.isEmpty()) trades else it.trades
                )
            }
        }
    }

    fun loadTradesData() {
        viewModelScope.launch {
            val trades = repo.getTrades()
            _uiState.update { it.copy(trades = trades) }
        }
    }

    fun loadTraineesData() {
        viewModelScope.launch {
            val trainees = repo.getTrainees()
            val pendingTrainees = repo.getPendingTrainees()
            _uiState.update {
                it.copy(
                    trainees = trainees,
                    pendingTrainees = pendingTrainees
                )
            }
        }
    }

    fun loadDiaryData() {
        viewModelScope.launch {
            val notes = repo.getAllDiaryNotes()
            _uiState.update { it.copy(diaryNotes = notes) }
        }
    }

    override fun onCleared() {
        super.onCleared()
        instructorsListener?.remove()
        tradesListener?.remove()
        traineesListener?.remove()
        diaryListener?.remove()
        attendanceListener?.remove()
    }

    fun loadAllAdminData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            
            // Fetch everything in parallel using async
            val statsDeferred = async { repo.getDashboardStats() }
            val tradesDeferred = async { repo.getTrades() }
            val instructorsDeferred = async { repo.getInstructors() }
            val pendingInstDeferred = async { repo.getPendingInstructors() }
            val traineesDeferred = async { repo.getTrainees() }
            val pendingTrainDeferred = async { repo.getPendingTrainees() }
            val adminsDeferred = async { repo.getAdmins() }
            val todayAttendanceDeferred = async { repo.getDailyAttendance(_uiState.value.selectedDate) }
            val settingsDeferred = async { repo.getInstituteSettings() }
            val logsDeferred = async { repo.getAuditLogs() }
            val correctionsDeferred = async { repo.getAttendanceCorrections() }
            val notifsDeferred = async { repo.getAllNotifications() }
            val diaryDeferred = async { repo.getAllDiaryNotes() }

            // Await all results simultaneously
            val stats = statsDeferred.await()
            val trades = tradesDeferred.await()
            val instructors = instructorsDeferred.await()
            val pendingInst = pendingInstDeferred.await()
            val trainees = traineesDeferred.await()
            val pendingTrain = pendingTrainDeferred.await()
            val admins = adminsDeferred.await()
            val todayAttendance = todayAttendanceDeferred.await()
            val settings = settingsDeferred.await()
            val logs = logsDeferred.await()
            val corrections = correctionsDeferred.await()
            val notifs = notifsDeferred.await()
            val diary = diaryDeferred.await()

            _uiState.update {
                it.copy(
                    isLoading = false,
                    stats = stats,
                    trades = trades,
                    instructors = instructors,
                    pendingInstructors = pendingInst,
                    trainees = trainees,
                    pendingTrainees = pendingTrain,
                    admins = admins,
                    todayAttendance = todayAttendance,
                    instituteSettings = settings,
                    auditLogs = logs,
                    corrections = corrections,
                    notifications = notifs,
                    diaryNotes = diary
                )
            }
        }
    }

    fun addNewAdmin(
        context: android.content.Context,
        name: String,
        email: String,
        password: String,
        creatorAdminName: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            val result = repo.createNewAdmin(context, name, email, password, creatorAdminName)
            result.onSuccess { newAdmin ->
                val updatedList = _uiState.value.admins + newAdmin
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        admins = updatedList,
                        message = "Successfully created new admin: ${newAdmin.name} (${newAdmin.email})"
                    )
                }
                onSuccess()
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = err.message ?: "Failed to create new admin account"
                    )
                }
            }
        }
    }

    fun deleteAdmin(adminUid: String, adminName: String, currentAdminUid: String, currentAdminName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            val success = repo.deleteAdmin(adminUid, adminName, currentAdminUid, currentAdminName)
            if (success) {
                val updatedAdmins = _uiState.value.admins.filter { it.uid != adminUid }
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        admins = updatedAdmins,
                        message = "Admin account '$adminName' deleted successfully."
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = "Failed to delete admin account '$adminName'."
                    )
                }
            }
        }
    }

    fun selectDate(date: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(selectedDate = date) }
            val records = repo.getDailyAttendance(date)
            _uiState.update { it.copy(todayAttendance = records) }
            startObservingAttendance(date)
        }
    }

    suspend fun fetchMonthlyAttendance(yearMonth: String): List<AttendanceRecord> {
        return repo.getMonthlyAttendance(yearMonth)
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun filterByTrade(tradeId: String?) {
        _uiState.update { it.copy(selectedTradeFilter = tradeId) }
    }

    fun addTrade(name: String, code: String, scheme: String, duration: String, adminId: String, adminName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val trade = Trade(
                tradeName = name.trim(),
                tradeCode = code.trim().uppercase(),
                scheme = scheme,
                duration = duration,
                status = "active"
            )
            val success = repo.addTrade(trade, adminId, adminName)
            if (success) {
                _uiState.update { it.copy(message = "Trade '$name' added successfully.") }
                loadAllAdminData()
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to add trade.") }
            }
        }
    }

    fun updateTrade(trade: Trade, adminId: String, adminName: String) {
        viewModelScope.launch {
            val success = repo.updateTrade(trade, adminId, adminName)
            if (success) {
                _uiState.update { it.copy(message = "Trade updated successfully.") }
                loadAllAdminData()
            } else {
                _uiState.update { it.copy(error = "Failed to update trade.") }
            }
        }
    }

    fun toggleTradeStatus(tradeId: String, currentStatus: String, adminId: String, adminName: String) {
        viewModelScope.launch {
            val success = repo.toggleTradeStatus(tradeId, currentStatus, adminId, adminName)
            if (success) {
                _uiState.update { it.copy(message = "Trade status updated.") }
                loadAllAdminData()
            }
        }
    }

    fun deleteTrade(tradeId: String, tradeName: String, adminId: String, adminName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteTrade(tradeId, tradeName, adminId, adminName)
            if (success) {
                _uiState.update { it.copy(message = "Trade '$tradeName' deleted successfully.") }
                loadAllAdminData()
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete trade.") }
            }
        }
    }

    fun approveInstructor(instructorId: String, adminId: String, adminName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.approveInstructor(instructorId, adminId, adminName)
            if (success) {
                _uiState.update { it.copy(message = "Instructor approved successfully.") }
                loadAllAdminData()
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to approve instructor.") }
            }
        }
    }

    fun rejectInstructor(instructorId: String, reason: String, adminId: String, adminName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.rejectInstructor(instructorId, reason, adminId, adminName)
            if (success) {
                _uiState.update { it.copy(message = "Instructor registration rejected.") }
                loadAllAdminData()
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to reject instructor.") }
            }
        }
    }

    fun toggleInstructorStatus(instructorId: String, currentStatus: String, adminId: String, adminName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.toggleInstructorStatus(instructorId, currentStatus, adminId, adminName)
            if (success) {
                _uiState.update { it.copy(message = "Instructor status updated successfully.") }
                loadAllAdminData()
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to update instructor status.") }
            }
        }
    }

    fun deleteInstructor(instructorId: String, instructorName: String, adminId: String, adminName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteInstructor(instructorId, instructorName, adminId, adminName)
            if (success) {
                _uiState.update { it.copy(message = "Instructor '$instructorName' deleted successfully.") }
                loadAllAdminData()
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete instructor.") }
            }
        }
    }

    fun approveTrainee(traineeUid: String, adminId: String, adminName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.approveTrainee(traineeUid, adminId, adminName, "admin")
            if (success) {
                _uiState.update { it.copy(message = "Trainee approved and unique Trainee ID generated.") }
                loadAllAdminData()
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to approve trainee.") }
            }
        }
    }

    fun rejectTrainee(traineeUid: String, reason: String, adminId: String, adminName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.rejectTrainee(traineeUid, reason, adminId, adminName, "admin")
            if (success) {
                _uiState.update { it.copy(message = "Trainee registration rejected.") }
                loadAllAdminData()
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to reject trainee.") }
            }
        }
    }

    fun toggleTraineeStatus(traineeUid: String, currentStatus: String, adminId: String, adminName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.toggleTraineeStatus(traineeUid, currentStatus, adminId, adminName)
            if (success) {
                _uiState.update { it.copy(message = "Trainee status updated successfully.") }
                loadAllAdminData()
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to update trainee status.") }
            }
        }
    }

    fun deleteTrainee(traineeUid: String, traineeName: String, adminId: String, adminName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteTrainee(traineeUid, traineeName, adminId, adminName)
            if (success) {
                _uiState.update { it.copy(message = "Trainee '$traineeName' deleted successfully.") }
                loadAllAdminData()
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete trainee.") }
            }
        }
    }

    fun updateInstructorDetails(
        instructorId: String,
        name: String,
        contact: String,
        adminId: String,
        adminName: String,
        onSuccess: (() -> Unit)? = null
    ) {
        if (name.isBlank()) {
            _uiState.update { it.copy(error = "Instructor name is required.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.updateInstructorProfile(
                instructorId = instructorId,
                name = name.trim(),
                contact = contact.trim(),
                adminId = adminId,
                adminName = adminName
            )
            if (success) {
                _uiState.update { it.copy(message = "Instructor details updated successfully.") }
                loadAllAdminData()
                onSuccess?.invoke()
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to update instructor details.") }
            }
        }
    }

    fun updateTraineeDetails(
        traineeUid: String,
        name: String,
        parentage: String,
        contact: String,
        guardianContact: String,
        address: String,
        adminId: String,
        adminName: String,
        onSuccess: (() -> Unit)? = null
    ) {
        val existingTrainee = _uiState.value.trainees.find { it.uid == traineeUid }
        val email = existingTrainee?.email ?: ""
        val parentAccessPin = existingTrainee?.parentAccessPin ?: "1234"

        if (name.isBlank()) {
            _uiState.update { it.copy(error = "Trainee name is required.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.updateTraineeProfile(
                traineeUid = traineeUid,
                name = name.trim(),
                parentage = parentage.trim(),
                contact = contact.trim(),
                guardianContact = guardianContact.trim(),
                email = email.trim(),
                address = address.trim(),
                parentAccessPin = parentAccessPin,
                updatedBy = adminId,
                updatedByName = adminName,
                updatedByRole = "admin"
            )
            if (success) {
                _uiState.update { it.copy(message = "Trainee details updated successfully.") }
                loadAllAdminData()
                onSuccess?.invoke()
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to update trainee details.") }
            }
        }
    }

    fun updateInstituteSettings(
        name: String,
        address: String,
        lat: Double,
        lng: Double,
        radius: Double,
        reportingTime: String,
        lateTime: String,
        cutOffTime: String,
        adminId: String,
        adminName: String
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val current = _uiState.value.instituteSettings
            val updated = current.copy(
                instituteName = name.trim(),
                instituteAddress = address.trim(),
                latitude = lat,
                longitude = lng,
                radiusMeters = radius,
                reportingTime = reportingTime.trim(),
                lateTimeThreshold = lateTime.trim(),
                cutOffTime = cutOffTime.trim()
            )
            val success = repo.updateInstituteSettings(updated, adminId, adminName, "admin")
            if (success) {
                _uiState.update { curr ->
                    val newStats = recomputeDashboardStats(
                        current = curr,
                        records = curr.todayAttendance,
                        cutOffTime = updated.cutOffTime
                    )
                    curr.copy(
                        isLoading = false,
                        instituteSettings = updated,
                        stats = newStats,
                        message = "Institute GPS & Timings updated successfully."
                    )
                }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to update institute settings.") }
            }
        }
    }

    fun addHoliday(
        date: String,
        name: String,
        description: String = "",
        adminId: String,
        adminName: String
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val cleanDate = date.replace("/", "-").trim()
            val cleanName = name.trim().ifBlank { "Institute Holiday" }
            val success = repo.addHoliday(cleanDate, cleanName, description, adminId, adminName)
            if (success) {
                val latestSettings = repo.getInstituteSettings()
                _uiState.update { curr ->
                    curr.copy(
                        isLoading = false,
                        instituteSettings = latestSettings,
                        message = "Holiday marked successfully for $cleanDate ($cleanName)"
                    )
                }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to mark holiday.") }
            }
        }
    }

    fun deleteHoliday(
        holidayId: String,
        adminId: String,
        adminName: String
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteHoliday(holidayId, adminId, adminName)
            if (success) {
                val latestSettings = repo.getInstituteSettings()
                _uiState.update { curr ->
                    curr.copy(
                        isLoading = false,
                        instituteSettings = latestSettings,
                        message = "Holiday removed successfully."
                    )
                }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to remove holiday.") }
            }
        }
    }

    fun sendBroadcastNotification(
        title: String,
        message: String,
        targetRole: String,
        senderName: String,
        targetTradeId: String? = null,
        targetUserId: String? = null
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.sendNotification(
                title = title.trim(),
                message = message.trim(),
                targetRole = targetRole,
                targetTradeId = targetTradeId,
                targetUserId = targetUserId,
                senderName = senderName
            )
            if (success) {
                val notifs = repo.getAllNotifications()
                _uiState.update { it.copy(isLoading = false, message = "Notification broadcasted successfully.", notifications = notifs) }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to broadcast notification.") }
            }
        }
    }

    fun deleteNotification(notificationId: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteNotification(notificationId)
            if (success) {
                val notifs = repo.getAllNotifications()
                _uiState.update { it.copy(isLoading = false, notifications = notifs, message = "Notification deleted successfully.") }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete notification.") }
            }
        }
    }

    fun deleteNotifications(notificationIds: List<String>) {
        if (notificationIds.isEmpty()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteNotifications(notificationIds)
            if (success) {
                val notifs = repo.getAllNotifications()
                _uiState.update { it.copy(isLoading = false, notifications = notifs, message = "Notifications deleted successfully.") }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete notifications.") }
            }
        }
    }

    fun deleteAllNotifications() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteAllNotifications()
            if (success) {
                val notifs = repo.getAllNotifications()
                _uiState.update { it.copy(isLoading = false, notifications = notifs, message = "All notifications deleted successfully.") }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete all notifications.") }
            }
        }
    }

    fun addDiaryNote(
        traineeId: String,
        traineeName: String,
        tradeId: String,
        tradeName: String,
        adminId: String,
        adminName: String,
        title: String,
        content: String
    ) {
        if (title.isBlank() || content.isBlank() || traineeId.isBlank()) {
            _uiState.update { it.copy(error = "Trainee, Title, and Content are required.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.addDiaryNote(
                traineeId = traineeId,
                traineeName = traineeName,
                tradeId = tradeId,
                tradeName = tradeName,
                instructorId = adminId,
                instructorName = if (adminName.isNotBlank()) "$adminName (Admin)" else "Admin Console",
                title = title,
                content = content
            )
            if (success) {
                val updatedDiary = repo.getAllDiaryNotes()
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        diaryNotes = updatedDiary,
                        message = "Diary note successfully added for $traineeName."
                    )
                }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to add diary note.") }
            }
        }
    }

    fun updateDiaryNote(noteId: String, title: String, content: String) {
        if (title.isBlank() || content.isBlank() || noteId.isBlank()) {
            _uiState.update { it.copy(error = "Title and content cannot be blank.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.updateDiaryNote(noteId, title.trim(), content.trim())
            if (success) {
                val updatedDiary = repo.getAllDiaryNotes()
                _uiState.update { it.copy(isLoading = false, diaryNotes = updatedDiary, message = "Diary note modified successfully.") }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to update diary note.") }
            }
        }
    }

    fun deleteDiaryNote(noteId: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteDiaryNote(noteId)
            if (success) {
                val updatedDiary = repo.getAllDiaryNotes()
                _uiState.update { it.copy(isLoading = false, diaryNotes = updatedDiary, message = "Diary note deleted successfully.") }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete diary note.") }
            }
        }
    }

    suspend fun getAttendanceForDate(date: String, tradeId: String? = null, tradeName: String? = null): List<AttendanceRecord> {
        val approvedTrainees = _uiState.value.trainees.filter { it.status == "approved" }
        val targetTrainees = if (!tradeId.isNullOrBlank() && tradeId != "ALL") {
            approvedTrainees.filter { it.tradeId == tradeId || (tradeName != null && it.tradeName.equals(tradeName, ignoreCase = true)) }
        } else {
            approvedTrainees
        }
        val traineeUids = targetTrainees.map { it.uid }.toSet() + targetTrainees.map { it.traineeId }.toSet()
        return if (!tradeId.isNullOrBlank() && tradeId != "ALL") {
            repo.getTradeAttendance(
                tradeId = tradeId,
                date = date,
                tradeName = tradeName ?: "",
                traineeUids = traineeUids
            )
        } else {
            repo.getDailyAttendance(date)
        }
    }

    suspend fun getMonthlyAttendance(yearMonth: String, tradeId: String? = null, tradeName: String? = null): List<AttendanceRecord> {
        val approvedTrainees = _uiState.value.trainees.filter { it.status == "approved" }
        val targetTrainees = if (!tradeId.isNullOrBlank() && tradeId != "ALL") {
            approvedTrainees.filter { it.tradeId == tradeId || (tradeName != null && it.tradeName.equals(tradeName, ignoreCase = true)) }
        } else {
            approvedTrainees
        }
        val traineeUids = targetTrainees.map { it.uid }.toSet() + targetTrainees.map { it.traineeId }.toSet()
        return if (!tradeId.isNullOrBlank() && tradeId != "ALL") {
            repo.getTradeMonthlyAttendance(
                tradeId = tradeId,
                yearMonth = yearMonth,
                tradeName = tradeName ?: "",
                traineeUids = traineeUids
            )
        } else {
            repo.getMonthlyAttendance(yearMonth)
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(message = null, error = null) }
    }

    fun clearAttendanceCorrections() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.clearAttendanceCorrections()
            if (success) {
                val updatedCorrections = repo.getAttendanceCorrections()
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        corrections = updatedCorrections,
                        message = "All attendance correction entries deleted successfully."
                    )
                }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete attendance corrections.") }
            }
        }
    }

    fun clearAuditLogs() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.clearAuditLogs()
            if (success) {
                val updatedLogs = repo.getAuditLogs()
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        auditLogs = updatedLogs,
                        message = "All system log entries deleted successfully."
                    )
                }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete system logs.") }
            }
        }
    }
}
