package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.InstructorProfile
import com.example.data.model.Trade
import com.example.data.model.TraineeProfile
import com.example.ui.theme.ItiNavyPrimary
import com.example.util.InstructorPrintItem
import com.example.util.PrintTableUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstructorViewAndPrintSection(
    instructors: List<InstructorProfile>,
    trades: List<Trade>,
    trainees: List<TraineeProfile>
) {
    val context = LocalContext.current

    var selectedTradeId by remember { mutableStateOf<String?>(null) }
    val selectedTrade = remember(trades, selectedTradeId) {
        trades.find { it.tradeId == selectedTradeId }
    }
    val currentTradeName = selectedTrade?.tradeName ?: "All Trades"
    var tradeDropdownExpanded by remember { mutableStateOf(false) }

    var searchQuery by remember { mutableStateOf("") }

    // Helper to calculate registered trainees for an instructor's trade
    fun getRegisteredTraineesCount(inst: InstructorProfile): Int {
        val tId = inst.tradeId
        val tName = inst.tradeName
        return trainees.count { trainee ->
            (tId.isNotBlank() && trainee.tradeId == tId) ||
            (tName.isNotBlank() && trainee.tradeName.equals(tName, ignoreCase = true))
        }
    }

    // Filter instructors by selected trade and optional search query
    val filteredInstructors = remember(instructors, selectedTradeId, selectedTrade, searchQuery) {
        val tradeFiltered = if (selectedTradeId == null) {
            instructors
        } else {
            val tName = selectedTrade?.tradeName ?: ""
            instructors.filter {
                it.tradeId == selectedTradeId || (tName.isNotBlank() && it.tradeName.equals(tName, ignoreCase = true))
            }
        }

        if (searchQuery.isBlank()) {
            tradeFiltered.sortedBy { it.name.lowercase() }
        } else {
            val q = searchQuery.trim()
            tradeFiltered.filter {
                it.name.contains(q, ignoreCase = true) ||
                it.email.contains(q, ignoreCase = true) ||
                it.tradeName.contains(q, ignoreCase = true) ||
                it.contact.contains(q, ignoreCase = true)
            }.sortedBy { it.name.lowercase() }
        }
    }

    // Prepare printable items
    val printItems = remember(filteredInstructors, trainees) {
        filteredInstructors.map { inst ->
            InstructorPrintItem(
                instructor = inst,
                registeredTraineesCount = getRegisteredTraineesCount(inst)
            )
        }
    }

    val tableScrollState = rememberScrollState()

    Column(modifier = Modifier.fillMaxSize()) {
        // Filter Card: Select Trade and Controls
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Row with 'Select Trade' dropdown filter and compact Action Buttons (PDF & Print)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Select Trade Dropdown Filter
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedCard(
                            onClick = { tradeDropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth().testTag("select_trade_instructor_dropdown"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.weight(1f, fill = false)
                                ) {
                                    Icon(
                                        if (selectedTradeId == null) Icons.Default.Apps else Icons.Default.Engineering,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Column {
                                        Text("Select Trade", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(
                                            text = if (selectedTradeId == null) "All Trades (${instructors.size})" else "$currentTradeName (${filteredInstructors.size})",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (selectedTradeId != null) {
                                        IconButton(
                                            onClick = { selectedTradeId = null },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear trade filter", modifier = Modifier.size(14.dp))
                                        }
                                    }
                                    Icon(if (tradeDropdownExpanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            }
                        }

                        DropdownMenu(
                            expanded = tradeDropdownExpanded,
                            onDismissRequest = { tradeDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("All Trades (${instructors.size})", fontWeight = if (selectedTradeId == null) FontWeight.Bold else FontWeight.Normal) },
                                onClick = {
                                    selectedTradeId = null
                                    tradeDropdownExpanded = false
                                },
                                leadingIcon = { Icon(Icons.Default.Apps, contentDescription = null) }
                            )
                            trades.forEach { trade ->
                                val count = instructors.count { it.tradeId == trade.tradeId || (trade.tradeName.isNotBlank() && it.tradeName.equals(trade.tradeName, ignoreCase = true)) }
                                DropdownMenuItem(
                                    text = { Text("${trade.tradeName} ($count)", fontWeight = if (selectedTradeId == trade.tradeId) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = {
                                        selectedTradeId = trade.tradeId
                                        tradeDropdownExpanded = false
                                    },
                                    leadingIcon = { Icon(Icons.Default.Engineering, contentDescription = null) }
                                )
                            }
                        }
                    }

                    // Save PDF Button (Compact)
                    OutlinedButton(
                        onClick = {
                            if (printItems.isEmpty()) {
                                Toast.makeText(context, "No instructors to save", Toast.LENGTH_SHORT).show()
                            } else {
                                val success = PrintTableUtils.saveInstructorsPdfToDownloads(
                                    context = context,
                                    items = printItems,
                                    tradeFilterName = currentTradeName
                                )
                                if (success) {
                                    Toast.makeText(context, "PDF saved to Downloads folder", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "Failed to save PDF", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("btn_save_instructor_pdf")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PDF")
                    }

                    // Print Button (Compact)
                    Button(
                        onClick = {
                            if (printItems.isEmpty()) {
                                Toast.makeText(context, "No instructors to print", Toast.LENGTH_SHORT).show()
                            } else {
                                PrintTableUtils.printInstructorsTable(
                                    context = context,
                                    items = printItems,
                                    tradeFilterName = currentTradeName
                                )
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("btn_print_instructor_table")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Print", fontWeight = FontWeight.Bold)
                    }
                }

                // Quick Trade Filter Chips
                if (trades.isNotEmpty()) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            FilterChip(
                                selected = selectedTradeId == null,
                                onClick = { selectedTradeId = null },
                                label = { Text("All Trades (${instructors.size})", style = MaterialTheme.typography.labelSmall) },
                                leadingIcon = {
                                    Icon(Icons.Default.Apps, contentDescription = null, modifier = Modifier.size(14.dp))
                                },
                                modifier = Modifier.testTag("chip_print_inst_trade_all")
                            )
                        }
                        items(trades, key = { it.tradeId }) { trade ->
                            val count = instructors.count { it.tradeId == trade.tradeId || (trade.tradeName.isNotBlank() && it.tradeName.equals(trade.tradeName, ignoreCase = true)) }
                            FilterChip(
                                selected = selectedTradeId == trade.tradeId,
                                onClick = {
                                    selectedTradeId = if (selectedTradeId == trade.tradeId) null else trade.tradeId
                                },
                                label = { Text("${trade.tradeName} ($count)", style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("chip_print_inst_trade_${trade.tradeCode.lowercase()}")
                            )
                        }
                    }
                }

                // Compact Search Box
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search instructor name, email, contact...", style = MaterialTheme.typography.bodySmall) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear search", modifier = Modifier.size(14.dp))
                            }
                        }
                    },
                    textStyle = MaterialTheme.typography.bodySmall,
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("input_search_view_print_instructors")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Table Section
        if (filteredInstructors.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.TableChart,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No instructors found for the selected trade / search.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            // Horizontal scrollable table container
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
            ) {
                Box(modifier = Modifier.fillMaxSize().horizontalScroll(tableScrollState)) {
                    val snoWidth = 60.dp
                    val nameWidth = 180.dp
                    val emailWidth = 200.dp
                    val tradeWidth = 160.dp
                    val contactWidth = 140.dp
                    val traineesCountWidth = 170.dp

                    LazyColumn(modifier = Modifier.fillMaxHeight()) {
                        // Header Row
                        item {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                tonalElevation = 3.dp,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Sno",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.width(snoWidth)
                                    )
                                    Text(
                                        text = "Name",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(nameWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Email",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(emailWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Trade",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(tradeWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Contact No",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(contactWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "No of Register Trainees",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(traineesCountWidth).padding(horizontal = 6.dp)
                                    )
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        }

                        // Table Body Rows
                        items(printItems.size) { index ->
                            val item = printItems[index]
                            val inst = item.instructor
                            val isEven = index % 2 == 0
                            val rowColor = if (isEven) {
                                MaterialTheme.colorScheme.surface
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                            }

                            Surface(
                                color = rowColor,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Sno
                                    Text(
                                        text = "${index + 1}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.width(snoWidth)
                                    )

                                    // Name
                                    Text(
                                        text = inst.name.ifBlank { "-" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .width(nameWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // Email
                                    Text(
                                        text = inst.email.ifBlank { "-" },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier
                                            .width(emailWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // Trade
                                    Text(
                                        text = inst.tradeName.ifBlank { "-" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier
                                            .width(tradeWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // Contact No
                                    Text(
                                        text = inst.contact.ifBlank { "-" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier
                                            .width(contactWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // No of Register Trainees
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .width(traineesCountWidth)
                                            .padding(horizontal = 6.dp)
                                    ) {
                                        Badge(
                                            containerColor = if (item.registeredTraineesCount > 0) {
                                                MaterialTheme.colorScheme.primaryContainer
                                            } else {
                                                MaterialTheme.colorScheme.surfaceVariant
                                            },
                                            contentColor = if (item.registeredTraineesCount > 0) {
                                                MaterialTheme.colorScheme.onPrimaryContainer
                                            } else {
                                                MaterialTheme.colorScheme.onSurfaceVariant
                                            }
                                        ) {
                                            Text(
                                                text = "${item.registeredTraineesCount} Trainees",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        }
                    }
                }
            }
        }
    }
}
