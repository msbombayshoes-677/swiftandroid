package com.example.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AccountStatus
import com.example.data.model.AdminProfile
import com.example.data.model.InstructorProfile
import com.example.data.model.Trade
import com.example.data.model.TraineeProfile
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.data.repository.AttendanceRepository
import com.example.data.repository.AuthRepository
import com.example.data.repository.AuthResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AuthUiState(
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val selectedRole: UserRole = UserRole.ADMIN,
    val currentRole: UserRole? = null,
    val currentUserProfile: UserProfile? = null,
    val currentAdmin: AdminProfile? = null,
    val currentInstructor: InstructorProfile? = null,
    val currentTrainee: TraineeProfile? = null,
    val currentParentTrainee: TraineeProfile? = null,
    val availableTrades: List<Trade> = emptyList(),
    val isRegisteredPending: Boolean = false,
    val isPasswordResetSent: Boolean = false
)

class AuthViewModel(
    private val authRepo: AuthRepository = AuthRepository(),
    private val attendanceRepo: AttendanceRepository = AttendanceRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    init {
        loadTrades()
    }

    fun selectRoleTab(role: UserRole) {
        _uiState.update { it.copy(selectedRole = role, errorMessage = null, successMessage = null) }
        loadTrades()
    }

    fun loadTrades() {
        viewModelScope.launch {
            val trades = attendanceRepo.getActiveTrades()
            _uiState.update { it.copy(availableTrades = trades) }
        }
    }

    fun checkAutoLogin(context: android.content.Context) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val restored = authRepo.checkAndRestoreSession(context)
            if (restored) {
                val role = authRepo.currentRole
                val profile = UserProfile(
                    uid = authRepo.getCurrentUserId() ?: "",
                    name = authRepo.currentAdmin?.name ?: authRepo.currentInstructor?.name ?: authRepo.currentTrainee?.name ?: authRepo.currentParentTrainee?.name ?: "",
                    email = authRepo.currentAdmin?.email ?: authRepo.currentInstructor?.email ?: authRepo.currentTrainee?.email ?: "",
                    role = role?.roleName ?: "trainee",
                    status = authRepo.currentAdmin?.status ?: authRepo.currentInstructor?.status ?: authRepo.currentTrainee?.status ?: "approved"
                )
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        currentUserProfile = profile,
                        currentRole = role,
                        currentAdmin = authRepo.currentAdmin,
                        currentInstructor = authRepo.currentInstructor,
                        currentTrainee = authRepo.currentTrainee,
                        currentParentTrainee = authRepo.currentParentTrainee
                    )
                }
            } else {
                _uiState.update { it.copy(isLoading = false) }
            }
        }
    }

    fun login(email: String, pass: String, context: android.content.Context? = null) {
        if (email.isBlank() || pass.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter both email and password.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val result = authRepo.login(email, pass, context)) {
                is AuthResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            currentUserProfile = result.data,
                            currentRole = authRepo.currentRole,
                            currentAdmin = authRepo.currentAdmin,
                            currentInstructor = authRepo.currentInstructor,
                            currentTrainee = authRepo.currentTrainee
                        )
                    }
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = result.message) }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    fun parentLogin(traineeId: String, pin: String, context: android.content.Context? = null) {
        if (traineeId.isBlank() || pin.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter Trainee ID and Parent Access PIN.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val result = authRepo.parentLogin(traineeId, pin, context)) {
                is AuthResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            currentRole = UserRole.PARENT,
                            currentParentTrainee = result.data
                        )
                    }
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = result.message) }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    fun registerInstructor(
        name: String,
        email: String,
        pass: String,
        contact: String,
        tradeId: String,
        tradeName: String,
        context: android.content.Context? = null
    ) {
        if (name.isBlank() || email.isBlank() || pass.isBlank() || contact.isBlank() || tradeId.isBlank()) {
            _uiState.update { it.copy(errorMessage = "All fields and trade selection are required.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val result = authRepo.registerInstructor(name, email, pass, contact, tradeId, tradeName, context)) {
                is AuthResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            currentRole = UserRole.INSTRUCTOR,
                            currentInstructor = result.data,
                            isRegisteredPending = true,
                            successMessage = "Instructor registration submitted. Awaiting Admin verification and approval."
                        )
                    }
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = result.message) }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    fun registerTrainee(
        name: String,
        parentage: String,
        guardianContact: String = "",
        email: String,
        pass: String,
        contact: String,
        address: String,
        tradeId: String,
        tradeName: String,
        instructorId: String,
        instructorName: String,
        context: android.content.Context? = null
    ) {
        if (name.isBlank() || parentage.isBlank() || email.isBlank() || pass.isBlank() || contact.isBlank() || tradeId.isBlank()) {
            _uiState.update { it.copy(errorMessage = "All registration fields are required.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val result = authRepo.registerTrainee(
                name, parentage, guardianContact, email, pass, contact, address, tradeId, tradeName, instructorId, instructorName, context
            )) {
                is AuthResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            currentRole = UserRole.TRAINEE,
                            currentTrainee = result.data,
                            isRegisteredPending = true,
                            successMessage = "Trainee registration submitted. Awaiting Instructor / Admin approval."
                        )
                    }
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = result.message) }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    fun sendPasswordReset(email: String) {
        if (email.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please enter your email to reset password.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val result = authRepo.sendPasswordReset(email)) {
                is AuthResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isPasswordResetSent = true,
                            successMessage = result.data
                        )
                    }
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = result.message) }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    fun resetInstructorPasswordWithMobile(
        email: String,
        contact: String,
        newPassword: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val result = authRepo.resetInstructorPasswordWithMobile(email, contact, newPassword)) {
                is AuthResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isPasswordResetSent = true,
                            successMessage = result.data
                        )
                    }
                    onSuccess()
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = result.message) }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    fun resetTraineePasswordWithMobileAndPin(
        email: String,
        contact: String,
        parentAccessPin: String,
        newPassword: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val result = authRepo.resetTraineePasswordWithMobileAndPin(email, contact, parentAccessPin, newPassword)) {
                is AuthResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            isPasswordResetSent = true,
                            successMessage = result.data
                        )
                    }
                    onSuccess()
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = result.message) }
                }
                is AuthResult.Loading -> {}
            }
        }
    }

    fun dismissPasswordResetSent() {
        _uiState.update { it.copy(isPasswordResetSent = false) }
    }

    fun refreshProfile() {
        viewModelScope.launch {
            authRepo.refreshCurrentProfile()
            val trainee = authRepo.currentTrainee
            if (trainee != null && (trainee.status.equals("inactive", ignoreCase = true) || trainee.status.equals("deactivated", ignoreCase = true))) {
                authRepo.logout()
                _uiState.update {
                    AuthUiState(
                        availableTrades = it.availableTrades,
                        errorMessage = "Your trainee account has been deactivated by your instructor. You cannot log in with this profile."
                    )
                }
                return@launch
            }
            _uiState.update {
                it.copy(
                    currentRole = authRepo.currentRole,
                    currentAdmin = authRepo.currentAdmin,
                    currentInstructor = authRepo.currentInstructor,
                    currentTrainee = authRepo.currentTrainee
                )
            }
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(errorMessage = null, successMessage = null) }
    }

    fun dismissRegistrationPending() {
        _uiState.update {
            it.copy(
                isRegisteredPending = false,
                successMessage = null,
                currentRole = null,
                currentInstructor = null,
                currentTrainee = null,
                currentUserProfile = null
            )
        }
    }

    fun logout(context: android.content.Context? = null) {
        authRepo.logout(context)
        _uiState.update {
            AuthUiState(availableTrades = it.availableTrades)
        }
    }
}
