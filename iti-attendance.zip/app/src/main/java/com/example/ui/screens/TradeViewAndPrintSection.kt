package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.InstructorProfile
import com.example.data.model.Trade
import com.example.data.model.TraineeProfile
import com.example.util.PrintTableUtils
import com.example.util.TradePrintItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeViewAndPrintSection(
    trades: List<Trade>,
    instructors: List<InstructorProfile>,
    trainees: List<TraineeProfile>
) {
    val context = LocalContext.current

    var selectedInstructorId by remember { mutableStateOf<String?>(null) }
    val selectedInstructor = remember(instructors, selectedInstructorId) {
        instructors.find { it.uid == selectedInstructorId }
    }
    val currentInstructorName = selectedInstructor?.name ?: "All Instructors"
    var instructorDropdownExpanded by remember { mutableStateOf(false) }

    var searchQuery by remember { mutableStateOf("") }

    // Active approved/inactive instructors
    val approvedInstructors = remember(instructors) {
        instructors.filter { it.status == "approved" || it.status == "inactive" }
    }

    // Helper to find incharge instructor for a trade
    fun findInchargeInstructor(trade: Trade): InstructorProfile? {
        return approvedInstructors.firstOrNull { inst ->
            (inst.tradeId.isNotBlank() && inst.tradeId == trade.tradeId) ||
            (trade.tradeName.isNotBlank() && inst.tradeName.equals(trade.tradeName, ignoreCase = true))
        }
    }

    // Helper to count trainees in a trade
    fun getTraineeCountForTrade(trade: Trade): Int {
        val tId = trade.tradeId
        val tName = trade.tradeName
        return trainees.count { trainee ->
            (tId.isNotBlank() && trainee.tradeId == tId) ||
            (tName.isNotBlank() && trainee.tradeName.equals(tName, ignoreCase = true))
        }
    }

    // Filter trades based on selected instructor and search query
    val printItems = remember(trades, approvedInstructors, trainees, selectedInstructorId, selectedInstructor, searchQuery) {
        // Map all trades to TradePrintItem
        val allTradeItems = trades.map { trade ->
            val incharge = findInchargeInstructor(trade)
            TradePrintItem(
                trade = trade,
                inchargeInstructorName = incharge?.name?.ifBlank { "Unassigned" } ?: "Unassigned",
                email = incharge?.email ?: "-",
                contactNo = incharge?.contact ?: "-",
                traineesCount = getTraineeCountForTrade(trade),
                instructorId = incharge?.uid ?: ""
            )
        }

        // Filter by selected instructor if any
        val instructorFiltered = if (selectedInstructorId == null) {
            allTradeItems
        } else {
            val inst = selectedInstructor
            val instTradeId = inst?.tradeId ?: ""
            val instTradeName = inst?.tradeName ?: ""
            val instUid = inst?.uid ?: ""
            allTradeItems.filter { item ->
                item.instructorId == instUid ||
                (instTradeId.isNotBlank() && item.trade.tradeId == instTradeId) ||
                (instTradeName.isNotBlank() && item.trade.tradeName.equals(instTradeName, ignoreCase = true))
            }
        }

        // Filter by search query
        if (searchQuery.isBlank()) {
            instructorFiltered.sortedBy { it.trade.tradeName.lowercase() }
        } else {
            val q = searchQuery.trim()
            instructorFiltered.filter { item ->
                item.trade.tradeName.contains(q, ignoreCase = true) ||
                item.trade.tradeCode.contains(q, ignoreCase = true) ||
                item.trade.duration.contains(q, ignoreCase = true) ||
                item.inchargeInstructorName.contains(q, ignoreCase = true) ||
                item.email.contains(q, ignoreCase = true) ||
                item.contactNo.contains(q, ignoreCase = true)
            }.sortedBy { it.trade.tradeName.lowercase() }
        }
    }

    val tableScrollState = rememberScrollState()

    Column(modifier = Modifier.fillMaxSize()) {
        // Top Filter Card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Row with 'Select Instructor' dropdown filter and compact Action Buttons (PDF & Print)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Select Instructor Dropdown Filter
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedCard(
                            onClick = { instructorDropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth().testTag("select_instructor_dropdown"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.weight(1f, fill = false)
                                ) {
                                    Icon(
                                        if (selectedInstructorId == null) Icons.Default.Groups else Icons.Default.Person,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Column {
                                        Text("Select Instructor", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(
                                            text = if (selectedInstructorId == null) "All Instructors (${trades.size})" else "$currentInstructorName (${printItems.size})",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (selectedInstructorId != null) {
                                        IconButton(
                                            onClick = { selectedInstructorId = null },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear instructor filter", modifier = Modifier.size(14.dp))
                                        }
                                    }
                                    Icon(if (instructorDropdownExpanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            }
                        }

                        DropdownMenu(
                            expanded = instructorDropdownExpanded,
                            onDismissRequest = { instructorDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("All Instructors (${trades.size})", fontWeight = if (selectedInstructorId == null) FontWeight.Bold else FontWeight.Normal) },
                                onClick = {
                                    selectedInstructorId = null
                                    instructorDropdownExpanded = false
                                },
                                leadingIcon = { Icon(Icons.Default.Groups, contentDescription = null) },
                                modifier = Modifier.testTag("menu_item_all_instructors")
                            )
                            approvedInstructors.forEach { inst ->
                                val assignedTradesCount = trades.count { trade ->
                                    (inst.tradeId.isNotBlank() && inst.tradeId == trade.tradeId) ||
                                    (trade.tradeName.isNotBlank() && inst.tradeName.equals(trade.tradeName, ignoreCase = true))
                                }
                                DropdownMenuItem(
                                    text = { Text("${inst.name} • ${inst.tradeName.ifBlank { "General" }} ($assignedTradesCount)", fontWeight = if (selectedInstructorId == inst.uid) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = {
                                        selectedInstructorId = inst.uid
                                        instructorDropdownExpanded = false
                                    },
                                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                                    modifier = Modifier.testTag("menu_item_instructor_${inst.uid}")
                                )
                            }
                        }
                    }

                    // Save PDF Button (Compact)
                    OutlinedButton(
                        onClick = {
                            if (printItems.isEmpty()) {
                                Toast.makeText(context, "No trades to save", Toast.LENGTH_SHORT).show()
                            } else {
                                val success = PrintTableUtils.saveTradesPdfToDownloads(
                                    context = context,
                                    items = printItems,
                                    instructorFilterName = currentInstructorName
                                )
                                if (success) {
                                    Toast.makeText(context, "PDF saved to Downloads folder", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "Failed to save PDF", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("btn_save_trades_pdf")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PDF")
                    }

                    // Print Button (Compact)
                    Button(
                        onClick = {
                            if (printItems.isEmpty()) {
                                Toast.makeText(context, "No trades to print", Toast.LENGTH_SHORT).show()
                            } else {
                                PrintTableUtils.printTradesTable(
                                    context = context,
                                    items = printItems,
                                    instructorFilterName = currentInstructorName
                                )
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("btn_print_trades_table")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Print", fontWeight = FontWeight.Bold)
                    }
                }

                // Quick Instructor Filter Chips
                if (approvedInstructors.isNotEmpty()) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            FilterChip(
                                selected = selectedInstructorId == null,
                                onClick = { selectedInstructorId = null },
                                label = { Text("All Instructors", style = MaterialTheme.typography.labelSmall) },
                                leadingIcon = {
                                    Icon(Icons.Default.Groups, contentDescription = null, modifier = Modifier.size(14.dp))
                                },
                                modifier = Modifier.testTag("chip_instructor_all")
                            )
                        }
                        items(approvedInstructors, key = { it.uid }) { inst ->
                            FilterChip(
                                selected = selectedInstructorId == inst.uid,
                                onClick = {
                                    selectedInstructorId = if (selectedInstructorId == inst.uid) null else inst.uid
                                },
                                label = { Text(inst.name, style = MaterialTheme.typography.labelSmall) },
                                leadingIcon = if (selectedInstructorId == inst.uid) {
                                    { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                } else null,
                                modifier = Modifier.testTag("chip_instructor_${inst.uid}")
                            )
                        }
                    }
                }

                // Compact Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search trade, code, instructor...", style = MaterialTheme.typography.bodySmall) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Clear search", modifier = Modifier.size(14.dp))
                            }
                        }
                    },
                    textStyle = MaterialTheme.typography.bodySmall,
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("input_search_trades_table")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Table Content
        if (printItems.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.TableChart,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No trades found for the selected instructor / search.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            // Horizontal scrollable table container
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
            ) {
                // Fixed column widths for consistent table styling
                val snoWidth = 50.dp
                val tradeWidth = 180.dp
                val tradeCodeWidth = 110.dp
                val durationWidth = 110.dp
                val inchargeWidth = 170.dp
                val emailWidth = 190.dp
                val contactWidth = 130.dp
                val traineesCountWidth = 135.dp
                val totalTableWidth = snoWidth + tradeWidth + tradeCodeWidth + durationWidth + inchargeWidth + emailWidth + contactWidth + traineesCountWidth

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(tableScrollState)
                ) {
                    LazyColumn(modifier = Modifier.fillMaxHeight()) {
                        // Header Row
                        item {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                tonalElevation = 3.dp,
                                modifier = Modifier.width(totalTableWidth)
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Sno",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.width(snoWidth)
                                    )
                                    Text(
                                        text = "Trade",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(tradeWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Trade Code",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(tradeCodeWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Duration",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(durationWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Incharge Instructor",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(inchargeWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Email",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(emailWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Contact No",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(contactWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "No. Of Trainees",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(traineesCountWidth).padding(horizontal = 6.dp)
                                    )
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        }

                        // Table Body Rows
                        items(printItems.size) { index ->
                            val item = printItems[index]
                            val isEven = index % 2 == 0
                            val rowColor = if (isEven) {
                                MaterialTheme.colorScheme.surface
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                            }

                            Surface(
                                color = rowColor,
                                modifier = Modifier.width(totalTableWidth)
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Sno
                                    Text(
                                        text = "${index + 1}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.width(snoWidth)
                                    )

                                    // Trade
                                    Text(
                                        text = item.trade.tradeName.ifBlank { "-" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .width(tradeWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // Trade Code
                                    Surface(
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier
                                            .width(tradeCodeWidth)
                                            .padding(horizontal = 6.dp)
                                    ) {
                                        Text(
                                            text = item.trade.tradeCode.ifBlank { "-" },
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            textAlign = TextAlign.Center,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                        )
                                    }

                                    // Duration
                                    Text(
                                        text = item.trade.duration.ifBlank { "-" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier
                                            .width(durationWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // Incharge Instructor
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier
                                            .width(inchargeWidth)
                                            .padding(horizontal = 6.dp)
                                    ) {
                                        if (item.inchargeInstructorName != "Unassigned") {
                                            Icon(
                                                Icons.Default.AccountCircle,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp),
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        Text(
                                            text = item.inchargeInstructorName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (item.inchargeInstructorName != "Unassigned") FontWeight.SemiBold else FontWeight.Normal,
                                            color = if (item.inchargeInstructorName != "Unassigned") MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                                        )
                                    }

                                    // Email
                                    Text(
                                        text = item.email,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier
                                            .width(emailWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // Contact No
                                    Text(
                                        text = item.contactNo,
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier
                                            .width(contactWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // No. Of Trainees
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .width(traineesCountWidth)
                                            .padding(horizontal = 6.dp)
                                    ) {
                                        Badge(
                                            containerColor = if (item.traineesCount > 0) {
                                                MaterialTheme.colorScheme.primaryContainer
                                            } else {
                                                MaterialTheme.colorScheme.surfaceVariant
                                            },
                                            contentColor = if (item.traineesCount > 0) {
                                                MaterialTheme.colorScheme.onPrimaryContainer
                                            } else {
                                                MaterialTheme.colorScheme.onSurfaceVariant
                                            }
                                        ) {
                                            Text(
                                                text = "${item.traineesCount} Trainees",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        }
                    }
                }
            }
        }
    }
}
