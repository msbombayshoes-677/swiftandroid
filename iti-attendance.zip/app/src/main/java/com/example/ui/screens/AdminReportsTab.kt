package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AttendanceRecord
import com.example.data.model.DashboardStats
import com.example.data.model.Holiday
import com.example.data.model.Trade
import com.example.data.model.TraineeProfile
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.util.CsvExportUtils
import com.example.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminReportsTab(
    trades: List<Trade>,
    trainees: List<TraineeProfile>,
    todayAttendance: List<AttendanceRecord>,
    stats: DashboardStats,
    workingDaysList: List<String> = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"),
    holidays: List<Holiday> = emptyList(),
    onFetchDayAttendance: (suspend (date: String, tradeId: String?, tradeName: String?) -> List<AttendanceRecord>)? = null,
    onFetchMonthlyAttendance: (suspend (yearMonth: String, tradeId: String?, tradeName: String?) -> List<AttendanceRecord>)? = null
) {
    var selectedTradeId by remember { mutableStateOf<String?>(null) }
    val selectedTrade = remember(trades, selectedTradeId) {
        trades.find { it.tradeId == selectedTradeId }
    }
    val currentTradeName = selectedTrade?.tradeName ?: "All Trades"
    var tradeDropdownExpanded by remember { mutableStateOf(false) }

    var reportTab by remember { mutableStateOf(1) } // 0: Day-Wise, 1: Month-Wise (Default to Month-Wise)
    var selectedDayDate by remember { mutableStateOf(DateUtils.getTodayDateString()) }
    var selectedMonthStr by remember { mutableStateOf(DateUtils.getTodayDateString().take(7)) } // e.g. "2026-08"

    var showDayDatePickerDialog by remember { mutableStateOf(false) }
    var showMonthDatePickerDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }

    var dayAttendanceRecords by remember { mutableStateOf<List<AttendanceRecord>>(todayAttendance) }
    var monthlyAttendanceRecords by remember { mutableStateOf<List<AttendanceRecord>>(emptyList()) }
    var isLoadingDay by remember { mutableStateOf(false) }
    var isLoadingMonth by remember { mutableStateOf(false) }
    var reloadDayTrigger by remember { mutableStateOf(0) }
    var reloadMonthlyTrigger by remember { mutableStateOf(0) }
    var dayFilterStatus by remember { mutableStateOf("all") }

    val currentTrainees = remember(trainees, selectedTradeId, selectedTrade) {
        if (selectedTradeId == null) {
            trainees
        } else {
            val sTradeName = selectedTrade?.tradeName ?: ""
            trainees.filter {
                it.tradeId == selectedTradeId || (sTradeName.isNotBlank() && it.tradeName.equals(sTradeName, ignoreCase = true))
            }
        }
    }

    val availableMonths = remember {
        val list = mutableListOf<Pair<String, String>>()
        val cal = java.util.Calendar.getInstance()
        val sdfVal = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault())
        val sdfLbl = java.text.SimpleDateFormat("MMMM yyyy", java.util.Locale.getDefault())
        for (i in 0..11) {
            list.add(sdfVal.format(cal.time) to sdfLbl.format(cal.time))
            cal.add(java.util.Calendar.MONTH, -1)
        }
        list
    }

    // Trigger Day attendance fetch when day date, trade, or reload trigger changes
    LaunchedEffect(selectedDayDate, reportTab, reloadDayTrigger, selectedTradeId) {
        if (reportTab == 0) {
            if (selectedDayDate == DateUtils.getTodayDateString() && todayAttendance.isNotEmpty() && reloadDayTrigger == 0 && selectedTradeId == null) {
                dayAttendanceRecords = todayAttendance
            } else if (onFetchDayAttendance != null) {
                isLoadingDay = true
                dayAttendanceRecords = onFetchDayAttendance(selectedDayDate, selectedTradeId, selectedTrade?.tradeName)
                isLoadingDay = false
            }
        }
    }

    // Trigger Monthly attendance fetch when month, trade, or reload trigger changes
    LaunchedEffect(selectedMonthStr, reportTab, reloadMonthlyTrigger, selectedTradeId) {
        if (reportTab == 1 && onFetchMonthlyAttendance != null) {
            isLoadingMonth = true
            monthlyAttendanceRecords = onFetchMonthlyAttendance(selectedMonthStr, selectedTradeId, selectedTrade?.tradeName)
            isLoadingMonth = false
        }
    }

    // Day DatePicker Dialog
    if (showDayDatePickerDialog) {
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = try {
                val sdf = java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.getDefault())
                sdf.parse(selectedDayDate)?.time
            } catch (_: Exception) { null }
        )
        DatePickerDialog(
            onDismissRequest = { showDayDatePickerDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val selectedMillis = datePickerState.selectedDateMillis
                        if (selectedMillis != null) {
                            selectedDayDate = DateUtils.formatUtcMillisToDate(selectedMillis)
                        }
                        showDayDatePickerDialog = false
                    }
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDayDatePickerDialog = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    // Month DatePicker Dialog
    if (showMonthDatePickerDialog) {
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = try {
                val sdf = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault())
                sdf.parse(selectedMonthStr)?.time
            } catch (_: Exception) { null }
        )
        DatePickerDialog(
            onDismissRequest = { showMonthDatePickerDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val selectedMillis = datePickerState.selectedDateMillis
                        if (selectedMillis != null) {
                            val formattedDate = DateUtils.formatUtcMillisToDate(selectedMillis)
                            selectedMonthStr = formattedDate.replace("/", "-").take(7)
                        }
                        showMonthDatePickerDialog = false
                    }
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showMonthDatePickerDialog = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    var traineeSearchQuery by remember { mutableStateOf("") }
    var expandedTraineeUids by remember { mutableStateOf<Set<String>>(emptySet()) }

    val (monthTotalDays, monthWorkingDays, monthHolidays) = remember(selectedMonthStr, workingDaysList, holidays) {
        DateUtils.calculateWorkingDays(selectedMonthStr, workingDaysList, holidays)
    }

    val distinctMonthDates = remember(monthlyAttendanceRecords) {
        monthlyAttendanceRecords.map { it.date.replace("/", "-") }.distinct().size
    }

    val enrolledUids = remember(currentTrainees) { currentTrainees.map { it.uid }.toSet() }
    val enrolledTraineeIds = remember(currentTrainees) { currentTrainees.map { it.traineeId }.filter { it.isNotBlank() }.toSet() }

    val allTraineesForMonth = remember(currentTrainees, monthlyAttendanceRecords, selectedTradeId) {
        val additional = monthlyAttendanceRecords
            .filter { it.traineeId !in enrolledUids && it.traineeUniqueId !in enrolledTraineeIds }
            .filter { rec ->
                if (selectedTradeId == null) true
                else rec.tradeId == selectedTradeId || (selectedTrade?.tradeName?.isNotBlank() == true && rec.tradeName.equals(selectedTrade.tradeName, ignoreCase = true))
            }
            .distinctBy { it.traineeId.ifBlank { it.traineeUniqueId } }
            .map { rec ->
                TraineeProfile(
                    uid = rec.traineeId,
                    traineeId = rec.traineeUniqueId,
                    name = rec.traineeName,
                    tradeName = rec.tradeName
                )
            }
        (currentTrainees + additional).sortedBy { it.name }
    }

    val filteredTrainees = remember(allTraineesForMonth, traineeSearchQuery) {
        if (traineeSearchQuery.isBlank()) allTraineesForMonth
        else {
            val q = traineeSearchQuery.trim()
            allTraineesForMonth.filter {
                it.name.contains(q, ignoreCase = true) ||
                it.traineeId.contains(q, ignoreCase = true)
            }
        }
    }

    // Day Stats Summary with full mapping
    val dayAttendanceMap = remember(dayAttendanceRecords) {
        val map = mutableMapOf<String, AttendanceRecord>()
        dayAttendanceRecords.forEach { rec ->
            if (rec.traineeId.isNotBlank()) map[rec.traineeId] = rec
            if (rec.traineeUniqueId.isNotBlank()) map[rec.traineeUniqueId] = rec
            if (rec.traineeName.isNotBlank()) map[rec.traineeName.lowercase().trim()] = rec
        }
        map
    }

    val allTraineesForDay = remember(currentTrainees, dayAttendanceRecords, enrolledUids, enrolledTraineeIds, selectedTradeId) {
        val additional = dayAttendanceRecords
            .filter { it.traineeId !in enrolledUids && it.traineeUniqueId !in enrolledTraineeIds }
            .filter { rec ->
                if (selectedTradeId == null) true
                else rec.tradeId == selectedTradeId || (selectedTrade?.tradeName?.isNotBlank() == true && rec.tradeName.equals(selectedTrade.tradeName, ignoreCase = true))
            }
            .distinctBy { it.traineeId.ifBlank { it.traineeUniqueId } }
            .map { rec ->
                TraineeProfile(
                    uid = rec.traineeId,
                    traineeId = rec.traineeUniqueId,
                    name = rec.traineeName,
                    tradeName = rec.tradeName
                )
            }
        (currentTrainees + additional).sortedBy { it.name }
    }

    val (dayPresentCountOnly, dayLateCount, dayMarkedAbsentCount, dayNotMarkedCount) = remember(allTraineesForDay, dayAttendanceMap) {
        var pOnly = 0
        var lCount = 0
        var aCount = 0
        var nmCount = 0
        allTraineesForDay.forEach { tr ->
            val rec = dayAttendanceMap[tr.uid]
                ?: (if (tr.traineeId.isNotBlank()) dayAttendanceMap[tr.traineeId] else null)
                ?: (if (tr.name.isNotBlank()) dayAttendanceMap[tr.name.lowercase().trim()] else null)
            val status = rec?.attendanceStatus?.lowercase()?.trim() ?: "not_marked"
            when (status) {
                "present" -> pOnly++
                "late" -> lCount++
                "absent" -> aCount++
                else -> nmCount++
            }
        }
        listOf(pOnly, lCount, aCount, nmCount)
    }

    val totalDayEnrolled = allTraineesForDay.size
    val presentDayCount = dayPresentCountOnly + dayLateCount
    // Formula: Absent trainees = enrolled trainees - present trainees - not marked attendance
    val absentDayCount = (totalDayEnrolled - presentDayCount - dayNotMarkedCount).coerceAtLeast(0)
    val lateDayCount = dayLateCount
    val notMarkedDayCount = dayNotMarkedCount
    val dayRate = if (totalDayEnrolled > 0) (presentDayCount.toFloat() / totalDayEnrolled) * 100f else 0f

    val filteredDayTrainees = remember(allTraineesForDay, dayAttendanceMap, dayFilterStatus) {
        allTraineesForDay.filter { tr ->
            val rec = dayAttendanceMap[tr.uid]
                ?: (if (tr.traineeId.isNotBlank()) dayAttendanceMap[tr.traineeId] else null)
                ?: (if (tr.name.isNotBlank()) dayAttendanceMap[tr.name.lowercase().trim()] else null)
            val status = rec?.attendanceStatus?.lowercase()?.trim() ?: "not_marked"
            when (dayFilterStatus) {
                "all" -> true
                "present" -> status == "present" || status == "late"
                "late" -> status == "late"
                "absent" -> status == "absent"
                "not_marked" -> status != "present" && status != "late" && status != "absent"
                else -> true
            }
        }
    }

    val dayHoliday = remember(selectedDayDate, holidays) {
        DateUtils.getHolidayForDate(selectedDayDate, holidays)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header with Export Report Button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Attendance Reports", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        text = if (selectedTradeId == null) "All ITI Trades Overview" else "Trade: $currentTradeName",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                FilledTonalButton(
                    onClick = { showExportDialog = true },
                    modifier = Modifier.testTag("btn_export_admin_report")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Export Report")
                }
            }
        }

        // Select Trade Filter Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Engineering, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            Text("Select Trade", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = if (selectedTradeId == null) "All Trades (${currentTrainees.size} Trainees)" else "$currentTradeName (${currentTrainees.size} Trainees)",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    // Dropdown Selector
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedCard(
                            onClick = { tradeDropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(
                                        if (selectedTradeId == null) Icons.Default.Apps else Icons.Default.Engineering,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Column {
                                        Text("Filter by Trade", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(if (selectedTradeId == null) "All Trades (${trainees.size} Trainees)" else currentTradeName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Icon(if (tradeDropdownExpanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        }

                        DropdownMenu(
                            expanded = tradeDropdownExpanded,
                            onDismissRequest = { tradeDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("All Trades (${trainees.size})", fontWeight = if (selectedTradeId == null) FontWeight.Bold else FontWeight.Normal) },
                                onClick = {
                                    selectedTradeId = null
                                    tradeDropdownExpanded = false
                                },
                                leadingIcon = { Icon(Icons.Default.Apps, contentDescription = null) }
                            )
                            trades.forEach { trade ->
                                val count = trainees.count { it.tradeId == trade.tradeId }
                                DropdownMenuItem(
                                    text = { Text("${trade.tradeName} ($count)", fontWeight = if (selectedTradeId == trade.tradeId) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = {
                                        selectedTradeId = trade.tradeId
                                        tradeDropdownExpanded = false
                                    },
                                    leadingIcon = { Icon(Icons.Default.Engineering, contentDescription = null) }
                                )
                            }
                        }
                    }

                    // Quick Filter Chips Row
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            FilterChip(
                                selected = selectedTradeId == null,
                                onClick = { selectedTradeId = null },
                                label = { Text("All Trades (${trainees.size})", style = MaterialTheme.typography.labelSmall) },
                                leadingIcon = {
                                    Icon(Icons.Default.Apps, contentDescription = null, modifier = Modifier.size(14.dp))
                                },
                                modifier = Modifier.testTag("chip_admin_trade_all")
                            )
                        }
                        items(trades, key = { it.tradeId }) { trade ->
                            val count = trainees.count { it.tradeId == trade.tradeId }
                            FilterChip(
                                selected = selectedTradeId == trade.tradeId,
                                onClick = {
                                    selectedTradeId = if (selectedTradeId == trade.tradeId) null else trade.tradeId
                                },
                                label = { Text("${trade.tradeName} ($count)", style = MaterialTheme.typography.labelSmall) },
                                modifier = Modifier.testTag("chip_admin_trade_${trade.tradeCode.lowercase()}")
                            )
                        }
                    }
                }
            }
        }

        // Mode Selector Tabs: Day-Wise vs Month-Wise
        item {
            TabRow(selectedTabIndex = reportTab) {
                Tab(
                    selected = reportTab == 0,
                    onClick = { reportTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Today, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Day-Wise Report", fontWeight = FontWeight.Bold)
                        }
                    }
                )
                Tab(
                    selected = reportTab == 1,
                    onClick = { reportTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Month-Wise Report", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }
        }

        if (reportTab == 0) {
            // Day-Wise Date Picker Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Selected Day:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "${DateUtils.formatDateForDisplay(selectedDayDate)} ($selectedDayDate)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(
                                onClick = { reloadDayTrigger++ },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    Icons.Default.Refresh,
                                    contentDescription = "Refresh Day Attendance",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            OutlinedButton(
                                onClick = { showDayDatePickerDialog = true },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("btn_pick_day_wise_date")
                            ) {
                                Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Select Date")
                            }
                        }
                    }
                }
            }

            // Holiday Alert Banner if selected day is a marked holiday
            if (dayHoliday != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f),
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                Icons.Default.EventBusy,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(24.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Institute Holiday: ${dayHoliday.name}",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "This day is marked as a holiday. It is excluded from working days and attendance calculations.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Day Summary (${DateUtils.formatDateForDisplay(selectedDayDate)})",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Surface(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Text(
                                    text = "Rate: ${String.format(java.util.Locale.US, "%.1f", dayRate)}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Enrolled", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    Text("$totalDayEnrolled", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Present", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    Text("$presentDayCount", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = StatusPresentGreen)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Absent", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    Text("$absentDayCount", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = StatusAbsentRed)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Late", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    Text("$lateDayCount", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = StatusLateOrange)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Unmarked", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    Text("$notMarkedDayCount", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }

            // Filter chips for Day-Wise Report
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val filters = listOf(
                        "all" to "All ($totalDayEnrolled)",
                        "present" to "Present ($presentDayCount)",
                        "absent" to "Absent ($absentDayCount)",
                        "late" to "Late ($lateDayCount)",
                        "not_marked" to "Not Marked ($notMarkedDayCount)"
                    )
                    items(filters) { (fKey, fLabel) ->
                        FilterChip(
                            selected = dayFilterStatus == fKey,
                            onClick = { dayFilterStatus = fKey },
                            label = { Text(fLabel, fontWeight = if (dayFilterStatus == fKey) FontWeight.Bold else FontWeight.Normal) },
                            modifier = Modifier.testTag("chip_day_filter_$fKey")
                        )
                    }
                }
            }

            if (isLoadingDay) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp))
                    }
                }
            } else {
                item {
                    Text(
                        text = "Trainee Day Attendance (${filteredDayTrainees.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (filteredDayTrainees.isEmpty()) {
                    item {
                        Text(
                            text = "No trainees found for the selected filter on $selectedDayDate.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    items(filteredDayTrainees) { tr ->
                        val rec = dayAttendanceMap[tr.uid]
                            ?: (if (tr.traineeId.isNotBlank()) dayAttendanceMap[tr.traineeId] else null)
                            ?: (if (tr.name.isNotBlank()) dayAttendanceMap[tr.name.lowercase().trim()] else null)
                        val status = rec?.attendanceStatus?.lowercase()?.trim() ?: "not_marked"
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = RoundedCornerShape(8.dp),
                            tonalElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(tr.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    val punchText = if (rec?.punchInTime != null) "Punch In: ${DateUtils.formatTime(rec.punchInTime)}" else "Attendance Not Marked"
                                    val tradeSub = if (tr.tradeName.isNotBlank()) " • ${tr.tradeName}" else ""
                                    Text(
                                        text = "ID: ${tr.traineeId.ifBlank { tr.uid.take(8) }}$tradeSub • $punchText",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                StatusBadge(status = status)
                            }
                        }
                    }
                }
            }
        } else {
            // Month-Wise Report
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Selected Month:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = "${DateUtils.formatYearMonthForDisplay(selectedMonthStr)} ($selectedMonthStr)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(
                                    onClick = { reloadMonthlyTrigger++ },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Refresh,
                                        contentDescription = "Refresh Month Attendance",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                OutlinedButton(
                                    onClick = { showMonthDatePickerDialog = true },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.testTag("btn_pick_month_wise_date")
                                ) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Select Month")
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Quick Select Month:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(4.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(availableMonths) { pair ->
                                FilterChip(
                                    selected = selectedMonthStr == pair.first,
                                    onClick = { selectedMonthStr = pair.first },
                                    label = { Text(pair.second, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Monthly Overview (${DateUtils.formatYearMonthForDisplay(selectedMonthStr)})",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Surface(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Text(
                                    text = "$monthWorkingDays Working Days",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Trainees", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${allTraineesForMonth.size}", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Working Days", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    Text("$monthWorkingDays", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Total Holiday's", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    Text("$monthHolidays", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, color = StatusLateOrange)
                                }
                            }
                        }
                    }
                }
            }

            // Search Bar for trainees
            item {
                OutlinedTextField(
                    value = traineeSearchQuery,
                    onValueChange = { traineeSearchQuery = it },
                    label = { Text("Search Trainee by Name or ID") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (traineeSearchQuery.isNotBlank()) {
                            IconButton(onClick = { traineeSearchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("input_search_monthly_trainee"),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )
            }

            if (isLoadingMonth) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(modifier = Modifier.size(32.dp))
                    }
                }
            } else {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Trainee Month-Wise Report (${filteredTrainees.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        if (allTraineesForMonth.isNotEmpty()) {
                            TextButton(
                                onClick = {
                                    expandedTraineeUids = if (expandedTraineeUids.size == allTraineesForMonth.size) emptySet()
                                    else allTraineesForMonth.map { it.uid.ifBlank { it.traineeId } }.toSet()
                                }
                            ) {
                                Text(if (expandedTraineeUids.size == allTraineesForMonth.size) "Collapse All" else "Expand Logs")
                            }
                        }
                    }
                }

                if (filteredTrainees.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    if (traineeSearchQuery.isNotBlank()) "No trainees matching '$traineeSearchQuery'"
                                    else "No trainee records found for ${DateUtils.formatYearMonthForDisplay(selectedMonthStr)}.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = { reloadMonthlyTrigger++ },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reload Records")
                                }
                            }
                        }
                    }
                } else {
                    items(filteredTrainees) { trainee ->
                        val traineeKey = trainee.uid.ifBlank { trainee.traineeId }
                        val isExpanded = expandedTraineeUids.contains(traineeKey)
                        TraineeMonthReportCard(
                            trainee = trainee,
                            monthlyAttendanceRecords = monthlyAttendanceRecords,
                            distinctMonthDates = distinctMonthDates,
                            monthWorkingDays = monthWorkingDays,
                            selectedMonthStr = selectedMonthStr,
                            holidays = holidays,
                            isExpanded = isExpanded,
                            onToggleExpand = {
                                expandedTraineeUids = if (isExpanded) expandedTraineeUids - traineeKey
                                else expandedTraineeUids + traineeKey
                            }
                        )
                    }
                }
            }
        }
    }

    // Export Report Dialog
    if (showExportDialog) {
        val context = LocalContext.current
        val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
        var exportMode by remember { mutableStateOf(reportTab) } // 0: Daily, 1: Monthly
        var exportDayDate by remember { mutableStateOf(selectedDayDate) }
        var exportMonthStr by remember { mutableStateOf(selectedMonthStr) }

        var exportDayRecords by remember { mutableStateOf<List<AttendanceRecord>>(dayAttendanceRecords) }
        var exportMonthRecords by remember { mutableStateOf<List<AttendanceRecord>>(monthlyAttendanceRecords) }

        var showExportDayPicker by remember { mutableStateOf(false) }
        var showExportMonthPicker by remember { mutableStateOf(false) }

        LaunchedEffect(exportDayDate, selectedTradeId) {
            if (exportDayDate == selectedDayDate && dayAttendanceRecords.isNotEmpty()) {
                exportDayRecords = dayAttendanceRecords
            } else if (onFetchDayAttendance != null) {
                exportDayRecords = onFetchDayAttendance(exportDayDate, selectedTradeId, selectedTrade?.tradeName)
            }
        }

        LaunchedEffect(exportMonthStr, selectedTradeId) {
            if (exportMonthStr == selectedMonthStr && monthlyAttendanceRecords.isNotEmpty()) {
                exportMonthRecords = monthlyAttendanceRecords
            } else if (onFetchMonthlyAttendance != null) {
                exportMonthRecords = onFetchMonthlyAttendance(exportMonthStr, selectedTradeId, selectedTrade?.tradeName)
            }
        }

        if (showExportDayPicker) {
            val datePickerState = rememberDatePickerState(
                initialSelectedDateMillis = try {
                    val sdf = java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.getDefault())
                    sdf.parse(exportDayDate)?.time
                } catch (_: Exception) { null }
            )
            DatePickerDialog(
                onDismissRequest = { showExportDayPicker = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            val selectedMillis = datePickerState.selectedDateMillis
                            if (selectedMillis != null) {
                                exportDayDate = DateUtils.formatUtcMillisToDate(selectedMillis)
                            }
                            showExportDayPicker = false
                        }
                    ) {
                        Text("OK")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showExportDayPicker = false }) { Text("Cancel") }
                }
            ) {
                DatePicker(state = datePickerState)
            }
        }

        if (showExportMonthPicker) {
            val datePickerState = rememberDatePickerState(
                initialSelectedDateMillis = try {
                    val sdf = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault())
                    sdf.parse(exportMonthStr)?.time
                } catch (_: Exception) { null }
            )
            DatePickerDialog(
                onDismissRequest = { showExportMonthPicker = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            val selectedMillis = datePickerState.selectedDateMillis
                            if (selectedMillis != null) {
                                val formattedDate = DateUtils.formatUtcMillisToDate(selectedMillis)
                                exportMonthStr = formattedDate.replace("/", "-").take(7)
                            }
                            showExportMonthPicker = false
                        }
                    ) {
                        Text("OK")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showExportMonthPicker = false }) { Text("Cancel") }
                }
            ) {
                DatePicker(state = datePickerState)
            }
        }

        val activeRecords = if (exportMode == 0) exportDayRecords else exportMonthRecords

        val reportCsv = remember(exportMode, activeRecords, currentTradeName, exportMonthStr, currentTrainees) {
            buildString {
                if (exportMode == 0) {
                    append("Date,Trainee ID,Trainee Name,Trade,Status,Punch In,Punch Out,Remarks\n")
                    activeRecords.forEach { a ->
                        val trTrade = a.tradeName.ifBlank { currentTradeName }
                        append("${a.date},${a.traineeUniqueId},${a.traineeName},$trTrade,${a.attendanceStatus},${DateUtils.formatTime(a.punchInTime)},${DateUtils.formatTime(a.punchOutTime)},${a.remarks ?: ""}\n")
                    }
                } else {
                    // Month-Wise Trainee Summary CSV
                    val distinctDates = activeRecords.map { it.date.replace("/", "-") }.distinct().size
                    val eUids = currentTrainees.map { it.uid }.toSet()
                    val eIds = currentTrainees.map { it.traineeId }.filter { it.isNotBlank() }.toSet()
                    val additional = activeRecords
                        .filter { it.traineeId !in eUids && it.traineeUniqueId !in eIds }
                        .distinctBy { it.traineeId.ifBlank { it.traineeUniqueId } }
                        .map { TraineeProfile(uid = it.traineeId, traineeId = it.traineeUniqueId, name = it.traineeName, tradeName = it.tradeName) }
                    val allList = (currentTrainees + additional).sortedBy { it.name }

                    append("=== MONTHLY TRAINEE ATTENDANCE SUMMARY ($exportMonthStr - $currentTradeName) ===\n")
                    append("Trainee ID,Trainee Name,Trade,Total Punches,Present Days,Late Days,Absent Days,Total Working Days,Attendance %\n")
                    allList.forEach { tr ->
                        val trRecords = activeRecords.filter {
                            (tr.uid.isNotBlank() && it.traineeId == tr.uid) ||
                            (tr.traineeId.isNotBlank() && it.traineeUniqueId == tr.traineeId) ||
                            (tr.name.isNotBlank() && it.traineeName.equals(tr.name, ignoreCase = true))
                        }
                        val punches = trRecords.sumOf { rec ->
                            var c = 0
                            if (rec.punchInTime != null) c++
                            if (rec.punchOutTime != null) c++
                            if (c == 0 && (rec.attendanceStatus == "present" || rec.attendanceStatus == "late")) c = 1
                            c
                        }
                        val present = trRecords.count { it.attendanceStatus.equals("present", ignoreCase = true) }
                        val late = trRecords.count { it.attendanceStatus.equals("late", ignoreCase = true) }
                        val absent = trRecords.count { it.attendanceStatus.equals("absent", ignoreCase = true) }
                        val attended = present + late
                        val pct = if (distinctDates > 0) ((attended.toDouble() / distinctDates.toDouble()) * 100.0).coerceIn(0.0, 100.0)
                        else if (trRecords.isNotEmpty()) ((attended.toDouble() / trRecords.size.toDouble()) * 100.0).coerceIn(0.0, 100.0) else 0.0
                        val trId = tr.traineeId.ifBlank { tr.uid.take(8) }
                        val trTrade = tr.tradeName.ifBlank { currentTradeName }

                        append("$trId,${tr.name},$trTrade,$punches,$present,$late,$absent,$distinctDates,${String.format(java.util.Locale.US, "%.1f%%", pct)}\n")
                    }

                    append("\n=== DETAILED MONTHLY LOGS ===\n")
                    append("Date,Trainee ID,Trainee Name,Trade,Status,Punch In,Punch Out,Remarks\n")
                    activeRecords.forEach { a ->
                        val trTrade = a.tradeName.ifBlank { currentTradeName }
                        append("${a.date},${a.traineeUniqueId},${a.traineeName},$trTrade,${a.attendanceStatus},${DateUtils.formatTime(a.punchInTime)},${DateUtils.formatTime(a.punchOutTime)},${a.remarks ?: ""}\n")
                    }
                }
            }
        }

        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = {
                Column {
                    Text("Export Attendance Report", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Trade: $currentTradeName", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TabRow(selectedTabIndex = exportMode) {
                        Tab(
                            selected = exportMode == 0,
                            onClick = { exportMode = 0 },
                            text = { Text("Day-Wise", fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = exportMode == 1,
                            onClick = { exportMode = 1 },
                            text = { Text("Month-Wise", fontWeight = FontWeight.Bold) }
                        )
                    }

                    if (exportMode == 0) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Target Date: $exportDayDate", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                OutlinedButton(
                                    onClick = { showExportDayPicker = true },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Pick Date", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Target Month: ${DateUtils.formatYearMonthForDisplay(exportMonthStr)}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                OutlinedButton(
                                    onClick = { showExportMonthPicker = true },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Pick Month", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(availableMonths) { pair ->
                                    FilterChip(
                                        selected = exportMonthStr == pair.first,
                                        onClick = { exportMonthStr = pair.first },
                                        label = { Text(pair.second, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Records: ${activeRecords.size}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Text(
                                "Present: ${activeRecords.count { it.attendanceStatus == "present" || it.attendanceStatus == "late" }} | Absent: ${activeRecords.count { it.attendanceStatus == "absent" }}",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(160.dp)
                    ) {
                        Text(
                            text = reportCsv,
                            modifier = Modifier.padding(8.dp),
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val sanitizedTrade = currentTradeName.replace(" ", "_").replace("/", "-")
                        val fileName = if (exportMode == 0) {
                            "attendance_report_${sanitizedTrade}_${exportDayDate.replace("/", "-")}.csv"
                        } else {
                            "attendance_report_${sanitizedTrade}_${exportMonthStr.replace("/", "-")}.csv"
                        }
                        val downloaded = CsvExportUtils.downloadCsvFile(context, fileName, reportCsv)
                        if (downloaded) {
                            android.widget.Toast.makeText(context, "CSV downloaded: $fileName to Downloads folder", android.widget.Toast.LENGTH_LONG).show()
                        } else {
                            clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(reportCsv))
                            android.widget.Toast.makeText(context, "CSV copied to clipboard!", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.testTag("btn_download_admin_report_csv")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Download CSV")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) { Text("Close") }
            }
        )
    }
}
