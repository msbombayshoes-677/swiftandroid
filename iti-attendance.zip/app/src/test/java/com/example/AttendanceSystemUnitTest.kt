package com.example

import com.example.data.model.InstituteSettings
import com.example.util.DateUtils
import com.example.util.LocationHelper
import org.junit.Assert.*
import org.junit.Test

class AttendanceSystemUnitTest {

    @Test
    fun testHaversineDistance_exactSamePoint_returnsZero() {
        val lat = 28.6139
        val lng = 77.2090
        val dist = LocationHelper.calculateDistanceMeters(lat, lng, lat, lng)
        assertEquals(0.0, dist, 0.001)
    }

    @Test
    fun testHaversineDistance_nearbyPoint_returnsCorrectMeters() {
        // Point A: ITI campus center
        val lat1 = 28.6139
        val lng1 = 77.2090

        // Point B: ~50 meters away
        // 0.00045 degrees latitude is roughly 50 meters
        val lat2 = 28.61435
        val lng2 = 77.2090

        val dist = LocationHelper.calculateDistanceMeters(lat1, lng1, lat2, lng2)
        assertTrue("Distance should be approximately 50 meters, was $dist", dist in 45.0..55.0)
    }

    @Test
    fun testGeofenceVerification_within100mRadius_isAllowed() {
        val settings = InstituteSettings(
            latitude = 28.6139,
            longitude = 77.2090,
            radiusMeters = 100.0
        )

        // Trainee is 40 meters away
        val traineeLat = 28.61426
        val traineeLng = 77.2090

        val result = LocationHelper.verifyLocation(traineeLat, traineeLng, settings)
        assertTrue("Trainee within 100m radius must be allowed", result.isWithinRadius)
        assertTrue("Distance must be <= 100m", result.distanceMeters <= 100.0)
    }

    @Test
    fun testGeofenceVerification_outside100mRadius_isForbidden() {
        val settings = InstituteSettings(
            latitude = 28.6139,
            longitude = 77.2090,
            radiusMeters = 100.0
        )

        // Trainee is ~300 meters away
        val traineeLat = 28.6166
        val traineeLng = 77.2090

        val result = LocationHelper.verifyLocation(traineeLat, traineeLng, settings)
        assertFalse("Trainee outside 100m radius must NOT be allowed", result.isWithinRadius)
        assertTrue("Distance must be > 100m", result.distanceMeters > 100.0)
    }

    @Test
    fun testDateFormatting() {
        val todayStr = DateUtils.getTodayDateString()
        assertTrue("Date should match YYYY-MM-DD pattern", todayStr.matches(Regex("\\d{4}-\\d{2}-\\d{2}")))

        val formatted = DateUtils.formatDateForDisplay("2026-08-23")
        assertTrue("Formatted date should contain year 2026", formatted.contains("2026"))
    }
}
